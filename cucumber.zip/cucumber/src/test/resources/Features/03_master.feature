@login @outReach_Event_setup
@master

Feature: Master actions

Background:
    Given placed on dashboard page
    
Scenario: Master actions
    And I wait for "2" seconds
    And I click on master option
    And I navigated to the master page
    And I wait for "2" seconds
