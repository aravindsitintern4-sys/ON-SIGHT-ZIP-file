#@login @outReach_Event_setup
@vision_clinical_records

Feature: Vision workflow in clinical records
	
Scenario: vision workflow
	And I click "Vision" label option
	Then popup "Vision" should be displayed

Scenario Outline: Vision chart dropdown
	And I select vision chart "<visiondata>" dropdown
		
Examples:
      | visiondata                |
      | Chart Based VA            |
      | Red Reflex Test           |
      | Fixation and Following    |
      | Preferential Looking Test |
	    
# AUTOMATION HOLD     
#  CHART BASED VA 
Scenario: Chart based VA selection actions (Clear and save)
	And I select vision chart "Chart Based VA" dropdown
	And I select RE "6/6" and LE "6/6" in UCVA dropdown
	And I select RE "6/6" and LE "6/6" in UCVAph dropdown
	And I click "Clear" button in vision
	And I select RE "6/6" and LE "6/6" in UCVA dropdown
	And I select RE "6/6" and LE "6/6" in UCVAph dropdown
	And I click "Save" button in vision	

#RED REFLEX TEST 	
Scenario: Red Reflex Test selection valid action
	And I click "Vision" label option
	And I select vision chart "Red Reflex Test" dropdown
	And I click "Continue" button in window
	And I click "Normal" flex button for "RE"
	And I click "Normal" flex button for "LE"
	And I click "Update" button in vision
	
# FIXATION AND FOLLOWING
Scenario: Fixation and Following selection valid action
	And I click "Vision" label option
	And I select vision chart "Fixation and Following" dropdown    
	And I click "Continue" button in window  
	And I click "Normal" flex button for "RE"
	And I click "Normal" flex button for "LE"
	And I click "Update" button in vision

# PREFERENTIAL LOOKING TEST 
Scenario: Preferential Looking Test selection valid action
	And I click "Vision" label option
	And I select vision chart "Preferential Looking Test" dropdown
	And I click "Continue" button in window  
	And I select method "Matching Cards" dropdown
	And I click "Normal" flex button for "RE"
	And I click "Normal" flex button for "LE" 
	And I click "Update" button in vision

Scenario: Red Reflex Test selection valid Delete action
	And I click "Vision" label option
	And I select vision chart "Red Reflex Test" dropdown
	And I click "Continue" button in window
	And I click "Normal" flex button for "RE"
	And I click "Normal" flex button for "LE"
	And I click "Delete" button in vision
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window    
	
# FINAL VALID VISION TEST DATAS
Scenario: Chart based VA selection valid actions
	And I click "Vision" label option
	And I select vision chart "Chart Based VA" dropdown
	And I select RE "6/6" and LE "6/6" in UCVA dropdown
	And I select RE "6/6" and LE "6/6" in UCVAph dropdown
	And I click "Save" button in vision
	Then I navigated to the doctor screen page 
	And I wait for "3" seconds
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	