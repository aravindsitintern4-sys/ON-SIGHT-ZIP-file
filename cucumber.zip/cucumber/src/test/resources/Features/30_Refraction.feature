@login @outReach_Event_setup
@refraction_clinical_records

Feature: Refraction workflow in clinical records
		
Scenario: Refraction workflow
	And user clicks "Refraction" label option
	Then popup "Refraction" should be displayed

Scenario: Undilated RR Details workflow
	And I click "Undilated RR" option in refraction
		
Scenario: Dyn RR Details workflow
	And I click "Dyn.RR" sub option in Undilated RR
	
Scenario: Empty fields in Undilated RR
	And I click "Save & Next" button in dynamic RR
	Then I should see "Please fill in the mandatory fields" field error message

Scenario: working distance Dynamic RR
	And I enter "Working distance:" label details as "80" in undialated RR



























# DILATED ----> DILATED RR 	
#Scenario: Drug name in dilated RR
	#And I select label as "Drug name:" and option as "Tropicamide Plus" in undilated RR	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	