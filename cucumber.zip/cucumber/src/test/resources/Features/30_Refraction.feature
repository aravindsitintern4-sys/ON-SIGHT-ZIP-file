@login @outReach_Event_setup
@refraction_clinical_records

Feature: Refraction workflow in clinical records
		
Scenario: Refraction workflow
	And user clicks "Refraction" label option
	Then popup "Refraction" should be displayed

#Current Spectacles --->  Current Spectacles(1)		
Scenario: Current Spectacles part one Details workflow
	And I click "Current Spectacles(1)" option in refraction

Scenario: Current Spectacles part one - Usage
	# ONE LABEL ONE OPTION
	And I select label as "Usage:" and option as "Regular" in refraction
	And I select label as "Usage:" and option as "Irregular" in refraction
	And I select label as "Usage:" and option as "Discontinued" in refraction
	And I select label as "Usage:" and option as "Broken" in refraction
	And I select label as "Usage:" and option as "Has prescription only" in refraction

Scenario: Current Spectacles part one - Duration	
	And I click Duration field in refraction
	And I set duration value "12" in refraction
    And I set duration type "Day" in refraction
    And I set duration value "12" in refraction
    And I set duration type "Week" in refraction
    And I set duration value "12" in refraction
    And I set duration type "Month" in refraction
    And I set duration value "12" in refraction
    And I set duration type "Year" in refraction
	And I click "Ok" button in duration in refraction

Scenario: Current Spectacles part one - Type of spectacle
	And I select label as "Type of spectacle:" and option as "DV Only" in refraction
	And I select label as "Type of spectacle:" and option as "NV Only" in refraction
	And I select label as "Type of spectacle:" and option as "Myopia Control Lens" in refraction
	# LOCATION SELECT
	And I select label "Type of spectacle:" option "Executive Bifocal" for selection dropdown in refraction

Scenario: Current Spectacles part one - Lens details
	And I select label as "Lens details:" and option as "Glass" in refraction
	And I select label as "Lens details:" and option as "Plastic" in refraction
	And I select label as "Lens details:" and option as "White" in refraction
	And I select label as "Lens details:" and option as "Tint" in refraction
	And I select label as "Lens details:" and option as "Photochromic" in refraction
	And I select label as "Lens details:" and option as "AR Coat" in refraction

Scenario: Current Spectacles part one - Prism
	And I select label as "Prism:" and option as "RE" in refraction
	And I select label as "Prism:" and option as "LE" in refraction
	#TWO LABELS (SELECT)
	And I select main label "RE:" sub label "Prism type:" option "Glass Mounted Prism" for selection dropdown in refraction
	# TWO LABELS INPUT
	And I enter "RE:" parent label "Prism type:" childlabel details as "11" in refraction
	And I select main label "RE:" sub label "Orientation:" option "Base in" for selection dropdown in refraction
	And I select main label "LE:" sub label "Prism type:" option "Peli Prism" for selection dropdown in refraction
	And I enter "LE:" parent label "Prism type:" childlabel details as "11" in refraction
	And I select main label "LE:" sub label "Orientation:" option "Base Out" for selection dropdown in refraction
	
Scenario: Current Spectacles part one - Condition
	# ONE LABEL ONE OPTION NG SELECT
	And I select label as "Condition:" and option as "Good" in refraction
	And I select label as "Condition:" option as "Frame Broken" for dropdown in refraction
	
Scenario: Current Spectacles part one - Fitting of spectacle
	And I select label as "Fitting of spectacle:" and option as "Good" in refraction
	And I select label "Fitting of spectacle:" option "Centering Problem" for selection dropdown in refraction	
	
Scenario: Current Spectacles part one - Satisfaction
	And I select label as "Satisfaction:" and option as "Satisfied" in refraction
	And I select label as "Satisfaction:" and option as "Not Satisfied" in refraction	

# START WORK FROM HERE	
Scenario: Current Spectacles part one - DBOC
	And I enter "DBOC:" parent label "RE:" childlabel details as "11" in refraction
	And I enter "DBOC:" parent label "LE:" childlabel details as "12" in refraction
	
Scenario: Current Spectacles part one - Chart types	
	And I select label "Chart types:" option "Snellen 3 Metre" for selection dropdown in refraction		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	