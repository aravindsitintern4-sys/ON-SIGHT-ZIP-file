@login @outReach_Event_setup
@refraction_clinical_records

Feature: Refraction workflow in clinical records
		
Scenario: Refraction workflow
	And user clicks "Refraction" label option
	Then popup "Refraction" should be displayed

Scenario: Actions for buttons in Current spectacles Part one
	And I click "Update & Next" button in current spectacles part one
			
Scenario: update & next for Dynamic RR
	And I click "Update & Next" button in dynamic RR
	
Scenario: Save action in Sub RR DV
	And I click "Update & Next" button in Sub.RR DV
		
Scenario: Sub.RR NV Details workflow
	And I click "Update & Next" button in Sub.RR NV
		
Scenario: Additional Info Details workflow
	And I click "Update & Next" button in add info

# GLASS PRESCRIPTION
Scenario: Glass Prescription Details workflow
	And I click "Glass Prescription" option in refraction
	
Scenario: Empty fields in Glass Prescription
	And I click "Save & Next" button in Glass Prescription
	Then I should see "Please fill in the mandatory fields" field error message
		
Scenario: label click in glass prescription in refraction
	And I select "Subjective RR" RR type
	
	
Scenario: DrugName Dilated
	And I select label as "Drug name:" and option as "Tropicamide Plus" in dilated     
	
Scenario: Select Dilated values for RE
# RE
	And I select "130" in "RE" for "Diopter Values (90's)" in refraction
	And I select "+1.25" in "RE" for "Diopter Values (90's)" in refraction
	And I select "180" in "RE" for "Diopter Values (180's)" in refraction
	And I select "-0.25" in "RE" for "Diopter Values (180's)" in refraction
	And I select "Dull Reflex" in "RE" for "Type of Reflex" in refraction
	And I move to "LE" refraction section

Scenario: Select Dilated values for LE
#LE  
	And I select "70" in "LE" for "Diopter Values (90's)" in refraction
	And I select "+2.25" in "LE" for "Diopter Values (90's)" in refraction
	And I select "145" in "LE" for "Diopter Values (180's)" in refraction
	And I select "-0.50" in "LE" for "Diopter Values (180's)" in refraction
	And I select "Peripheral Reflex" in "LE" for "Type of Reflex" in refraction             
	    
Scenario: Remarks in Dilated
	And I enter Remarks as "Dilated remark entered" in refraction
	
Scenario: Summary display in Dilated
	Then undilated RR summary should be displayed
	
Scenario: Save action in Dilated
	And I click "Save & Next" button in dilated

# SUB RR DV DILATED
Scenario: Empty fields in Sub.RR DV
	And I click "Save & Next" button in Sub.RR DV
	#And I click "Clear" button in dynamic RR
	#And I click "Update & Next" button in dynamic RR
	Then I should see "Please fill in the mandatory fields" field error message
	
Scenario: Sub.RR DV - Chart types	
	And I select label "Chart types:" option "LogMAR (Snellen equ)" for selection dropdown in refraction
		
Scenario: Select Refractions values in sub RR DV for RE
# RE
	And I select "6/3P" in "RE" for "UCVA" in refraction
	And I select "+1.25" in "RE" for "Spherical" in refraction
	And I select "-0.50" in "RE" for "Cylinder" in refraction
	And I select "90" in "RE" for "Axis" in refraction
	And I select "6/6P" in "RE" for "BCVA" in refraction
	And I select "6/12P" in "RE" for "PH BCVA" in refraction
	And I select "11" in "RE" for "MPD" in refraction
	And I move to "LE" refraction section

Scenario: Select Refractions values in sub RR DV for LE
#LE 
	And I select "12" in "LE" for "MPD" in refraction	
	And I select "6/12P" in "LE" for "UCVA" in refraction
	And I select "+0.25" in "LE" for "Spherical" in refraction
	And I select "-0.25" in "LE" for "Cylinder" in refraction
	And I select "85" in "LE" for "Axis" in refraction
	And I select "6/12P" in "LE" for "BCVA" in refraction
	And I select "6/15P" in "LE" for "PH BCVA" in refraction
	

Scenario: Occupation in Sub.RR DV
	And I select label as "Occupation:" option as "Actor" for dropdown in refraction
	And I enter "Occupation:" label details as "Occupation is entered" for input field

Scenario: Remarks in Sub.RR DV
	And I select label as "Remarks:" option as "BE any correction not taken" for dropdown in refraction
	And I enter "Remarks:" label details as "Remarks is entered" for input field
	
Scenario: Summary display in Undilated RR
	Then undilated RR summary should be displayed
	
Scenario: Save action in Sub RR DV
	And I click "Save & Next" button in Sub.RR DV






















# DILATED ----> DILATED RR 	
#Scenario: Drug name in dilated RR
	#And I select label as "Drug name:" and option as "Tropicamide Plus" in undilated RR	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	