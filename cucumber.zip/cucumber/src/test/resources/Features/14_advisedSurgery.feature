@login @outReach_Event_setup
@surgery_advised_dashboard

Feature: Surgery Advised inside dashboard Workflow

Scenario: Surgery Advised inside dashboard actions
	And I click patient surgery confirmed section in dashboard
	Then I navigated to the surgery advised onboarding page
	
Scenario: button actions in patient onboarding
    And I click "Done" button in surgery adviced onboarding