#@login @outReach_Event_setup
@CR_dashboard_doctor_screen_navigation

Feature: Clinical Records Dashboard to Doctor screen page navigation actions

# CLINICAL RECORDS DASHBOARDPAGE TO DOCTOR SCREEN ACTIONS (FILTER THE PATIENT AND ENTER PIN ACTIONS)

Scenario: Report view icon
	And I clear search box
	And I wait for "2" seconds
	When I enter id in search bar "C-00001-0165"
	And I wait for "2" seconds
	And I click report view icon
	And I wait for "2" seconds
	And I click "Close" button

#NEGATIVE SCENARIO
Scenario: No patient found
	And I clear search box
	And I wait for "2" seconds
	When I enter id in search bar "jdhjscgvhjcvcjgcjchgchgch"
	Then "No patient found" found messege should be displayed

Scenario: Reset buttons in Enter PIN popup
	And I clear search box
	And I wait for "2" seconds
	When I enter id in search bar "C-00001-0165"
    And I click filtered option 
    Then popup "Enter PIN" should be displayed
    And I wait for "2" seconds
    And I enter pin "97"
    And I enter pin "Reset"
    And I wait for "2" seconds
    And I enter pin "981"
    Then error message "Invalid PIN. Please try again" should be displayed  
    And I click close icon

Scenario: Delete buttons in Enter PIN popup
	And I clear search box
	And I wait for "2" seconds
	When I enter id in search bar "C-00001-0165"
    And I click filtered option
    Then popup "Enter PIN" should be displayed
    And I wait for "2" seconds
    And I enter pin "9"
    And I enter pin "Delete"
    And I enter pin "981"
    Then error message "Invalid PIN. Please try again" should be displayed  
    And I click close icon

Scenario: Invalid Pin 
	And I clear search box	
	And I wait for "2" seconds
	When I enter id in search bar "C-00001-0165"
    And I click filtered option
    Then popup "Enter PIN" should be displayed
    And I wait for "2" seconds
    And I enter pin "973"
    Then error message "Invalid PIN. Please try again" should be displayed 
    And I click close icon
       
Scenario: Valid Test datas for navigation for doctor screen
 	And I clear search box 
 	And I wait for "2" seconds
	When I enter id in search bar "C-00001-0210"
    And I click filtered option
    Then popup "Enter PIN" should be displayed
    And I enter pin "183"
    Then I navigated to the doctor screen page
    And I wait for "2" seconds
                       
     