#@login @outReach_Event_setup
@station_overview

Feature: Station Overview Workflow

Scenario: Station Overview report
	And I click patient station overview section in dashboard
	Then popup "Station Overview" should be displayed
		
                  