@login @outReach_Event_setup
@auto_refraction_clinical_records

Feature: Auto Refraction workflow in clinical records 

Scenario: Auto Refraction workflow
	And I click "Auto Refraction" label option
	Then popup "Auto Refraction" should be displayed
	
Scenario: button actions in Auto Refraction
	Then save button should be disable
	And I click "Start" button in autorefraction
	

