#@login @outReach_Event_setup
@outReach_master_EditEvent

Feature: OutReach Master EditWorkflow

# NEW BUTTON 
Background:
  Then user navigated to the outreach event master page
  And user clears search box
	
#EDIT WORKFLOW
Scenario: Edit button workflow invalid Test datas in event
    And user enters data in search bar "100"
    Then no data found messege should be displayed in dropdown in event
    
Scenario: Edit button workflow invalid Test datas in event
    And user enters data in search bar "india"
    Then no data found messege should be displayed in dropdown in event

Scenario Outline: Edit workflow using Valid data
  When user enters data in search bar "<datas>"
  Then event details for data "<datas>" should be displayed
  When user selects checkbox for data "<datas>"
  Then checkbox for data "<datas>" should be selected
  Then edit and delete buttons should be enabled and new button should be disabled
  When user clicks on edit button in Event
  Then event creation popup with existing details should be displayed
  And user clicks cancel button in event popup
  
 Examples:
      | datas    |
      | 41       |
      | Madurai  |
      
Scenario: Edit OP data in aready created event
  When user enters data in search bar "41"
  Then event details for data "41" should be displayed
  When user selects checkbox for data "41"
  Then checkbox for data "41" should be selected
  Then edit and delete buttons should be enabled and new button should be disabled
  When user clicks on edit button in Event
  Then event creation popup with existing details should be displayed
  #START DATE
	And user clicks event start date calendar icon
    And user selects start month "Nov"
	And user selects start year "2026"
	And user selects start date "15" from date picker
	Then selected date should be displayed in event start date field
    And user enters expected op "700"
    And user clicks update button in event 
  
Scenario: Delete event workflow with Confirmation Cancel (Do not delete event)
	  When user enters data in search bar "64"
	  Then event details for data "64" should be displayed
	  When user selects checkbox for data "64"
	  Then checkbox for data "64" should be selected
	  Then edit and delete buttons should be enabled and new button should be disabled
	  And user clicks on delete button in Event
	  And user clicks on Confirmation Cancel in Event


Scenario: Delete event workflow with Confirmation Ok (delete event)
	  When user enters data in search bar "70"
	  Then event details for data "70" should be displayed
	  When user selects checkbox for data "70"
	  Then checkbox for data "70" should be selected
	  Then edit and delete buttons should be enabled and new button should be disabled
	  And user clicks on delete button in Event
	  And user clicks on Confirmation ok in Event
	  And user enters data in search bar "70"
  	  Then no data found messege should be displayed in dropdown in event    

Scenario: Navigate to User master Edit actions
	And user clicks on home
	And user clicks on master option
    And user navigated to the master page	
    And user clicks on user master option
    Then user navigated to the user master page
    Then edit and delete and reset password buttons should be disable initially
    
    
    
    
  
 


    
    