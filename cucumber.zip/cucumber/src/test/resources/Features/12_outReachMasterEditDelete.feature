@login @outReach_Event_setup
@outReach_master_EditEvent

Feature: OutReach Master EditWorkflow

# NEW BUTTON 
Background:
  Then I navigated to the outreach event master page
  And I clear search box
	
#EDIT WORKFLOW
Scenario: Edit button workflow invalid Test datas in event
    And I enter data in search bar "100"
    Then no data found messege should be displayed in dropdown in event
    
Scenario: Edit button workflow invalid Test datas in event
    And I enter data in search bar "india"
    Then no data found messege should be displayed in dropdown in event

Scenario Outline: Edit workflow using Valid data
  When I enter data in search bar "<datas>"
  Then event details for data "<datas>" should be displayed
  When I select checkbox for data "<datas>"
  Then checkbox for data "<datas>" should be selected
  Then edit and delete buttons should be enabled and new button should be disabled
  When I click on edit button in Event
  Then event creation popup with existing details should be displayed
  And I click cancel button in event popup
  
 Examples:
      | datas    |
      | 41       |
      | Madurai  |
      
Scenario: Edit OP data in aready created event
  When I enter data in search bar "41"
  Then event details for data "41" should be displayed
  When I select checkbox for data "41"
  Then checkbox for data "41" should be selected
  Then edit and delete buttons should be enabled and new button should be disabled
  When I click on edit button in Event
  Then event creation popup with existing details should be displayed
  #START DATE
	And I click event start date calendar icon
    And I select start month "Nov"
	And I select start year "2026"
	And I select start date "15" from date picker
	Then selected date should be displayed in event start date field
    And I enter expected op "700"
    And I click update button in event 
  
Scenario: Delete event workflow with Confirmation Cancel (Do not delete event)
	  When I enter data in search bar "64"
	  Then event details for data "64" should be displayed
	  When I select checkbox for data "64"
	  Then checkbox for data "64" should be selected
	  Then edit and delete buttons should be enabled and new button should be disabled
	  And I click on delete button in Event
	  And I click on Confirmation Cancel in Event


Scenario: Delete event workflow with Confirmation Ok (delete event)
	  When I enter data in search bar "70"
	  Then event details for data "70" should be displayed
	  When I select checkbox for data "70"
	  Then checkbox for data "70" should be selected
	  Then edit and delete buttons should be enabled and new button should be disabled
	  And I click on delete button in Event
	  And I click on Confirmation ok in Event
	  And I enter data in search bar "70"
  	  Then no data found messege should be displayed in dropdown in event    

Scenario: Navigate to User master Edit actions
	And I click on home
	And I click on master option
    And I navigated to the master page	
    And I click on user master option
    Then I navigated to the user master page
    Then edit and delete and reset password buttons should be disable initially
    
    
    
    
  
 


    
    