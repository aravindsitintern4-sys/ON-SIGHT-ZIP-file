@login @outReach_Event_setup
@hospital_master_New

Feature: Hospital master Actions

# HOSPITAL MASTER  
Scenario: Hospital Master actions 
	  And I click on hospital master option
	  Then I navigated to the hospital master page
	  Then edit and delete buttons should be disable initially
 
Scenario: New button in Hospital master
	 And I click New button in hospital master
	 Then new hospital creation popup should be displayed

#HOSPITAL NAME	
Scenario Outline: hospital name actions
	And I enter hospital name "<hospitalName>"
	And I click clear button
	
Examples:
         | hospitalName                    |
         | Aravind Eye Care - Virudhunagar |
         | Aravind Eye Care - Salem        |
         
Scenario: Empty credential for hospital name 
	And user clicks save button 
	Then hospital name Required alert should be appear
	And I click clear button

#HOSPITAL SHORT NAME	
Scenario Outline: Hospital Short Name  actions
	And I enter hospital short name "<hospitalShortName>"
	And I click clear button

Examples:
         | hospitalShortName |
         | Virudhunagar      |
         | Salem             |	
         
Scenario: Empty credential for hospital short name
	And user clicks save button 
	Then hospital short name Required alert should be appear
	And I click clear button

#HOSPITALTYPE 	
Scenario Outline: Hospital type  actions
	And I select hospital type "<hospitaltype>"
	And I click clear button

Examples:
         | hospitaltype       |
         | Vision Center      |
         | Secondary Hospital |	
         | Tertiary Hospital  |
	
Scenario: Empty credential for hospital type
	And user clicks save button 
	Then hospital type Required alert should be appear
	And I click clear button	
	
#ACTIVE STATUS ---> CHECK BOX	
Scenario: Active status checkbox validation in hospital master
    And I click active checkbox
	And I click clear button

# ADDRESS LINE 1
Scenario Outline: Address line actions
	And I enter address line "<address>"
	And I click clear button

Examples:
         | address                   |
         | abc street, Virudhunagar  |
         | east street, Salem-654321 |	
         
Scenario: Empty credential for Address
	And user clicks save button 
	Then address Required alert should be appear
	And I click clear button	
	
	
# TALUK ACTIONS	
Scenario Outline: Taluk Actions
	And I select citytaluk "<taluk>"
	And I click clear button

Examples:
         | taluk      |
         | JAMMIKUNTA |
         | DHANWADA   |	

	
Scenario: Empty credential for Taluk
	And user clicks save button 
	Then taluk Required alert should be appear
	And I click clear button	
	
# DISTRICT ACTIONS	
Scenario Outline: District Actions
	And I select district "<district>"
	And I click clear button

Examples:
         | district      |
         | DIBANG VALLEY |
         | BANSWARA      |	

	
Scenario: Empty credential for District
	And user clicks save button 
	Then district require alert should be appear
	And I click clear button
		
# STATE ACTIONS	
Scenario Outline: State Actions
	And I select state "<state>"
	And I click clear button

Examples:
         | state          |
         | ANDHRA PRADESH |
         | TAMIL NADU     |	

	
Scenario: Empty credential for State
	And user clicks save button 
	Then state Required alert should be appear
	And I click clear button	
	
# COUNTRY ACTIONS	
Scenario Outline: Country Actions
	And I select country "<country>"
	And I click clear button

Examples:
         | country   |
         | MAURITIUS |
         | INDIA     |	
         
# TELEPHONE NUMBER ACTIONS	
Scenario Outline: Telephone number Actions
	And I enter telephone number "<telephone>"
	And user clicks save button
	Then validation for Telephone No field
	And I click clear button

Examples:
         | telephone             |
         | 0000000000            |
         | 145785468646554654654 |	
         | hgsghvfasv12314       |
         | {}{}/.,/.,/;[];=-=    | 
		
# EMAIL ACTIONS	
Scenario Outline:  Actions
	And I enter email "<emailData>"
	And user clicks save button
	Then validation for Email field
	And I click clear button

Examples:
         | emailData          |
         | 0000000000         |
         | sabitha12          |	
         | hgsghvfasv12314    |
         | {}{}/.,/.,/;[];=-= |
         | sabitha@123        |
         | sabitha.com        |
         	
Scenario: Empty credential for Email
	And user clicks save button 
	Then email Required alert should be appear
	And I click clear button
	
# EXISTING HOSPITAL
Scenario: Existing hospital 
	And I enter hospital name "Aravind Eye Care - Vellore"
	And I enter hospital short name "VLR CAMP"
	And I select hospital type "Secondary Hospital"
	And I click active checkbox
	And I click active checkbox
	And I enter address line "abc street, Vellorer"
	And I select citytaluk "DHANWADA"
	And I select district "VIRUDHUNAGAR"
	And I select state "TAMIL NADU"
	And I select country "INDIA"
	And I enter telephone number "4345678901"
	And I enter email "sabitha123@gmail.com"
	And user clicks save button 
    Then "Hospital Name already exists." toast should be displayed
    And I click clear button

# VALID TEST DATA
Scenario: Valid test datas for hospital master
	And I enter hospital name "Aravind Eye Care - gtr"
	And I enter hospital short name "Gtr CAMP"
	And I select hospital type "Secondary Hospital"
	And I click active checkbox
	And I click active checkbox
	And I enter address line "abc street, CBE"
	And I select citytaluk "DHANWADA"
	And I select district "VIRUDHUNAGAR"
	And I select state "TAMIL NADU"
	And I select country "INDIA"
	And I enter telephone number "7589607412"
	And I enter email "aravind925@gmail.com"
	And user clicks save button 
	Then I navigated to the hospital master page
	Then edit and delete buttons should be disable initially	
	
Scenario: Navigate to User master page
	And I click on home
	And I click on master option
    And I navigated to the master page	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	