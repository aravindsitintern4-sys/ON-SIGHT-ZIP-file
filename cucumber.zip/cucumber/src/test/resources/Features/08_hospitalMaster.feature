#@login @outReach_Event_setup
@hospital_master_New

Feature: Hospital master Actions

# HOSPITAL MASTER  
Scenario: Hospital Master actions 
	  And user clicks on hospital master option
	  Then user navigated to the hospital master page
	  Then edit and delete buttons should be disable initially
 
Scenario: New button in Hospital master
	 And user clicks New button in hospital master
	 Then new hospital creation popup should be displayed

#HOSPITAL NAME	
Scenario Outline: hospital name actions
	And user enters hospital name "<hospitalName>"
	And user clicks clear button
	
Examples:
         | hospitalName                    |
         | Aravind Eye Care - Virudhunagar |
         | Aravind Eye Care - Salem        |
         
Scenario: Empty credential for hospital name 
	And user clicks save button 
	Then hospital name Required alert should be appear
	And user clicks clear button

#HOSPITAL SHORT NAME	
Scenario Outline: Hospital Short Name  actions
	And user enters hospital short name "<hospitalShortName>"
	And user clicks clear button

Examples:
         | hospitalShortName |
         | Virudhunagar      |
         | Salem             |	
         
Scenario: Empty credential for hospital short name
	And user clicks save button 
	Then hospital short name Required alert should be appear
	And user clicks clear button 

#HOSPITALTYPE 	
Scenario Outline: Hospital type  actions
	And user selects hospital type "<hospitaltype>"
	And user clicks clear button

Examples:
         | hospitaltype       |
         | Vision Center      |
         | Secondary Hospital |	
         | Tertiary Hospital  |
	
Scenario: Empty credential for hospital type
	And user clicks save button 
	Then hospital type Required alert should be appear
	And user clicks clear button 	
	
#ACTIVE STATUS ---> CHECK BOX	
Scenario: Active status checkbox validation in hospital master
    And user clicks active checkbox
	And user clicks clear button

# ADDRESS LINE 1
Scenario Outline: Address line actions
	And user enters address line "<address>"
	And user clicks clear button

Examples:
         | address                   |
         | abc street, Virudhunagar  |
         | east street, Salem-654321 |	
         
Scenario: Empty credential for Address
	And user clicks save button 
	Then address Required alert should be appear
	And user clicks clear button 	
	
	
# TALUK ACTIONS	
Scenario Outline: Taluk Actions
	And user selects citytaluk "<taluk>"
	And user clicks clear button

Examples:
         | taluk      |
         | JAMMIKUNTA |
         | DHANWADA   |	

	
Scenario: Empty credential for Taluk
	And user clicks save button 
	Then taluk Required alert should be appear
	And user clicks clear button	
	
# DISTRICT ACTIONS	
Scenario Outline: District Actions
	And user selects district "<district>"
	And user clicks clear button

Examples:
         | district      |
         | DIBANG VALLEY |
         | BANSWARA      |	

	
Scenario: Empty credential for District
	And user clicks save button 
	Then district require alert should be appear
	And user clicks clear button
		
# STATE ACTIONS	
Scenario Outline: State Actions
	And user selects state "<state>"
	And user clicks clear button

Examples:
         | state          |
         | ANDHRA PRADESH |
         | TAMIL NADU     |	

	
Scenario: Empty credential for State
	And user clicks save button 
	Then state Required alert should be appear
	And user clicks clear button	
	
# COUNTRY ACTIONS	
Scenario Outline: Country Actions
	And user selects country "<country>"
	And user clicks clear button

Examples:
         | country   |
         | MAURITIUS |
         | INDIA     |	
         
# TELEPHONE NUMBER ACTIONS	
Scenario Outline: Telephone number Actions
	And user enters telephone number "<telephone>"
	And user clicks save button
	Then validation for Telephone No field
	And user clicks clear button

Examples:
         | telephone             |
         | 0000000000            |
         | 145785468646554654654 |	
         | hgsghvfasv12314       |
         | {}{}/.,/.,/;[];=-=    | 
		
# EMAIL ACTIONS	
Scenario Outline:  Actions
	And user enters email "<emailData>"
	And user clicks save button
	Then validation for Email field
	And user clicks clear button

Examples:
         | emailData          |
         | 0000000000         |
         | sabitha12          |	
         | hgsghvfasv12314    |
         | {}{}/.,/.,/;[];=-= |
         | sabitha@123        |
         | sabitha.com        |
         	
Scenario: Empty credential for Email
	And user clicks save button 
	Then email Required alert should be appear
	And user clicks clear button	
	
# EXISTING HOSPITAL
Scenario: Existing hospital 
	And user enters hospital name "Aravind Eye Care - Vellore"
	And user enters hospital short name "VLR CAMP"
	And user selects hospital type "Secondary Hospital"
	And user clicks active checkbox
	And user clicks active checkbox
	And user enters address line "abc street, Vellorer"
	And user selects citytaluk "DHANWADA"
	And user selects district "VIRUDHUNAGAR"
	And user selects state "TAMIL NADU"
	And user selects country "INDIA"
	And user enters telephone number "4345678901"
	And user enters email "sabitha123@gmail.com"
	And user clicks save button 
    Then "Hospital Name already exists." toast should be displayed
    And user clicks clear button

# VALID TEST DATA
Scenario: Valid test datas for hospital master
	And user enters hospital name "Aravind Eye Care - gtr"
	And user enters hospital short name "Gtr CAMP"
	And user selects hospital type "Secondary Hospital"
	And user clicks active checkbox
	And user clicks active checkbox
	And user enters address line "abc street, CBE"
	And user selects citytaluk "DHANWADA"
	And user selects district "VIRUDHUNAGAR"
	And user selects state "TAMIL NADU"
	And user selects country "INDIA"
	And user enters telephone number "7589607412"
	And user enters email "aravind925@gmail.com"
	And user clicks save button 
	Then user navigated to the hospital master page
	Then edit and delete buttons should be disable initially	
	
Scenario: Navigate to User master page
	And user clicks on home
	And user clicks on master option
    And user navigated to the master page	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	