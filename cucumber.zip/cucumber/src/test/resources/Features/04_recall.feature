#@login @outReach_Event_setup
@recall 

Feature: Recall Patient Address details

Scenario: Click Registration actions
	When user clicks on Registration option
	Then patient should be navigated to the registration page
  
Scenario: Recall Vaildation with Empty credentials for OID
  When user clicks on Recall button
  Then recall popup should be displayed
  And user enters OID ""
  And user clicks on Submit button in recall
  Then Required alert should be appear in recall
  And user clicks on Cancel button in recall

#RECALL TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: OID field validation in Recall
  When user clicks on Recall button
  And user enters OID "<oid>"
  And user clicks on Submit button in recall
  Then user should see OID validation message "No data available for the given UID!"
  And user clicks on OK button

Examples:
  | oid           |
  | DD-00041-0029 |	
  | D00041-0029	  |
  | D-0004-0029	  |
  | D-00041-029	  |
  | 1-00041-0029  |	    


# VALID RECALL TEST DATAS

Scenario: Recall a patient

  When user clicks on Recall button
  Then recall popup should be displayed

  And user enters OID "C-00025-0064"
  
  And user clicks on Submit button in recall
  
  And user waits for "5" seconds
  #Then patient address details should be displayed
  
   #And user clicks on Cancel button in recall
   #Then user should be navigated to registration page
   
  And user clicks on Cancel button in registration 
  
  