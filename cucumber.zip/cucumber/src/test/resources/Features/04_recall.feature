#@login @outReach_Event_setup
@recall 

Feature: Recall Patient Address details

Scenario: Click Registration actions
	When I click on Registration option
	Then patient should be navigated to the registration page
  
Scenario: Recall Vaildation with Empty credentials for OID
  When I click on Recall button
  Then recall popup should be displayed
  And I enter OID ""
  And I click on Submit button in recall
  Then Required alert should be appear in recall
  And I click on Cancel button in recall

#RECALL TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: OID field validation in Recall
  When I click on Recall button
  And I enter OID "<oid>"
  And I click on Submit button in recall
  Then I should see OID validation message "No data available for the given UID!"
  And I click on OK button

Examples:
  | oid           |
  | DD-00041-0029 |	
  | D00041-0029	  |
  | D-0004-0029	  |
  | D-00041-029	  |
  | 1-00041-0029  |	    


# VALID RECALL TEST DATAS

Scenario: Recall a patient

  When I click on Recall button
  Then recall popup should be displayed

  And I enter OID "C-00025-0064"
  
  And I click on Submit button in recall
  
  And I wait for "5" seconds
  #Then patient address details should be displayed
  
   #And I click on Cancel button in recall
   #Then I should be navigated to registration page
   
  And I click on Cancel button in registration 
  
  