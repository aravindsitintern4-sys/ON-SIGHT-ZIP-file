#@login @outReach_Event_setup
@camp_summary_report

Feature: Camp summary report Workflow

Scenario: Camp summary report
	And user clicks on "Camp Summary" option
	Then popup "Camp Summary Reports" should be displayed

# NEGATIVE SCENARIO	
Scenario: Invalid From date actions
	 And I enter From date as "<fromDate>"
	 And I should see "To date cannot be less than from date" field error message
   	 
Examples:
	| fromDate   |
	| 00-00-0000 |
	| 31-12-2024 |
	| 01-04-3000 | 
	| 01-02-3000 |
	
# NEGATIVE SCENARIO	
Scenario: Invalid To date actions
	 And I enter To date as "<toDate>"
	 And I should see "To date cannot be less than from date" field error message
	  
Examples:
	| toDate       |
	| 00-00-0000   |
	| 31-12-2024   |
	| 01-03-2026   | 

# NEGATIVE SCENARIO	
Scenario: To date invalid action
	And I enter To date as "01-02-300000"
	And I should see "No event found across the time period" field error message
	And user waits for "5" seconds

Scenario: valid date
	And I enter From date as "01-04-2026"
	And I enter To date as "28-04-2026"

# NEGATIVE SCENARIO	
Scenario: Camp ID/ Place dropdown field with invalid datas
	And I select Camp id or place dropdown field invalid data "Mumbai"
	Then no items found message should be displayed in dropdown in reports
	And user waits for "2" seconds
	And user clicks close icon
	
Scenario: Camp ID/ Place dropdown field with valid camp ID data
	And user clicks on "Camp Summary" option
	And I select Camp id or place dropdown field "25"
	And user waits for "2" seconds

Scenario: Camp ID/ Place dropdown field with valid camp place datas
	And I select Camp id or place dropdown field "Pondicherry"
	And user waits for "2" seconds
	And user clicks close icon
	
Scenario: Verify Select All checkbox in Camp dropdown
    And user clicks on "Camp Summary" option
    Given I open the Camp dropdown
    And I click on Select All checkbox
    Then all dropdown options should be selected
    And user clicks close icon

Scenario: Camp ID/ Place dropdown unselect
	And user clicks on "Camp Summary" option
    Given I open the Camp dropdown
    And I click on Select All checkbox
	And I select Camp id or place dropdown field "Pondicherry"
	And user waits for "2" seconds
	And user clicks close icon
	
Scenario: Submit button action
	And user clicks on "Camp Summary" option
	And I select Camp id or place dropdown field "25"
	And I click "Submit" button in camp summary
	Then report table should be displayed
	
Scenario: Toggle button actions
	And I click "Summary" button in camp summary
	Then report table should be displayed
	And I click "Age / Gender" button in camp summary
	Then report table should be displayed     

Scenario: Export excel datas for summary
 	And I click "Summary" button in camp summary
 	And user clicks on Export button
 	#Then file "camp" should be downloaded successfully
    Then file should be downloaded successfully

Scenario: Export excel datas for Age or Gender
 	And I click "Age / Gender" button in camp summary
 	And user clicks on Export button
 	#Then file "camp_age" should be downloaded successfully
    Then file should be downloaded successfully
    And user clicks close icon
    And user clicks on home

          
 



           