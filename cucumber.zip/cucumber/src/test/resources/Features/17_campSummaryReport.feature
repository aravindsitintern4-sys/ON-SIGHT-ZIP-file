@login @outReach_Event_setup
@camp_summary_report

Feature: Camp summary report Workflow

Scenario: Camp summary report
	And user clicks on "Camp Summary" option
	Then user is navigated to "Camp Summary Reports" page

# NEGATIVE SCENARIO	
Scenario: Invalid From date actions
	 And I enter From date as "<fromDate>"
	 And I should see "To date cannot be less than from date" field error message
	 
Examples:
	| fromDate   |
	| 00-00-0000 |
	| 31-12-2024 |
	| 01-04-3000 |
	
	

