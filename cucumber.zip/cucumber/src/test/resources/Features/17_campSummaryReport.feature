@login @outReach_Event_setup
@camp_summary_report

Feature: Camp summary report Workflow


	
Scenario: Submit button action
	And user clicks on "Camp Summary" option
	And I select Camp id or place dropdown field "25"
	And I click "Submit" button in camp summary
	Then report table should be displayed
	
Scenario: Toggle button actions
	And I click "Summary" button in camp summary
	Then report table should be displayed
	And I click "Age / Gender" button in camp summary
	Then report table should be displayed     

Scenario: Export excel datas for summary
 	And I click "Summary" button in camp summary
 	And user clicks on Export button
 	Then file "camp" should be downloaded successfully
    #Then file should be downloaded successfully

Scenario: Export excel datas for Age or Gender
 	And I click "Age / Gender" button in camp summary
 	And user clicks on Export button
 	Then file "camp_age" should be downloaded successfully
    #Then file should be downloaded successfully
    And user clicks close icon
    And user clicks on home

          
 



           