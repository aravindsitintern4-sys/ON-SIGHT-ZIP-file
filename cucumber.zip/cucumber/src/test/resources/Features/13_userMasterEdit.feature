#@login @outReach_Event_setup 
@user_master_EditUser

Feature: User Master Edit Workflow

# NEW BUTTON 
Background: 
	Then user navigated to the user master page
	And user clears search box

#EDIT WORKFLOW

Scenario: Edit button workflow invalid Test datas in user
    And user enters id in search bar "1000"
    Then no data found messege should be displayed
    
Scenario: Edit button workflow invalid Test datas in user
    And user enters data in search bar "india"
    Then no data found messege should be displayed
    
Scenario Outline: Edit workflow using Valid datas in user Edit
  When user enters id in search bar "<datas>"
  Then details for id "<datas>" should be displayed
  When user selects checkbox for data "<datas>" in table
  Then selected checkbox data should be displayed "<datas>"
  Then edit and delete and reset password buttons should be enabled and new button should be disabled
  When user clicks edit button
  Then "User Master" existing details should be displayed
  And user clicks cancel button
  
 Examples:
      | datas    |
      | 156      |
      | 3        |
      | sabitha  |
      
Scenario: Edit user details
  When user enters id in search bar "156"
  Then details for id "156" should be displayed
  When user selects checkbox for data "156" in table
  Then selected checkbox data should be displayed "156"
  Then edit and delete and reset password buttons should be enabled and new button should be disabled
  When user clicks edit button
  Then "User Master" existing details should be displayed
  #EDIT EMAIL ID
  And user enters email "sabitha123@gmail.com" in user
  And user selects alias "Ms" dropdown
  And user clicks update button
  Then "User updated successfully!" toast should be displayed
  And user waits for "3" seconds	


# DELETE BUTTON  
Scenario: Delete workflow with Confirmation Cancel in user master
  When user enters id in search bar "183"
  Then details for id "183" should be displayed
  When user selects checkbox for data "183" in table
  Then selected checkbox data should be displayed "183"
  Then edit and delete and reset password buttons should be enabled and new button should be disabled
  And user clicks on delete button
  And user clicks on Confirmation Cancel
  And user waits for "3" seconds
  
Scenario: Delete workflow with Confirmation Ok in user master
  When user enters id in search bar "210"
  Then details for id "210" should be displayed
  When user selects checkbox for data "210" in table
  Then selected checkbox data should be displayed "210"
  Then edit and delete and reset password buttons should be enabled and new button should be disabled
  And user clicks on delete button
  And user clicks on Confirmation ok 
  Then "User deleted successfully" toast should be displayed
  When user enters id in search bar "210"
  Then no data found messege should be displayed
  And user waits for "3" seconds	
 




