#@login @outReach_Event_setup
@referral_advice_clinical_records

Feature: Referral advice workflow in clinical records
		
Scenario: Referral advice workflow
	And I click "Referral" label option
	Then popup "Referral" should be displayed
			
# HOSPITAL NAME 	
Scenario Outline: Hospital Name dropdown
	And I select hospital name "<hospitalName>" dropdown 
	And I click "Clear" button in referral advice
	And I click "Ok" button in window 
	
Examples:
     | hospitalName                       |
     | Aravind Vision Center-Thammampatti |
     | Aravind Vision Center-Thalaivasal  |
     | Aravind Eye Hospital - Salem       |

# NEGATIVE SCENARIO
Scenario: Hospital Name dropdown invalid in referral advice
	And I select hospital name "Aravind eye hospital - Mumbai" dropdown 
	Then no items found message should be displayed in dropdown
	And I click "Clear" button in referral advice
	
Scenario: Hospital Name dropdown empty in referral
	And I click "Save" button in referral advice
	Then hospital name Required alert should be appear referral advice
	    
# CLINIC NAME 	
Scenario Outline: Clinic Name dropdown valid actions in referral advice
	And I select hospital name "Aravind Eye Hospital - Salem" dropdown 
	And I select clinic name "<clinicName>" dropdown 
	And I click "Clear" button in referral advice
	And I click "Ok" button in window 
	
Examples:
     | clinicName |
     | IOL        |
     | Retina     |

# NEGATIVE SCENARIO
Scenario: Clinic Name dropdown invalid in referral advice
	And I select hospital name "Aravind Eye Hospital - Salem" dropdown 
	And I select clinic name "Dental" dropdown 
	Then no items found message should be displayed in dropdown	
	And I click "Clear" button in referral advice
    And I click "Ok" button in window
	
Scenario: Clinic Name dropdown empty in referral advice
	And I select hospital name "Aravind Vision Center-Thalaivasal" dropdown 
	And I click "Save" button in referral advice
	Then clinic name Required alert should be appear referral advice 
	And I click "Clear" button in referral advice
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window 

# REASON FOR REFERRAL 	
Scenario Outline: Reason for Referral dropdown valid actions
 	And I select hospital name "Aravind Vision Center-Thalaivasal" dropdown
 	And I select clinic name "Unit 1" dropdown
	And I select reason for referral "<reason>" dropdown 
	
Examples:
     | reason             |
     | Routine Referral   |
     | For Investigations |

Scenario: Reason for referral dropdown empty
	And I click "Clear" button in referral advice
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window
	And I select hospital name "Aravind Vision Center-Thalaivasal" dropdown
 	And I select clinic name "Unit 1" dropdown
	And I click "Save" button in referral advice
	Then reason for referral Required alert should be appear referral advice
	And I click "Clear" button in referral advice
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window 
	   
Scenario: Remarks in referral advice
	And I enter remarks "need surgery"
	And I click "Clear" button in referral advice
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window

Scenario: Emergency check box in referral advice
	And I click checkbox
	And I click "Clear" button in referral advice
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window	
  
# VALID TEST DATAS WITH SAVE BUTTON
Scenario: valid actions with Save button
	And I select hospital name "Aravind Eye Hospital - Salem" dropdown 
 	And I select clinic name "IOL" dropdown	
	And I select reason for referral "Routine Referral" dropdown 
	And I enter remarks "need surgery"
	And I click checkbox
	And I click "Save" button in referral advice
	Then referral advice summary should be displayed	
	
# VALID TEST DATAS WITH SAVE AND PRINT BUTTON
Scenario: valid actions with save and print button
	And I click "Referral" label option
	Then popup "Referral" should be displayed
	And I select hospital name "Aravind Eye Hospital - Salem" dropdown 
 	And I select clinic name "Retina" dropdown	
	And I select reason for referral "Routine Referral" dropdown 
	And I enter remarks "need surgery"
	And I click checkbox
	And I click "Update & Print" button in referral advice
	And I click "Close" button in preview
    Then referral advice summary should be displayed

	
# VALID TEST DATAS
Scenario: Disabled button test datas after save
	And I click "Referral" label option
	Then popup "Referral" should be displayed
	And I click "Update" button in referral advice
	Then "Update" button should be disabled
	And I click close icon
	#And I click "Clear" button in referral advice
	#Then popup "Confirm" should be displayed
	#And I click "Ok" button in window

# REFERRAL SUMMARY PRINT 
Scenario: Referral summary print icon
	And I click referral advice summary print icon
	And I click "Print" button in preview
	
# REFERRAL SUMMARY PRINT CLOSE BUTTON
Scenario: Referral summary Print icon close button
	And I click referral advice summary print icon
	And I click "Close" button in preview
	Then referral advice summary should be displayed
	
# REFERRAL SUMMARY INFO ICON
Scenario: Referral summary info icon
	When I hover referral advice summary info icon
	Then patient info "sabitha" should be displayed
	And I wait for "2" seconds

# REFERRAL SUMMARY DELETE ICON
Scenario: Referral summary delete icon	
	And I click referral advice summary delete icon
	Then popup "Confirm" should be displayed
	And I click "Cancel" button in window
	Then referral advice summary should be displayed	
	
Scenario: Referral summary delete icon	
	And I click referral advice summary delete icon
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window
	Then referral advice summary should be not displayed
	

	
	
	
	







		
