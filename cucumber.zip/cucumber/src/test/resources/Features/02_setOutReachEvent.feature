@login 
@outReach_Event_setup 
Feature: Outreach Event Setup

Scenario: Invalid Set up an outreach event
  Given outreach event setup page
  And I wait for "2" seconds
  When I select hospital "Aravind Eye Hospital-Madurai" 
  And I click on the Save button
  #Then error message should be displayed Outreach Event setup


Scenario: Valid Set up an outreach event
  Given outreach event setup page
  #And I select eventId "41" 
  And I select eventId "1" 
  And I click on the Save button
  Then I navigated to the dashboard page
  
  #When I click Cancel button
  #Then I navigated to the login page
  
