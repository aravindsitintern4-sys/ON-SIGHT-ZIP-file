@login 
@outReach_Event_setup 
Feature: Outreach Event Setup

#Scenario: Invalid Set up an outreach event
 # Given user is on the outreach event setup page
  #When user selects hospital "Aravind Eye Hospital - Salem" 
  #And user clicks on the Save button
 # Then error message should be displayed Outreach Event setup


Scenario: Valid Set up an outreach event
  Given user is on the outreach event setup page
  #And user selects eventId "41" 
  And user selects eventId "25" 
  And user clicks on the Save button
  Then user should be navigated to the dashboard page
  
  #When user clicks Cancel button
  #Then user should navigated to the login page
  
