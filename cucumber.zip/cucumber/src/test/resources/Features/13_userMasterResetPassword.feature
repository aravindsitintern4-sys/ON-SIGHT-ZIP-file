#@login @outReach_Event_setup 
@user_master_resetPassword

Feature: User Master Delete Workflow

#Scenario: user master actions
	#And user clicks on user master option
	#Then user navigated to the user master page
	#And user clears search box 
 
#RESET PASSWORD
Scenario: Reset password Invalid and valid actions
      And user waits for "5" seconds
      When user enters id in search bar "174"
	  Then details for id "174" should be displayed
	  When user selects checkbox for data "174" in table
	  Then selected checkbox data should be displayed "174"
	  Then edit and delete and reset password buttons should be enabled and new button should be disabled
	  And user clicks on reset password button
	  Then "Password reset successfully!" toast should be displayed
	  And user clicks on Logout 
	  Then user is navigated into login page
	  And user enters username "174" and password "Pass@123"
	  And clicks on login button  
	  Then user is navigated to reset password page 
	  #EMPTY FIELD
	  And user enters old password ""
	  And user enters new password ""
	  Then old password Required alert should be appear  	
	  And user enters confirm password ""
	  Then new password Required alert should be appear
	  And user enters old password ""
	  Then confirm password Required alert should be appear
	  #INVALID PASSWORDS
	  And user enters new password "abitha@456"
	  And user enters confirm password "thishf@123"
	  Then alert messege for new password should be displayed
	  And user enters old password "qwerrd@456"
	  Then alert messege for confirm password should be displayed
	  And user enters new password "Sabitha@456"
	  And user enters confirm password "Sabitha@456"
	  And user enters new password "Sabitha@456"
	 # Then alert messege for old password should be displayed
	 #VALID PASSWORDS
	  And user enters old password "Pass@123"
	  And user enters new password "Banmlsg@456"
      And user enters confirm password "Banmlsg@456"
	  And user clicks save button in reset
	  And user clicks save button in reset
	  And user enters username "174"
	  And user enters password "Banmlsg@456"
	  And user waits for "3" seconds 
	  And clicks on signin button
	  And user selects eventId "25" 
	  And user clicks on the Save button
      Then user should be navigated to the dashboard page
	