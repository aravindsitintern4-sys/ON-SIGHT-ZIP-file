@login  @outReach_Event_setu
@reprint
Feature: Reprint patient details

Scenario: Click Registration actions
	When I click on Registration option
	Then patient should be navigated to the registration page

# NEGATIVE SCENARIO
Scenario Outline: OID field validation in Reprint for invalid formats
  And I click "Reprint" button
  Then reprint popup should be displayed
  And I enter OID "<oid>" in reprint
  And I click on Search icon in edit
  Then I should see OID validation message "No data available for the given UID!"
  And I click "Ok" button


Examples:
  | oid             |
  | DD-00041-0029   |
  | D00041-0029     |
  | D-0004-0029     |
  | D-00041-029     |
  | 1-00041-0029    |
   
Scenario: Reprint Validation with Empty Oid credentials
  And I click "Reprint" button
  Then reprint popup should be displayed
  And I select patient type "New"
  Then date field should be disable
  And I click on Search icon in edit
  And Required alert "Required." should be appear in reprint
  And I click "Ok" button
 
Scenario: Reprint Validation with New patient credentials
  And I click "Reprint" button
  Then reprint popup should be displayed
  And I select patient type "New"
  Then date field should be disable
  # GIVE TODAY REGISTERED OID
  And I enter OID "C-00001-0225" in reprint
  And I click on Search icon in edit
  And I click "Submit" button from popup
  Then print preview should be displayed
  And I click "Close" button from popup
   And I click "Cancel" button from popup

Scenario: Reprint Validation with Review patient credentials
  And I click "Reprint" button
  Then reprint popup should be displayed
  And I select patient type "Review"
  And I wait for "1" seconds
  # GIVE TODAY REGISTERED OID AND CHANGE THE DATE(TODAY)
  And I enter date "11-06-2026" in reprint
  And I enter OID "C-00001-0225" in reprint
  And I click on Search icon in edit
  And I wait for "1" seconds
  And I click "Submit" button from popup
  And I wait for "1" seconds
  Then print preview should be displayed
  And I wait for "1" seconds
  And I click "Close" button from popup
  And I click "Cancel" button from popup
 
Scenario: Reprint Validation with Review patient with old OID credentials
  And I click "Reprint" button
  Then reprint popup should be displayed
  And I select patient type "Review"
  And I enter date "10-06-2026" in reprint
  And I enter OID "D-00041-0036" in reprint
  And I click on Search icon in edit
  And error message "Patients not registered today cannot be reprinted." should be displayed in reprint
  And I click "Cancel" button from popup

Scenario: Reprint Validation with  Previous day OID for New patient
  And I click "Reprint" button
  Then reprint popup should be displayed
  And I select patient type "New"
  Then date field should be disable
  And I enter OID "D-00041-0030" in reprint
  And I click on Search icon in edit
  And error message "Patients not registered today cannot be reprinted." should be displayed in reprint
  Then submit button should be disable in reprint
  And I click "Cancel" button from popup
  And I click "Cancel" button


