@login @outReach_Event_setup
@systemic_history_clinical_records

Feature: Systemic History workflow in clinical records
		
Scenario: Systemic history navigation flow
	And I click "Systemic History" label option
	Then popup "Systemic History" should be displayed

#Scenario: clear button after save 
	#And I wait for "1" seconds
	#And I click clear button in history and complaints
    #And I click "Ok" button in window
	
#Scenario: Initially clear button should disable
    #Then "Clear" button should be disable

Scenario: Empty fields Systemic History
	And I wait for "1" seconds
    And I select "Asthma:" label for "No" option	
    And I click save or update button in examination
    Then Mandatory alert should be displayed
    
Scenario: Systemic history valid action for option YES - Cardiac
	And I select "Cardiac:" label for "Yes" option	
	And I set duration value "1" in history
    And I set duration type "Year" in history
    And I enter "Cardiac:" label remarks as "medication"

Scenario: Systemic history valid action for option YES - Diabetes
	And I select "Diabetes:" label for "Yes" option	
	And I set duration value "12" in history
    And I set duration type "Week" in history
    And I enter "Diabetes:" label remarks as "medication"	
    
Scenario: Systemic history valid action for option YES - Asthma
    And I select "Asthma:" label for "Yes" option	
    And I wait for "1" seconds
	And I set duration value "10" in history
    And I set duration type "Day" in history
    And I enter "Asthma:" label remarks as "medication"
 
Scenario: Systemic history valid action for option YES - Epilepsy/Seizures
    And I select "Epilepsy/Seizures:" label for "Yes" option	
	And I set duration value "1" in history
    And I set duration type "Month" in history
    And I enter "Epilepsy/Seizures:" label remarks as "medication"

Scenario: Systemic history valid action for option YES - Hypertension
    And I select "Hypertension:" label for "Yes" option	
	And I set duration value "12" in history
    And I set duration type "Day" in history
    And I enter "Hypertension:" label remarks as "medication"
    
Scenario: Systemic history valid action for option YES - Other Allergies
	And I select "Other Allergies:" label for "Yes" option
	And I enter other allergy detail "Dust Allergy"                  
	
Scenario: Systemic history valid action for option YES - Drug Allergies
	And I select "Drug Allergies:" label for "Yes" option
	And I select drug allergy "ACTIVISION CAPS"   
	
Scenario: Systemic history valid action for option NO
	And I select "Asthma:" label for "No" option
	And I select "Cardiac:" label for "No" option
 	And I select "Diabetes:" label for "No" option
 	And I select "Epilepsy/Seizures:" label for "No" option
 	And I select "Hypertension:" label for "No" option	
 	And I select "Diabetes:" label for "No" option
    And I select "Other Allergies:" label for "No" option   
 	And I select "Drug Allergies:" label for "No" option
 	And I wait for "1" seconds

Scenario: Save action in history
    And I wait for "1" seconds
    And I click save or update button in examination
	Then history summary should be displayed
	 
Scenario: History info icon
	When I hover history summary info icon
	Then "Systemic History : Ms.sabitha" info is displayed
	And I wait for "2" seconds
	
	
	
	

	
	
	
	
	
	
	
	