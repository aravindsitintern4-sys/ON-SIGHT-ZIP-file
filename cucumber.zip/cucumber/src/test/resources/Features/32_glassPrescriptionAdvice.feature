#@login @outReach_Event_setup
@glass_Prescription_advice_clinical_records

Feature: Glass Prescription Advice workflow in clinical records
				
Scenario: Glass Prescription Advice workflow
	And I wait for "5" seconds
	And I click "GP" button
	Then popup "Glass Prescription" should be displayed

Scenario: Initial GP summary inside Pop up
	Then refraction glass prescription summary should be displayed
	
Scenario: instruction in GP advice
    And I select label as "Instruction:" and option as "Near Vision Only" in GP
	And I select label as "Instruction:" and option as "Distance Vision Only" in GP
	And I select label as "Instruction:" and option as "Constant Wear" in GP
	And I select label as "Instruction:" and option as "Vocational Use" in GP

Scenario: Advice in GP advice
	And I select label as "Advice:" and option as "Advise GP" in GP
	And I select label as "Advice:" and option as "Continue Same PG" in GP

Scenario: button actions in GP
	And I click "Clear" button in GP
	Then popup "Confirm" should be displayed
	And I click "Cancel" button in window
	And I click "Save & Print" button in GP
	And I click "Print" button in preview
	
# GP SUMMARY PRINT 
Scenario: GP summary print icon
	And I click GP advice summary print icon
	And I click "Print" button in preview
	
# GP SUMMARY PRINT CLOSE BUTTON
Scenario: GP summary Print icon close button
	And I click GP advice summary print icon
	And I click "Close" button in preview
	Then GP advice summary should be displayed
	
# GP SUMMARY INFO ICON
Scenario: GP summary info icon
	When I hover GP advice summary info icon
	And I wait for "2" seconds

Scenario: Click refraction after GP saved
	And I click "Refraction" label option
	Then "Please remove the Glass Prescription before adding Refraction." toast should be displayed
	
# GP SUMMARY DELETE ICON
Scenario: GP summary delete icon with cancel delete action
	And I click GP advice summary delete icon
	Then popup "Confirm" should be displayed
	And I click "Cancel" button in window
	Then GP advice summary should be displayed	
	
Scenario: GP summary delete icon	
	And I click GP advice summary delete icon
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window
	Then GP advice summary should be not displayed
	
Scenario: Valid Test datas Final GP module
	And I click "GP" button
	Then refraction glass prescription summary should be displayed
	And I select label as "Advice:" and option as "Advise GP" in GP
	And I click "Save" button in GP
	Then GP advice summary should be displayed
	

  
              