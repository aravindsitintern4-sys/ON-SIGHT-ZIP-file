#@login @outReach_Event_setup
@glass_Prescription_advice_clinical_records

Feature: Glass Prescription Advice workflow in clinical records
				
Scenario: Glass Prescription Advice workflow
	And I wait for "5" seconds
	And I click "GP" button
	Then popup "Glass Prescription" should be displayed

Scenario: Initial GP summary inside Pop up
	Then refraction glass prescription summary should be displayed
	
Scenario: instruction in GP advice
    And I select label as "Instruction:" and option as "Near Vision Only" in GP
	And I select label as "Instruction:" and option as "Distance Vision Only" in GP
	And I select label as "Instruction:" and option as "Constant Wear" in GP
	And I select label as "Instruction:" and option as "Vocational Use" in GP

Scenario: Advice in GP advice
	And I select label as "Advice:" and option as "Advise GP" in GP
	And I select label as "Advice:" and option as "Continue Same PG" in GP

Scenario: button actions in GP
	And I click "Clear" button in GP
	Then popup "Confirm" should be displayed
	And I click "Cancel" button in window
	And I click "Save & Print" button in GP
	And I click "Print" button in preview
	
# GP SUMMARY PRINT 
Scenario: GP summary print icon
	And I click GP advice summary print icon
	And I click "Print" button in preview
	
Scenario: GP summary print icon but Printer is not connected
	And I click GP advice summary print icon
	And I click "Print" button in preview
	And "Printer not reachable" toast should be displayed
	
# GP SUMMARY PRINT CLOSE BUTTON
Scenario: GP summary Print icon close button
	And I click GP advice summary print icon
	And I click "Close" button in preview
	Then GP advice summary should be displayed

Scenario: Click refraction after GP saved
	And I click "Refraction" label option
	Then "Please remove the Glass Prescription before adding Refraction." toast should be displayed
	And I wait for "3" seconds
	
# GP SUMMARY DELETE ICON
Scenario: GP summary delete icon with cancel delete action
	And I click trash icon in "Glass Prescription"
	Then popup "Confirm" should be displayed
	And I click "Cancel" button in window
	Then GP advice summary should be displayed	
	
Scenario: GP summary delete icon	
	And I click trash icon in "Glass Prescription"
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window
	Then GP advice summary should be not displayed
	
Scenario: Valid Test datas Final GP module
	And I click "GP" button
	Then refraction glass prescription summary should be displayed
	And I select label as "Advice:" and option as "Advise GP" in GP
	And I click "Save" button in GP
	And "Saved successfully" toast should be displayed
	Then GP advice summary should be displayed
	And I wait for "3" seconds
	
# GP SUMMARY INFO ICON
Scenario: GP summary info icon
	When I hover GP advice summary info icon
	And I wait for "2" seconds
	
#COUNSELLING

#NEGATIVE SCENARIO
Scenario: Counselling initial link Confirmed GP validation for button diable
	And I click "Glass Prescription" link counselling
    Then popup "GP Counselling" should be displayed
    And I wait for "1" seconds
	Then "Save & Print" button should be disable
	Then "Save" button should be disable
	Then "Clear" button should be disable

Scenario: Counselling initial link Confirmed in GP Counselling
	And I wait for "1" seconds
	And I select label as "Glass Prescription:" and option as "Counselling Done" in surgery advice
	And I click "Save" button for new counselling
	And "Glass prescription counselling updated" toast should be displayed
	And I wait for "2" seconds
 
# GP SUMMARY INFO ICON AFTER COUNSELLING
Scenario: GP summary info icon after counselling
	When I hover GP advice summary info icon
	And I wait for "2" seconds 


              