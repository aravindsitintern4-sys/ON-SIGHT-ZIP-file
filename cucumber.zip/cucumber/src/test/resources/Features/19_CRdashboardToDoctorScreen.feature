@login @outReach_Event_setup
@CR_dashboard_doctor_screen_navigation

Feature: Clinical Records Dashboard to Doctor screen page navigation actions

# CLINICAL RECORDS DASHBOARDPAGE TO DOCTOR SCREEN ACTIONS (FILTER THE PATIENT AND ENTER PIN ACTIONS)

#Scenario: Report view icon
	#And user clears search box
	#When user enters id in search bar "lkjh"
	#And user waits for "2" seconds
	#And user clicks report view icon
	#And user waits for "2" seconds
	#And user clicks close button common

#Scenario: No patient found
	#And user clears search box
	#When user enters id in search bar "jdhjscgvhjcvcjgcj"
	#Then "No patient found" found messege should be displayed

#Scenario: Reset buttons in Enter PIN popup
	#And user clears search box
	#When user enters id in search bar "lkjh"
    #And user clicks filtered option 
    #Then popup "Enter PIN" should be displayed
    #And user waits for "2" seconds
    #And user enters pin "97"
    #And user enters pin "Reset"
    #And user waits for "2" seconds
    #And user enters pin "981"
    #Then error message "Invalid PIN. Please try again" should be displayed  
    #And user clicks close button

#Scenario: Delete buttons in Enter PIN popup
	#And user clears search box
	#When user enters id in search bar "lkjh"
    #And user clicks filtered option
    #Then popup "Enter PIN" should be displayed
    #And user waits for "2" seconds
    #And user enters pin "9"
    #And user enters pin "Delete"
    #And user enters pin "981"
    #Then error message "Invalid PIN. Please try again" should be displayed  
    #And user clicks close button

#Scenario: Invalid Pin 
	#And user clears search box	
	#And user waits for "2" seconds
	#When user enters id in search bar "lkjh"
    #And user clicks filtered option
    #Then popup "Enter PIN" should be displayed
    #And user waits for "2" seconds
    #And user enters pin "973"
    #Then error message "Invalid PIN. Please try again" should be displayed 
    #And user clicks close button
       
Scenario: Valid Test datas for navigation for doctor screen
 	And user clears search box 
 	And user waits for "2" seconds
	When user enters id in search bar "Jewopfg"
    And user clicks filtered option
    Then popup "Enter PIN" should be displayed
    And user enters pin "548"
    Then user navigated to the doctor screen page
    
    
    