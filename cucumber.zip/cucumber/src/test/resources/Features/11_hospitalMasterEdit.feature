@login @outReach_Event_setup 
@Hospital_master_Edit

Feature: Hospital Master Edit Workflow

# NEW BUTTON 
Background:
	Then I navigated to the hospital master page
	And I clear search box
		
#EDIT WORKFLOW
Scenario: Edit button workflow invalid Test datas in hospital master
    And I enter id in search bar "1000"
    Then no data found messege should be displayed
    
Scenario: Edit button workflow invalid Test datas in hospital master
    And I enter data in search bar "india"
    Then no data found messege should be displayed
    
Scenario Outline: Edit workflow using Valid datas in hospital Edit
  When I enter id in search bar "<datas>"
  Then details for id "<datas>" should be displayed
  When I select checkbox for data "<datas>" in table
  Then selected checkbox data should be displayed "<datas>"
  Then edit and delete buttons should be enabled and new button should be disabled
  When I click edit button
  Then hospital edit popup with existing details should be displayed  
  And I click cancel button
  
 Examples:
      | datas                               |
      | 16                                  |
      | 22                                  |
      | Aravind Eye Hospital - Virudhunagar |
      
Scenario: Edit user details
  When I enter id in search bar "22"
  Then details for id "22" should be displayed
  When I select checkbox for data "22" in table
  Then selected checkbox data should be displayed "22"
  Then edit and delete buttons should be enabled and new button should be disabled
  When I click edit button
  Then hospital edit popup with existing details should be displayed 
  #EDIT EMAIL ID
  And I enter email "aravindvnr123@aravind.com"
  And I click update button
  
 # DELETE BUTTON 
Scenario: Delete workflow with Confirmation Cancel in hospital master
  When I enter id in search bar "26"
  Then details for id "26" should be displayed
  When I select checkbox for data "26" in table
  Then selected checkbox data should be displayed "26"
  Then edit and delete buttons should be enabled and new button should be disabled
  And I click on delete button
  And I click on Confirmation Cancel
  
Scenario: Delete workflow with Confirmation Ok in hospital master
  When I enter id in search bar "Aravind Eye Hospital - mno"
  Then details for id "Aravind Eye Hospital - mno" should be displayed
  When I select checkbox for data "Aravind Eye Hospital - mno" in table
  Then selected checkbox data should be displayed "Aravind Eye Hospital - mno"
  Then edit and delete buttons should be enabled and new button should be disabled
  And I click on delete button
  And I click on Confirmation ok  
  When I enter id in search bar "Aravind Eye Hospital - mno"
  Then no data found messege should be displayed
  
Scenario: Navigate to OutReach event master Edit actions
	And I click on home
	And I click on master option
    And I navigated to the master page	
    And I click on outReach event master option
    Then I navigated to the outreach event master page
    Then edit and delete buttons should be disable initially