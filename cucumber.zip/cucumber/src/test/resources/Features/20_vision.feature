#@login @outReach_Event_setup
@vision_clinical_records

Feature: Vision workflow in clinical records
    
Background: 
		Then user navigated to the doctor screen page 
		
Scenario: vision workflow
	And user clicks "Vision" label option
	Then popup "Vision" should be displayed

Scenario Outline: Vision chart dropdown
	And user selects vision chart "<visiondata>" dropdown
		
Examples:
      | visiondata                |
      | Chart Based VA            |
      | Red Reflex Test           |
      | Fixation and Following    |
      | Preferential Looking Test |
	    
# AUTOMATION HOLD     
#  CHART BASED VA 
Scenario: Chart based VA selection actions (Clear and save)
	And user selects vision chart "Chart Based VA" dropdown
	And user selects RE "6/6" and LE "6/6" in UCVA dropdown
	And user selects RE "6/6" and LE "6/6" in UCVAph dropdown
	And user clicks "Clear" button in vision
	And user selects RE "6/6" and LE "6/6" in UCVA dropdown
	And user selects RE "6/6" and LE "6/6" in UCVAph dropdown
	And user clicks "Save" button in vision	

#RED REFLEX TEST 	
Scenario: Red Reflex Test selection valid action
	And user clicks "Vision" label option
	And user selects vision chart "Red Reflex Test" dropdown
	And user clicks "Continue" button in window
	And user clicks "Normal" flex button for "RE"
	And user clicks "Abnormal" flex button for "LE"
	And user clicks "Update" button in vision
	
# FIXATION AND FOLLOWING
Scenario: Fixation and Following selection valid action
	And user clicks "Vision" label option
	And user selects vision chart "Fixation and Following" dropdown    
	And user clicks "Continue" button in window  
	And user clicks "Abnormal" flex button for "RE"
	And user clicks "Normal" flex button for "LE"
	And user clicks "Update" button in vision

# PREFERENTIAL LOOKING TEST 
Scenario: Preferential Looking Test selection valid action
	And user clicks "Vision" label option
	And user selects vision chart "Preferential Looking Test" dropdown
	And user clicks "Continue" button in window  
	And user selects method "Matching Cards" dropdown
	And user clicks "Normal" flex button for "RE"
	And user clicks "Abnormal" flex button for "LE" 
	And user clicks "Update" button in vision


Scenario: Red Reflex Test selection valid Delete action
	And user clicks "Vision" label option
	And user selects vision chart "Red Reflex Test" dropdown
	And user clicks "Continue" button in window
	And user clicks "Normal" flex button for "RE"
	And user clicks "Abnormal" flex button for "LE"
	And user clicks "Delete" button in vision
	Then popup "Confirm" should be displayed
	And user clicks "Ok" button in window    
	
# FINAL VALID VISION TEST DATAS
Scenario: Chart based VA selection valid actions
	And user clicks "Vision" label option
	And user selects vision chart "Chart Based VA" dropdown
	And user selects RE "6/6" and LE "6/6" in UCVA dropdown
	And user selects RE "6/6" and LE "6/6" in UCVAph dropdown
	And user clicks "Save" button in vision
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	