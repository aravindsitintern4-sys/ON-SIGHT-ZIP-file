@login @outReach_Event_setup
@recall 

Feature: Recall Patient Address details

Scenario: Click Registration actions
	When I click on Registration option
	Then patient should be navigated to the registration page
  
Scenario: Recall Vaildation with Empty credentials for OID
  And I click "Recall" button
  Then recall popup should be displayed
  And I enter OID ""
  And I click "Submit" button from popup
  Then Required alert should be appear in recall
  And I click "Cancel" button from popup

#RECALL TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: OID field validation in Recall
  And I click "Recall" button
  And I enter OID "<oid>"
  And I click "Submit" button from popup
  Then I should see OID validation message "No data available for the given UID!"
  And I click "Ok" button from popup

Examples:
  | oid           |
  | DD-00041-0029 |	
  | D00041-0029	  |
  | D-0004-0029	  |
  | D-00041-029	  |
  | 1-00041-0029  |	    


# VALID RECALL TEST DATAS

Scenario: Recall a patient

	  And I click "Recall" button
	  Then recall popup should be displayed
	 
	 # GIVE TODAY REGISTERED OID
	  And I enter OID "C-00001-0225"
	  
	  And I click "Submit" button from popup
	  Then I should be navigated to registration page
	  
	  And I wait for "5" seconds
	  #Then patient address details should be displayed
	  
	  And I click "Cancel" button

  
  