#@login @outReach_Event_setup
@master

Feature: Master actions

Background:
    Given user is on the dashboard page
    
Scenario: Master actions
    And user clicks on master option
    And user navigated to the master page
