@login @outReach_Event_setup
@surgery_advice_clinical_records

Feature: Surgery advice workflow in clinical records
		
Scenario: Surgery advice workflow
	And I click "Surgery Advice" button
	Then popup "Surgery Advice" should be displayed
	
Scenario: Save button should be disable initially in surgery
	Then save button should be disable
	
Scenario: Empty field in surgery
	Then save button should be disable		
	
Scenario: Eye selection in Surgery advice	
     And I select label as "Eye" and option as "RE" in surgery advice
     And I select label as "Eye" and option as "LE" in surgery advice
	
Scenario: Surgery type selection
	 And I select label as "Surgery" and option as "SICS/PMMA" in surgery advice
	 And I select label as "Surgery" and option as "Others" in surgery advice
	 And I select "DCR" from other surgery
	 And I select "Yag cap" from other surgery
	
Scenario: Anesthesia selection in Surgery advice	
     And I select label as "Anesthesia" and option as "Topical" in surgery advice
     And I select label as "Anesthesia" and option as "Subtenons" in surgery advice	
     And I select label as "Anesthesia" and option as "Retrobular" in surgery advice
     And I select label as "Anesthesia" and option as "Facial" in surgery advice
	 And I select label as "Anesthesia" and option as "Peribular" in surgery advice
	
Scenario: Ocular selection in Surgery advice	
     And I select label as "Ocular" and option as "Under GVP" in surgery advice
     And I select label as "Ocular" and option as "+/-IOL" in surgery advice	
     And I select label as "Ocular" and option as "+/- CTR" in surgery advice
     And I select label as "Ocular" and option as "Conj c/s" in surgery advice
	 And I select label as "Ocular" and option as "Dilate in Block Room" in surgery advice	
	
Scenario: Non-Ocular selection in Surgery advice	
     And I select label as "Non-Ocular" and option as "IV Mannitol" in surgery advice
     And I select label as "Non-Ocular" and option as "Nebulizer" in surgery advice	
	
Scenario: Remarks in surgery
    And I enter remarks "Emergency" in surgery
		
Scenario: Save button action in Surgery
	 # SAVE FOR SURGERY ADVICE
	 And I click "Save" button in surgery advice
	 Then surgery advice summary should be displayed 

# COUNSELLING 	 
Scenario: Counselling not done link action
	And I click "Surgery Advice" button
	Then popup "Surgery Advice" should be displayed
	 
Scenario: Date confirmation selection in Surgery advice	
     And I select label as "Date Confirmed:" and option as "Confirmed" in surgery advice
     And I select label as "Date Confirmed:" and option as "Not Confirmed" in surgery advice
     
Scenario: Date not confirmed reason dropdown
	 And I select label as "Date Confirmed:" and option as "Not Confirmed" in surgery advice
	 And I select reason for surgery date not confirmed is "Patient not willing"
	 And I select reason for surgery date not confirmed is "Need counselling again"	
     
Scenario: Surgery Date selection
     And I select label as "Date Confirmed:" and option as "Confirmed" in surgery advice
     And I enter surgery date as "02-05-2026"
	
Scenario: Save button action in Surgery Counselling
	 # SAVE FOR SURGERY COUNSELLING
	 And I click "Save" button in surgery counselling advice
	 Then surgery advice summary should be displayed
	 
# SURGERY SUMMARY INFO ICON
Scenario: Surgery summary info icon
	When I hover surgery advice summary info icon
	Then patient info "sabitha" should be displayed in surgery
	And I wait for "2" seconds	
	
# SURGERY SUMMARY DELETE ICON
Scenario: Surgery summary delete icon	
	And I click surgery advice summary delete icon
	Then popup "Confirm" should be displayed
	And I click "Cancel" button in window
	Then surgery advice summary should be displayed	
	
Scenario: Surgery summary delete icon	
	And I click surgery advice summary delete icon
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window
	Then surgery advice summary should be not displayed	
	
# VALID TEST DATAS
Scenario: Valid test datas for surgery advice
	And I click "Surgery Advice" button
	And I select label as "Eye" and option as "RE" in surgery advice
	And I select label as "Surgery" and option as "Others" in surgery advice
	And I select "DCR" from other surgery
	And I select label as "Anesthesia" and option as "Facial" in surgery advice
	And I select label as "Ocular" and option as "+/-IOL" in surgery advice
	And I select label as "Non-Ocular" and option as "Nebulizer" in surgery advice	
	And I enter remarks "Emergency" in surgery
	And I click "Save" button in surgery advice
	Then surgery advice summary should be displayed 
	And I click "Surgery Advice" button
	And I select label as "Date Confirmed:" and option as "Confirmed" in surgery advice
    And I enter surgery date as "02-05-2026"
    And I click "Save" button in surgery counselling advice
	Then surgery advice summary should be displayed
	
	


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	