@login @outReach_Event_setup
@investigations_clinical_records

Feature: Investigation workflow in clinical records
		
Scenario: Investigation workflow
	And I wait for "2" seconds
	And I click "Investigations" label option
	Then popup "Investigations" should be displayed
	
# IOP 	
Scenario: RE Values tests
	And I enter RE iop input "11"
	And I select RE iop dropdown "NCT"
	
Scenario: LE Values tests
	And I select LE iop dropdown "ERROR"
	And I enter LE iop input "11"
	
Scenario: Save icon for IOP
	And I click save icon in "IOP"

Scenario: Repeat icon for IOP
	And I click repeat icon in "IOP"
	
Scenario: Empty field IOP
	And I click save icon in "IOP"
	Then error message "Please Enter Some Value" should be displayed 
	
Scenario: Plus icon in IOP
	And I click plus icon in "IOP"
	And I wait for "2" seconds
		
Scenario: Delete icon for IOP
	And I enter RE iop input "11"
	And I select RE iop dropdown "NCT"
	And I select LE iop dropdown "ERROR"
	And I enter LE iop input "11"
	And I click delete icon in "IOP"
	Then popup "Confirm" should be displayed
	And I click "Yes" button in window 

#BLOOD SUGAR
	
Scenario: Select dropdown Blood Sugar
	And I select blood sugar type "Random"
	And I enter blood sugar value "120"
	And I select blood sugar location "Done at Outside"
	And I select blood sugar date "10-04-2026"
	
Scenario: Save icon for Blood Sugar
	And I click save icon in "Blood Sugar"    

Scenario: Repeat icon for Blood Sugar
	And I click repeat icon in "Blood Sugar"
	
Scenario: Plus icon in Blood Sugar
	And I click plus icon in "Blood Sugar"
	And I wait for "2" seconds
		
Scenario: Empty field Blood Sugar
	And I click save icon in "Blood Sugar"
	Then error message "Please Enter Some Value" should be displayed		
	
Scenario: Delete icon for Blood Sugar
	And I select blood sugar type "FBS"
	And I enter blood sugar value "110"
	And I select blood sugar location "Done at Camp site"
	And I select blood sugar date "09-04-2029"
	Then error message "Entered date should not be greater than the Current date." should be displayed
	And I select blood sugar date "10-04-2026"
	And I click delete icon in "Blood Sugar"
	Then popup "Confirm" should be displayed
	And I click "Yes" button in window 

#BLOOD PRESSURE
Scenario: Input value Blood Pressure
	And I enter systolic value "120"
    And I enter diastolic value "80"
	
Scenario: Save icon for Blood Pressure
	And I click save icon in "Blood Pressure"    

Scenario: Repeat icon for Blood Pressure
	And I click repeat icon in "Blood Pressure"
	
Scenario: Plus icon in Blood Pressure
	And I click plus icon in "Blood Pressure"
	And I wait for "2" seconds
		
Scenario: Empty field Blood Pressure
	And I click save icon in "Blood Pressure"
	Then error message "Please Enter Some Value" should be displayed		
	
Scenario: Delete icon for Blood Pressure
	And I enter systolic value "110"
    And I enter diastolic value "90"
	And I click delete icon in "Blood Pressure"
	Then popup "Confirm" should be displayed
	And I click "Yes" button in window
				
#DUCT

Scenario: Click checkbox buttons for DUCT RE and LE
	And I click "Duct RE" checkbox
	And I click "Duct LE" checkbox 
	
Scenario: Select dropdown RE LE DUCT
	And I select duct RE lower dropdown "Proximal Soft stop"	
	And I select duct RE upper dropdown "Not done - punctal atresia"
	And I select duct LE lower dropdown "Not Free with pus through fistula"
	And I select duct LE upper dropdown "Not done - punctal stenosis"
	
Scenario: Save icon for DUCT
	And I click save icon in "Duct"    

Scenario: Repeat icon for DUCT
	And I click repeat icon in "Duct"
	
Scenario: Plus icon in DUCT
	And I click plus icon in "Duct"
	And I wait for "2" seconds
		
Scenario: Empty field Duct
	And I click save icon in "Duct"
	Then error message "Please Enter Some Value" should be displayed		
	
Scenario: Delete icon for DUCT
	And I select duct RE lower dropdown "Proximal Soft stop"	
	And I select duct RE upper dropdown "Not done - punctal atresia"
	And I select duct LE lower dropdown "Not Free with pus through fistula"
	And I select duct LE upper dropdown "Not done - punctal stenosis"
	# Delete cancel
	And I click delete icon in "Duct"
	Then popup "Confirm" should be displayed
	And I click "No" button in window 
	#Delete DUCT
	And I click delete icon in "Duct"
	Then popup "Confirm" should be displayed
	And I click "Yes" button in window 
	#Delete full DUCT ---> I give delete again
	And I wait for "2" seconds
	And I click delete icon in "Duct"
	Then popup "Confirm" should be displayed
	And I click "Yes" button in window 

#ROPLAS

#ENABLE FOR NEW PATIENT INVESTIGATION	
Scenario: Click checkbox buttons for ROPLAS LE and RE
	And I click "Roplas RE" checkbox
	And I click "Roplas LE" checkbox
	
Scenario: Select dropdown RE LE roplas
	And I select roplas RE dropdown "Positive with Mucus"	
	And I select roplas LE dropdown "Positive with Pus"
	
Scenario: Save icon for roplas
	And I click save icon in "Roplas"    
	
Scenario: Repeat icon for Roplas
	And I wait for "2" seconds
	And I click repeat icon in "Roplas"

Scenario: First time Plus icon in Roplas
	And I click plus icon in "Roplas"
	And I wait for "2" seconds
		
Scenario: Empty field roplas
	And I click save icon in "Roplas"
	Then error message "Please Enter Some Value" should be displayed	
	
Scenario: Click checkbox buttons for ROPLAS LE and RE if it is already checked
	And I click "Roplas RE" checkbox
	Then popup "Alert" should be displayed
	And I click "Ok" button in window
	And I click "Roplas LE" checkbox
	Then popup "Alert" should be displayed
	And I click "Ok" button in window	
	
Scenario: Delete icon for Roplas
	And I select roplas RE dropdown "Negative"	
	And I select roplas LE dropdown "Positive with Clear fluids"
	And I click delete icon in "Roplas"
	Then popup "Confirm" should be displayed
	And I click "Yes" button in window 
	And I click close icon
	Then I navigated to the doctor screen page
	And I wait for "2" seconds
	

 	                               
	
	
	                        
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	