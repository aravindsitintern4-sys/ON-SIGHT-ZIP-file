@login @outReach_Event_setup
@fundus_clinical_records

Feature: Fundus workflow in clinical records
		
Scenario: Fundus navigation flow
	And user clicks " Fundus " label option
	Then popup "Fundus" should be displayed
	
Scenario: Save button should be disable initially
	Then save button should be disable
			
Scenario: Fundus action for Media
 	And user waits for "1" seconds
 	And I select "Media:" label for "RE" with "Clear" option in fundus
	And I select "Media:" label for "LE" with "Hazy - cataract" option in fundus
	And I select "Media:" label for "RE" with "Hazy - corneal edema" option in fundus
	And I select "Media:" label for "LE" with "Hazy - corneal scar" option in fundus
	And I select "Media:" label for "RE" with "Hazy - vitreous haemorrhage" option in fundus

Scenario: Fundus action for Disc
 	And I select "Disc:" label for "RE" with "Normal" option in fundus
	And I select "Disc:" label for "LE" with "High VCDR" option in fundus
	And I select "Disc:" label for "RE" with "Pale disc" option in fundus
	And I select "Disc:" label for "LE" with "NVD" option in fundus	
	
Scenario: Fundus action for Vessels
 	And I select "Vessels:" label for "RE" with "Normal" option in fundus
	And I select "Vessels:" label for "LE" with "Attenuated" option in fundus
	And I select "Vessels:" label for "RE" with "Arteriosclerotic changes" option in fundus
	And I select "Vessels:" label for "LE" with "Tortuous" option in fundus		
	
Scenario: Fundus action for Background Retina
 	And user waits for "1" seconds
 	And I select "Background Retina:" label for "RE" with "Normal" option in fundus
	And I select "Background Retina:" label for "LE" with "DR" option in fundus
	And I select "Background Retina:" label for "RE" with "Drusen" option in fundus
	And I select "Background Retina:" label for "LE" with "CRVO" option in fundus
	And I select "Background Retina:" label for "RE" with "Peripheral degenerations" option in fundus
		
Scenario: Fundus action for Macula / Foveal Reflex
 	And I select "Macula / Foveal Reflex:" label for "RE" with "Present" option in fundus
	And I select "Macula / Foveal Reflex:" label for "LE" with "Dull" option in fundus
	And I select "Macula / Foveal Reflex:" label for "RE" with "RPE degeneration" option in fundus
	And I select "Macula / Foveal Reflex:" label for "LE" with "Absent" option in fundus	
		
Scenario: Remarks for Fundus
	And I enter remarks for "RE" as "RE remarks entered in fundus" in fundus
	And I enter remarks for "LE" as "LE remarks entered in fundus" in fundus	
	
Scenario: Save action in Fundus
	And I click save button in examination
	#And user clicks close icon
	#And user clicks "Discard" button in window
	Then Fundus summary should be displayed
	
Scenario: Update action in Fundus
    And user clicks " Fundus " label option
    And I select "Macula / Foveal Reflex:" label for "RE" with "Scar" option in fundus	
    And I click save or update button in examination
	Then Fundus summary should be displayed
		
Scenario: Fundus info icon
	When user hovers Fundus summary info icon
	And user waits for "2" seconds
	
Scenario: Fundus summary Delete icon
 	And I click Fundus summary delete icon
	Then popup "Confirm" should be displayed
	And user clicks "Delete" button in window
	Then Fundus summary should be not displayed
	And user waits for "2" seconds
	
Scenario: Final Datas for Fundus
    And user clicks " Fundus " label option
    And I select "Macula / Foveal Reflex:" label for "RE" with "Present" option in fundus
    And I select "Disc:" label for "LE" with "High VCDR" option in fundus 
    And I select "Background Retina:" label for "RE" with "Drusen" option in fundus
    And I select "Disc:" label for "RE" with "Pale disc" option in fundus
    And I enter remarks for "RE" as "RE remarks entered in fundus" in fundus
	And I enter remarks for "LE" as "LE remarks entered in fundus" in fundus
    And I click save or update button in examination
	Then Fundus summary should be displayed
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	