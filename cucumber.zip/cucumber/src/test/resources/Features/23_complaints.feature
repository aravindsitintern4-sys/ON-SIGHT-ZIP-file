#@login @outReach_Event_setup
@complaints_clinical_records

Feature: Complaints workflow in clinical records
		
Scenario: Complaints navigation flow
	And I wait for "2" seconds
	And I click "Complaints" label option
	Then popup "Complaints" should be displayed
      
Scenario: Actions Complaints 
    And I wait for "10" seconds
    And I select "RE" eye for "Defective near vision" complaint
    When I open duration for "Defective near vision"
    And I set duration value "12"
    And I set duration type "Day"
    And I set duration value "12"
    And I set duration type "Week"
    And I set duration value "12"
    And I set duration type "Month"
    And I set duration value "12"
    And I set duration type "Year"
	And I click "Ok" button in duration
	Then complaint with duration should be displayed
	
Scenario: Unselect action delete confirm
    And I click "Pain" complaint option
    And I set duration value "12"
    And I set duration type "Day"
    And I click "Ok" button in duration
    Then complaint with duration should be displayed
    And I click "Pain" complaint option
    And I click delete "OK" for confirmation complaint
 
    
Scenario: Unselect action delete cancel    
	And I click "Pain" complaint option
    And I set duration value "12"
    And I set duration type "Day"
    And I click "Ok" button in duration
    Then complaint with duration should be displayed
    And I click "Pain" complaint option   
    And I click delete "Cancel" for confirmation complaint
	
Scenario: Actions in complaints - Defective Vision
    And I select "RE" eye for "Defective Vision" complaint  
    And I set duration value "12"
    And I set duration type "Day"
	And I click "Ok" button in duration
	Then complaint with duration should be displayed	
	
Scenario: Actions in complaints - Foreign Body
    And I select "RE" eye for "Foreign Body" complaint
    And I set duration value "12"
    And I set duration type "Today"
	And I click "Ok" button in duration
	Then complaint with duration should be displayed	
	
Scenario: Actions in complaints - Ocular Trauma
    And I select "RE" eye for "Ocular Trauma" complaint
    And I set duration value "90"
    And I set duration type "Week"
	And I click "Ok" button in duration
	Then complaint with duration should be displayed		
	
Scenario: Actions in complaints - Irritation
	And I click "Irritation" complaint option
    And I set duration value "12"
    And I set duration type "Year"
    And I click "Ok" button in duration
    Then complaint with duration should be displayed
    
Scenario: Actions in complaints - Watering
	And I click "Watering" complaint option
    And I set duration value "12"
    And I set duration type "Day"
    And I click "Ok" button in duration
    Then complaint with duration should be displayed	
	
Scenario: Actions in complaints - Discharge
	And I click "Discharge" complaint option
    And I set duration value "12"
    And I set duration type "Month"
    And I click "Ok" button in duration
    Then complaint with duration should be displayed	
	
Scenario: Actions in complaints - Itching
    And I select "LE" eye for "Itching" complaint
    And I set duration value "10"
    And I set duration type "Day"
	And I click "Ok" button in duration
	Then complaint with duration should be displayed	
	
Scenario: Actions in complaints - Redness
    And I select "RE" eye for "Redness" complaint
    And I set duration value "1"
    And I set duration type "Month"
	And I click "Ok" button in duration
	Then complaint with duration should be displayed	
	
Scenario: Actions in complaints - Headache
	And I click "Headache" complaint option
    And I set duration value "12"
    And I set duration type "Day"
    And I click "Ok" button in duration
    Then complaint with duration should be displayed	
	
Scenario: Actions in complaints - No Specific Complaints
	And I click "No Specific Complaints" complaint option
    And I click "OK" for system alert confirmation complaint
    Then complaint with duration should be displayed	
	
Scenario: Actions in complaints - Non Ocular
    #And I click "BE" complaint option
    And I click "Non Ocular" complaint option
    And I select "Chest Pain, Earpain" from all complaints dropdown
    When I open duration in all complaints
    And I set duration value "12" in complaints
    And I set duration type "Day" in complaints
    And I click "Ok" button in duration in complaints
    And I click "Add" button
    Then complaint with duration should be displayed
      	
Scenario: Compalints save
	And I click save or update button in examination
	Then complaints summary should be displayed
	And I wait for "2" seconds
	
Scenario: Actions in complaints Update action
	And I wait for "2" seconds
	And I click "Complaints" label option
	And I wait for "2" seconds
    And I select "LE" eye for "Swelling" complaint
    And I set duration value "90"
    And I set duration type "Day"
	And I click "Ok" button in duration
	Then complaint with duration should be displayed
    And I click save or update button in examination
    And I wait for "2" seconds
	
Scenario: Complaints info icon
	When I hover complaints summary info icon
	Then "Complaints : Ms.sabitha" info is displayed
	And I wait for "2" seconds
	      
Scenario: Complaints summary Delete icon
 	And I click complaints summary delete icon
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window
	Then complaints summary should be not displayed
	And I wait for "2" seconds

Scenario: Final Valid complaint
	And I wait for "2" seconds
	And I click "Complaints" label option
	And I wait for "3" seconds
	And I click "Pain" complaint option
    And I set duration value "12"
    And I set duration type "Day"
    And I click "Ok" button in duration
    Then complaint with duration should be displayed
    
	And I select "LE" eye for "Swelling" complaint
    And I set duration value "90"
    And I set duration type "Day"
	And I click "Ok" button in duration
	Then complaint with duration should be displayed
	
    And I click save or update button in examination
    And I wait for "2" seconds
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	