#@login @outReach_Event_setup
@DP_advice_clinical_records

Feature: Drug Prescription (DP) advice workflow in clinical records
		
Scenario: DP advice workflow
	And I click "DP" button
	Then popup "Drug Prescription" should be displayed
	
# DRUG SELECTION WITH FLEX BUTTON	
Scenario: Drug Selection through buttons
    And I select "RE" for "Aurosol, 30 days x Twice a day" drug

# DRUG SELECTION USING DROPDOWN   
Scenario: Repeat Drug Selection through buttons 
    And I select "RE" for "Aurosol, 30 days x Twice a day" drug
    And get alert msg and click "OK" for alert from system

# EYE TYPE    
Scenario Outline: Select Eye Type in DP
    And I select eye type "<eyeType>" in DP
    
Examples:
    | eyeType |
    | RE      |
    | LE      |
    | BE      |

# DRUG NAME  
Scenario Outline: Select Drug name in DP
    And I select drug name "<drugName>" in DP

Examples:
    | drugName |
    | Aurosol  |

# NEGATIVE SCENARIO
Scenario: Select Invalid Drug name in DP
    And I select drug name "{}::{}{{" in DP
    Then "Invalid Drug Name" alert indicating should appear
    
# FREQUENCY SELECTION
Scenario: Frequency selection
	And I select frequency "<frequency>" in DP
	
Examples:
    | frequency   |
    | Twice a day |
    | Once a day  |

#NEGATIVE SCENARIO    
Scenario: Duration input
	And I enter duration "<duration>" in DP
	
Examples:
	| duration |
	| hjsjashc |
	| }{}::{}{ |

# DURATION INPUT
Scenario: Duration input
	And I enter duration "100" in DP

# DURATION TYPE		
Scenario: Duration type selection
	And I select duration Type "<type>" in DP

Examples:
    | type   |
    | Days   |
    | Months |    

#REMARKS
Scenario: Remark input
	And I enter remarks "Need Medication" in DP

# ADD BUTTON
Scenario: Add button In DP
	And I click "Add" button
	Then added drug details should be displayed

# DELETE ICON FOR ADDED DRUG	
Scenario: delete icon for added details
  	And I click delete icon for "BE - Aurosol | Once a day | 100 Months, Need Medication"

# PRESCRIPTION LANGUAGE 	
Scenario: Prescription Language actions
	And I select prescription language "தமிழ்" in DP
	And I select prescription language "English" in DP

# SAVE BUTTON ACTIONS
Scenario: Save actions in DP
	And I click "Save" button in DP
	Then DP advice summary should be displayed

# DP SUMMARY PRINT 
Scenario: DP summary print icon
	And I click DP advice summary print icon
	And I click "Print" button in preview
	
# DP SUMMARY PRINT CLOSE BUTTON
Scenario: DP summary Print icon close button
	And I click DP advice summary print icon
	And I click "Close" button in preview
	Then DP advice summary should be displayed
	
# DP SUMMARY INFO ICON
Scenario: DP summary info icon
	When I hover DP advice summary info icon
	Then patient info "sabitha" should be displayed in DP
	And I wait for "2" seconds
	
# DP LANGUAGE PRINT ACTION
Scenario: Language Check in Prescription Print
	And I click "DP" button
	And I select eye type "LE" in DP
    And I select drug name "Aurosol" in DP
    And I select frequency "Twice a day" in DP
    And I enter duration "1" in DP
	And I select duration Type "Months" in DP
	And I select prescription language "தமிழ்" in DP
	And I click "Add" button
	Then added drug details should be displayed
	And I click "Update & Print" button in DP
	And I wait for "2" seconds
	Then prescription should be displayed in "தமிழ்"
	And I wait for "2" seconds
	And I click "Close" button in preview
	And I wait for "2" seconds
	Then DP advice summary should be displayed
		  	  
# DP SUMMARY DELETE ICON
Scenario: DP summary delete icon	
	And I click trash icon in "Drug Prescription"
	Then popup "Confirm" should be displayed
	And I click "Cancel" button in window
	Then DP advice summary should be displayed	
	
Scenario: DP summary delete icon	
	And I click trash icon in "Drug Prescription"
	Then popup "Confirm" should be displayed
	And I click "Ok" button in window
	Then DP advice summary should be not displayed
	
# NEGATIVE SCENARIO FOR DURATION
Scenario: Duration invalid input
	And I click "DP" button
	And I select eye type "RE" in DP
    And I select drug name "Aurosol" in DP
    And I select frequency "Twice a day" in DP
    And I enter duration "454654654655465465454" in DP
	And I select duration Type "Months" in DP
	And I click "Add" button
	Then added drug details should be displayed
	Then screenshot should be captured "DP_invaild_duration"
	And I wait for "2" seconds
	And I click "Save" button in DP
	Then added drug details should be displayed
	And I click "Clear" button in DP
	And I click "Ok" button in window
	
# FINAL VALID TEST DATAS
Scenario: Valid Test datas for DP advice
	And I select eye type "RE" in DP
    And I select drug name "Aurosol" in DP
    And I select frequency "Once a day" in DP
    And I enter duration "45" in DP
	And I select duration Type "Days" in DP
	And I enter remarks "Need Medication" in DP
	And I click "Add" button
	Then added drug details should be displayed
	And I click "Save" button in DP
	Then DP advice summary should be displayed
	Then screenshot should be captured "DP_Vaild"
	
#COUNSELLING

#NEGATIVE SCENARIO
Scenario: Counselling initial link Confirmed DP validation button diable
	And I click "Drug Prescription" text
    Then popup "DP Counselling" should be displayed
	Then "Save & Print" button should be disable
	And I click "Clear" button for new counselling
	And I click "Ok" button

Scenario: Counselling initial link Confirmed in DP Counselling
	And I select label as "Drug Prescription:" and option as "Counselling Done" in surgery advice
	And I click "Save" button for new counselling
	
    
       
























































 	