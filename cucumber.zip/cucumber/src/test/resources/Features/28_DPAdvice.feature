@login @outReach_Event_setup
@DP_advice_clinical_records

Feature: Drug Prescription (DP) advice workflow in clinical records
		
Scenario: DP advice workflow
	And I click "DP" button
	Then popup "Drug Prescription" should be displayed
	
Scenario: Drug Selection through buttons
    And I select "RE" for "Aurosol, 30 days x Twice a day" drug
    
Scenario: Repeat Drug Selection through buttons 
    And I select "RE" for "Aurosol, 30 days x Twice a day" drug
    And get alert msg and select "OK" for alert from system
    
Scenario Outline: Select Eye Type in DP
    And I select eye type "<eyeType>" in DP
    
Examples:
    | eyeType |
    | RE      |
    | LE      |
    | BE      |
   
Scenario Outline: Select Drug name in DP
    And I select drug name "<drugName>" in DP
    
Examples:
    | drugName |
    | Aurosol  |
    | {}{}{}{  |




































































 	