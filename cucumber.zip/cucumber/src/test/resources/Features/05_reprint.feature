#@login  @outReach_Event_setu
@reprint
Feature: Reprint patient details

Scenario: Click Registration actions
	When user clicks on Registration option
	Then patient should be navigated to the registration page

# NEGATIVE SCENARIO
Scenario Outline: OID field validation in Reprint for invalid formats
  When user clicks on Reprint button
  Then reprint popup should be displayed
  And user enters OID "<oid>" in reprint
  And user clicks on Search icon
  Then user should see OID validation message "No data available for the given UID!"
  And user clicks on OK button
  And user clicks on Cancel button in reprint


Examples:
  | oid             |
  | DD-00041-0029   |
  | D00041-0029     |
  | D-0004-0029     |
  | D-00041-029     |
  | 1-00041-0029    |
   
Scenario: Reprint Validation with Empty Oid credentials
  When user clicks on Reprint button
  Then reprint popup should be displayed
  And user selects patient type "New"
  Then date field should be disable
  And user clicks on Search icon
  And Required alert "Required." should be appear in reprint
  And user clicks on Cancel button in reprint

Scenario: Reprint Validation with New patient credentials
  When user clicks on Reprint button
  Then reprint popup should be displayed
  And user selects patient type "New"
  Then date field should be disable
  And user enters OID "C-00025-0064" in reprint
  And user clicks on Search icon
  When user clicks on Submit button in reprint
  Then print preview should be displayed
  And user clicks "Close" button in preview
  And user clicks on Cancel button in reprint

Scenario: Reprint Validation with Review patient credentials
  When user clicks on Reprint button
  Then reprint popup should be displayed
  And user selects patient type "Review"
  And user enters date "29-04-2026" in reprint
  And user enters OID "C-00025-0064" in reprint
  And user clicks on Search icon
  When user clicks on Submit button in reprint
  Then print preview should be displayed
  And user clicks "Close" button in preview
  And user clicks on Cancel button in reprint
 
Scenario: Reprint Validation with Review patient with old OID credentials
  When user clicks on Reprint button
  Then reprint popup should be displayed
  And user selects patient type "Review"
  And user enters date "24-03-2026" in reprint
  And user enters OID "D-00041-0036" in reprint
  And user clicks on Search icon
  And error message "Patients not registered today cannot be reprinted." should be displayed in reprint
  And user clicks on Cancel button in reprint

Scenario: Reprint Validation with  Previous day OID for New patient
  When user clicks on Reprint button
  Then reprint popup should be displayed
  And user selects patient type "New"
  Then date field should be disable
  And user enters OID "D-00041-0030" in reprint
  And user clicks on Search icon
  And error message "Patients not registered today cannot be reprinted." should be displayed in reprint
  Then submit button should be disable in reprint
  And user clicks on Cancel button in reprint
  And user clicks on Cancel button in registration 
  