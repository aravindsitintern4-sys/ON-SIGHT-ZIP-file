#@login  @outReach_Event_setu
@reprint
Feature: Reprint patient details

Scenario: Click Registration actions
	When I click on Registration option
	Then patient should be navigated to the registration page

# NEGATIVE SCENARIO
Scenario Outline: OID field validation in Reprint for invalid formats
  When I click on Reprint button
  Then reprint popup should be displayed
  And I enter OID "<oid>" in reprint
  And I click on Search icon
  Then I should see OID validation message "No data available for the given UID!"
  And I click on OK button
  And I click on Cancel button in reprint


Examples:
  | oid             |
  | DD-00041-0029   |
  | D00041-0029     |
  | D-0004-0029     |
  | D-00041-029     |
  | 1-00041-0029    |
   
Scenario: Reprint Validation with Empty Oid credentials
  When I click on Reprint button
  Then reprint popup should be displayed
  And I select patient type "New"
  Then date field should be disable
  And I click on Search icon
  And Required alert "Required." should be appear in reprint
  And I click on Cancel button in reprint

Scenario: Reprint Validation with New patient credentials
  When I click on Reprint button
  Then reprint popup should be displayed
  And I select patient type "New"
  Then date field should be disable
  And I enter OID "C-00025-0064" in reprint
  And I click on Search icon
  When I click on Submit button in reprint
  Then print preview should be displayed
  And I click "Close" button in preview
  And I click on Cancel button in reprint

Scenario: Reprint Validation with Review patient credentials
  When I click on Reprint button
  Then reprint popup should be displayed
  And I select patient type "Review"
  And I enter date "29-04-2026" in reprint
  And I enter OID "C-00025-0064" in reprint
  And I click on Search icon
  When I click on Submit button in reprint
  Then print preview should be displayed
  And I click "Close" button in preview
  And I click on Cancel button in reprint
 
Scenario: Reprint Validation with Review patient with old OID credentials
  When I click on Reprint button
  Then reprint popup should be displayed
  And I select patient type "Review"
  And I enter date "24-03-2026" in reprint
  And I enter OID "D-00041-0036" in reprint
  And I click on Search icon
  And error message "Patients not registered today cannot be reprinted." should be displayed in reprint
  And I click on Cancel button in reprint

Scenario: Reprint Validation with  Previous day OID for New patient
  When I click on Reprint button
  Then reprint popup should be displayed
  And I select patient type "New"
  Then date field should be disable
  And I enter OID "D-00041-0030" in reprint
  And I click on Search icon
  And error message "Patients not registered today cannot be reprinted." should be displayed in reprint
  Then submit button should be disable in reprint
  And I click on Cancel button in reprint
  And I click on Cancel button in registration 
  