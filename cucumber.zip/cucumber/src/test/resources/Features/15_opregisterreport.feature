#@login @outReach_Event_setup
@opRegister_report

Feature: OP Register Workflow

Scenario: OP Register Report
	And I click on "Op Register" option
	Then I navigated to "Op Register" page
	
Scenario Outline: Register patient report Valid test datas
	And I select campId "<campidPlace>"
    And I click "Submit" button
	Then selected data "<campidPlace>" details should be displayed
Examples:
      | campidPlace |
      | 24          |
      | 25          |	

# NEGATIVE SCENARIO
Scenario Outline: Register patient invalid test datas
	And I select campId "<campidPlace>"
	Then no items found message should be displayed in dropdown
    And I click "Submit" button	
    
Examples:
      | campidPlace |
      | 188888888   |
      | ghvchgcghch |

#PAGINATION
Scenario: Pagination actions using next and previous buttons
	And I select campId "25"
    And I click "Submit" button
	Then selected data "25" details should be displayed
	
	And I click on Next button
	Then page "2" should be active
	And I click on Next button
	Then page "3" should be active
	
	And I click on Previous button
	Then page "2" should be active
	And I click on Previous button
	Then page "1" should be active

Scenario: Pagination actions without next and previous buttons
	And I select campId "25"
    And I click "Submit" button
	Then selected data "25" details should be displayed

	And I click on page "2"
	Then page "2" should be active
	And I click on page "3"
	Then page "3" should be active
	And I click on page "1"
	Then page "1" should be active
	Then Previous button should be disabled

# OP REGISTER EXCEL EXPORT
Scenario: Verify export functionality
    And I select campId "25"
    And I click "Submit" button
    Then selected data "25" details should be displayed
    And I click on Export button
    Then file should be downloaded successfully
	Then screenshot should be captured "OP_Register_1"
	And I wait for "5" seconds
	And I click close icon
	Then I navigated to the reports page
	And I wait for "2" seconds










