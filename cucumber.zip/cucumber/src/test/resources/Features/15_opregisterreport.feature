#@login @outReach_Event_setup
@opRegister_report

Feature: OP Register Workflow

Scenario: OP Register Report
	And user clicks on "Op Register" option
	Then user is navigated to "Op Register" page
	
Scenario Outline: Register patient report Valid test datas
	And user selects campId "<campidPlace>"
	And user clicks submit button
	Then selected data "<campidPlace>" details should be displayed
Examples:
      | campidPlace |
      | 25          |
      | 12          |	

# NEGATIVE SCENARIO
Scenario Outline: Register patient invalid test datas
	And user selects campId "<campidPlace>"
	Then no items found message should be displayed in dropdown
	And user clicks submit button	
Examples:
      | campidPlace |
      | 188888888   |
      | ghvchgcghch |

#PAGINATION
Scenario: Pagination actions  using next and previous buttons
	And user selects campId "25"
	And user clicks submit button
	Then selected data "25" details should be displayed
	
	And user clicks on Next button
	Then page "2" should be active
	And user clicks on Next button
	Then page "3" should be active
	
	And user clicks on Previous button
	Then page "2" should be active
	And user clicks on Previous button
	Then page "1" should be active

Scenario: Pagination actions without next and previous buttons
	And user selects campId "41"
	And user clicks submit button
	Then selected data "41" details should be displayed

	And user clicks on page "2"
	Then page "2" should be active
	And user clicks on page "3"
	Then page "3" should be active
	And user clicks on page "1"
	Then page "1" should be active
	Then Previous button should be disabled

# OP REGISTER EXCEL EXPORT
Scenario: Verify export functionality
    And user selects campId "25"
    And user clicks submit button
    Then selected data "25" details should be displayed
    And user clicks on Export button
    Then file should be downloaded successfully
	Then screenshot should be captured "OP_Register_25"
	And user waits for "5" seconds
	And user clicks close icon
	Then user navigated to the reports page










