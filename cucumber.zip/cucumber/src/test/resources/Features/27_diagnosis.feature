#@login @outReach_Event_setup
@diagnosis_clinical_records

Feature: Diagnosis workflow in clinical records
		
Scenario: Diagnosis navigation flow
	And I click "Diagnosis" label option
	Then popup "Diagnosis" should be displayed
	
Scenario: Save button should be disable initially
	Then save button should be disable
	
Scenario: Select diagnosis after select normal
	And I click "Normal" diagnosis option
	And I select "RE" eye for "Acute conjunctivitis" diagnosis
	Then Not Allowed alert should be displayed
	And I click "Normal" diagnosis option
	
Scenario: Click actions in diagnosis with Eye
	And I select "RE" eye for "Acute conjunctivitis" diagnosis
	And I select "RE" eye for "Blepharitis" diagnosis
	And I select "LE" eye for "Corneal foreign Body" diagnosis
	And I select "RE" eye for "Hordeolum internum" diagnosis
	And I select "LE" eye for "Hyperopic astigmatism" diagnosis
	And I select "RE" eye for "IMC - Immature cataract" diagnosis
	And I select "LE" eye for "Incipient cataract" diagnosis
	And I select "RE" eye for "Mature cataract" diagnosis
	And I select "RE" eye for "MGD-Meibomian gland dysfunction" diagnosis
	And I select "LE" eye for "Myopic astigmatism" diagnosis
	And I select "LE" eye for "Presbyopia" diagnosis
	And I select "RE" eye for "Pseudophakia" diagnosis
	And I select "RE" eye for "Simple hypermetropia" diagnosis
	
Scenario: Click diagnosis for both eye
	And I click "Simple myopia" diagnosis option
	And I click "Sinusitis" diagnosis option
	And I click "Episcleritis" diagnosis option
	
Scenario: Other diagnosis section
	And I select "RE" eye type for other diagnosis 
	And I select "Hyperopia of bilateral eyes" from diagnosis dropdown
	And I click "Add" button

Scenario: Save action in Diagnosis
	And I click save button in examination
	#And user clicks close icon
	#And user clicks "Discard" button in window
	Then Diagnosis summary should be displayed
	
Scenario: Update action in Diagnosis
    And I click "Diagnosis" label option
    And I select "RE" eye for "PCO - Posterior capsular opacification" diagnosis	
    And I click save or update button in examination
	Then Diagnosis summary should be displayed
		
Scenario: Diagnosis info icon
	When I hover Diagnosis summary info icon
	And I wait for "2" seconds
	
Scenario: Diagnosis summary Delete icon
 	And I click Diagnosis summary delete icon
	And I click "Ok" button in window
	Then Diagnosis summary should be not displayed
	And I wait for "2" seconds
	
Scenario: Final Datas for Diagnosis
    And I click "Diagnosis" label option
    And I select "RE" eye for "Incipient cataract" diagnosis
    And I select "LE" eye for "Blepharitis" diagnosis
    And I select "RE" eye for "Presbyopia" diagnosis
    And I click save or update button in examination
	Then Diagnosis summary should be displayed
	




























