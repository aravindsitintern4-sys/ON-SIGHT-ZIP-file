@login @outReach_Event_setup 
@user_master_newUser

Feature: User Master Workflow Actions
	
# USER MASTER  
Scenario: User Master actions 
    And I click on user master option
    Then I navigated to the user master page
    Then edit and delete and reset password buttons should be disable initially
 
Scenario: New button in User master
	And I click New button in user master
	Then new user creation popup should be displayed
	
# ALIAS 	
Scenario Outline: Alias Validation
	And I select alias "<aliasInput>" dropdown
	And I click clear button in event popup
	
Examples:
  | aliasInput | 
  | Ms         | 
  | Mrs        |
  | Mr         |	

Scenario: Empty credential for Alias 
	And I click save button in event popup
	Then alias Required alert should be appear
	And I click clear button in event popup
	
# FIRST NAME 	
Scenario Outline: First name Validation
	And I enter First name "<firstName>" in user
	And I click clear button in event popup

Examples:
  | firstName   | 
  | N@me- Test  | 
  | RAM         |
  | RANI        |	

Scenario: Empty credential for Alias 
	And I click save button in user popup
	Then first name Required alert should be appear
	And I click clear button in user popup	
	
# LAST NAME 	
Scenario Outline: Last name Validation
	And I enter Last name "<lastName>" in user
	And I click clear button in event popup

Examples:
  | lastName    | 
  | N@me- Test  | 
  | RAM         |
  | RANI        |
  
# EMAIL  	
Scenario Outline: Email Validation
	And I enter email "<email>" in user
	And I click clear button in event popup

Examples:
  | lastName         | 
  | N@me- Test       | 
  | RAM123@gmail.com |
  | RANI124@.com     |
  
# ROLES 	
Scenario Outline: Roles Validation
	And I select role "<roleInput>" dropdown
	And I click clear button in event popup

Examples:
  | roleInput  | 
  | Admin      | 
  | Doctor     |
  | Organizer  |	

Scenario: Empty credential for Role 
	And I click save button in event popup
	Then role Required alert should be appear
	And I click clear button in event popup
  
# HOSPITAL NAME 	
Scenario Outline: Hospital name Validation
	And I select hospital name "<hospitalInput>" userMaster dropdown
	And I click clear button in event popup

Examples:
  | hospitalInput                       | 
  | Aravind Eye Hospital - Virudhunagar | 
  | Aravind Eye Hospital-Madurai        |
	

Scenario: Empty credential for Hospital name userMaster 
	And I click save button in event popup
	Then I should see hospital name empty field validation in user master
	And I click clear button in event popup

# MCIR NUMBER  	
#Scenario Outline: MCIR number Validation
	#And I enter MCIR number "<mcirNum>" in user
	#And I click clear button in event popup
	
#Examples:
 # | mcirNum         | 
 # | N@me- Test123   | 
 # | 67747647647647  |
  #| {123456}        |
	
#ACTIVE STATUS ---> CHECK BOX	
Scenario: Active status checkbox validation in userMaster
    And I click active checkbox
	And I click clear button in user popup		
	
# VALID TEST DATAS
Scenario: Valid Test Datas
	And I enter First name "N@me- Test" in user
	And I enter Last name "User" in user
	And I enter email "N@me- Test@!@34" in user
	And I select role "Admin" dropdown	
	And I select hospital name "Aravind Eye Hospital - Virudhunagar" userMaster dropdown
    #And I enter MCIR number "6774" in user
	And I click active checkbox
	And I select alias "Ms" dropdown
		
	And I click save button in event popup
	Then "User created successfully!" toast should be displayed
	#And I click clear button in user popup	
	#And I click cancel button in user popup	
	
Scenario: Navigate to Outreach event master page
	And I click on home
	And I click on master option
    And I navigated to the master page

	

	
	

	  		

  

 

  	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	