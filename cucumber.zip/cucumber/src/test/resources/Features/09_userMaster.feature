#@login @outReach_Event_setup 
@user_master_newUser

Feature: User Master Workflow Actions
	
# USER MASTER  
Scenario: User Master actions 
    And user clicks on user master option
    Then user navigated to the user master page
    Then edit and delete and reset password buttons should be disable initially
 
Scenario: New button in User master
	And user clicks New button in user master
	Then new user creation popup should be displayed
	
# ALIAS 	
Scenario Outline: Alias Validation
	And user selects alias "<aliasInput>" dropdown
	And user clicks clear button in event popup
	
Examples:
  | aliasInput | 
  | Ms         | 
  | Mrs        |
  | Mr         |	

Scenario: Empty credential for Alias 
	And user clicks save button in event popup
	Then alias Required alert should be appear
	And user clicks clear button in event popup
	
# FIRST NAME 	
Scenario Outline: First name Validation
	And user enters First name "<firstName>" in user
	And user clicks clear button in event popup

Examples:
  | firstName   | 
  | N@me- Test  | 
  | RAM         |
  | RANI        |	

Scenario: Empty credential for Alias 
	And user clicks save button in user popup
	Then first name Required alert should be appear
	And user clicks clear button in user popup	
	
# LAST NAME 	
Scenario Outline: Last name Validation
	And user enters Last name "<lastName>" in user
	And user clicks clear button in event popup

Examples:
  | lastName    | 
  | N@me- Test  | 
  | RAM         |
  | RANI        |
  
# EMAIL  	
Scenario Outline: Email Validation
	And user enters email "<email>" in user
	And user clicks clear button in event popup

Examples:
  | lastName         | 
  | N@me- Test       | 
  | RAM123@gmail.com |
  | RANI124@.com     |
  
# ROLES 	
Scenario Outline: Roles Validation
	And user selects role "<roleInput>" dropdown
	And user clicks clear button in event popup

Examples:
  | roleInput  | 
  | Admin      | 
  | Doctor     |
  | Organizer  |	

Scenario: Empty credential for Role 
	And user clicks save button in event popup
	Then role Required alert should be appear
	And user clicks clear button in event popup
  
# HOSPITAL NAME 	
Scenario Outline: Hospital name Validation
	And user selects hospital name "<hospitalInput>" userMaster dropdown
	And user clicks clear button in event popup

Examples:
  | hospitalInput                       | 
  | Aravind Eye Hospital - Virudhunagar | 
  | Aravind Eye Hospital-Madurai        |
	

Scenario: Empty credential for Hospital name userMaster 
	And user clicks save button in event popup
	Then user should see hospital name empty field validation in user master
	And user clicks clear button in event popup

# MCIR NUMBER  	
#Scenario Outline: MCIR number Validation
	#And user enters MCIR number "<mcirNum>" in user
	#And user clicks clear button in event popup
	
#Examples:
 # | mcirNum         | 
 # | N@me- Test123   | 
 # | 67747647647647  |
  #| {123456}        |
	
#ACTIVE STATUS ---> CHECK BOX	
Scenario: Active status checkbox validation in userMaster
    And user clicks active checkbox
	And user clicks clear button in user popup		
	
# VALID TEST DATAS
Scenario: Valid Test Datas
	And user enters First name "N@me- Test" in user
	And user enters Last name "User" in user
	And user enters email "N@me- Test@!@34" in user
	And user selects role "Admin" dropdown	
	And user selects hospital name "Aravind Eye Hospital - Virudhunagar" userMaster dropdown
    #And user enters MCIR number "6774" in user
	And user clicks active checkbox
	And user selects alias "Ms" dropdown
		
	And user clicks save button in event popup
	Then "User created successfully!" toast should be displayed
	#And user clicks clear button in user popup	
	#And user clicks cancel button in user popup	
	
Scenario: Navigate to Outreach event master page
	And user clicks on home
	And user clicks on master option
    And user navigated to the master page

	

	
	

	  		

  

 

  	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	