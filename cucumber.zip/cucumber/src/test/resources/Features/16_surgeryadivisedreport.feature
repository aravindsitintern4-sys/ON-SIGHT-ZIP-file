#@login @outReach_Event_setup
@surgeryAdvised_report

Feature: Surgery Advised Workflow

Scenario: Surgery Adviced Report
	And I click on "Surgery Advised" option
	Then I navigated to "Surgery Advised" page

	
Scenario Outline: Surgery advised report patient Valid test datas
	And I select campId "<campidPlace>"
	#And I click submit button
    And I click "Submit" button
	Then selected data "<campidPlace>" details should be displayed
	
Examples:
      | campidPlace |
      | 25          |
      | 12          |	


# NEGATIVE SCENARIO
Scenario Outline: Surgery Advised report patient invalid test datas
	And I select campId "<campidPlace>"
	Then no items found message should be displayed in dropdown
	#And I click submit button
    And I click "Submit" button
    
Examples:
      | campidPlace |
      | 188888888   |
      | ghvchgcghch |
      

# PAGEINATION
Scenario: Pagination workflow using action buttons Next and Previous in surgery advice
	And I select campId "24"
	#And I click submit button
    And I click "Submit" button
	Then selected data "24" details should be displayed
	
	And I click on Next button
	Then page "2" should be active
	
	And I click on Previous button
	Then page "1" should be active

Scenario: Pagination actions using page number in surgery advice
	And I select campId "24"
	#And I click submit button
    And I click "Submit" button
	Then selected data "24" details should be displayed
	
	And I click on page "2"
	Then page "2" should be active
	
	And I click on page "1"
	Then page "1" should be active
	Then Previous button should be disabled

# EXPORT EXCEL ----> FILE DOWNLOAD
Scenario: Export Pdf workflow in surgery advice
    And I select campId "25"
    #And I click submit button
    And I click "Submit" button
    Then selected data "25" details should be displayed
    And I click on Export button
    Then file should be downloaded successfully
    Then screenshot should be captured "surgery_advised_25"
    And I wait for "5" seconds
	And I click close icon
	Then I navigated to the reports page
	And I click on home
	









