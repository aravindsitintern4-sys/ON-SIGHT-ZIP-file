#@login @outReach_Event_setup
@surgeryAdvised_report

Feature: Surgery Advised Workflow

Scenario: Surgery Adviced Report
	And user clicks on "Surgery Advised" option
	Then user is navigated to "Surgery Advised" page

	
Scenario Outline: Surgery advised report patient Valid test datas
	And user selects campId "<campidPlace>"
	And user clicks submit button
	Then selected data "<campidPlace>" details should be displayed
Examples:
      | campidPlace |
      | 25          |
      | 12          |	


# NEGATIVE SCENARIO
Scenario Outline: Surgery Advised report patient invalid test datas
	And user selects campId "<campidPlace>"
	Then no items found message should be displayed in dropdown
	And user clicks submit button
Examples:
      | campidPlace |
      | 188888888   |
      | ghvchgcghch |
      

# PAGEINATION
Scenario: Pagination workflow using action buttons Next and Previous in surgery advice
	And user selects campId "24"
	And user clicks submit button
	Then selected data "24" details should be displayed
	
	And user clicks on Next button
	Then page "2" should be active
	
	And user clicks on Previous button
	Then page "1" should be active

Scenario: Pagination actions using page number in surgery advice
	And user selects campId "24"
	And user clicks submit button
	Then selected data "24" details should be displayed
	
	And user clicks on page "2"
	Then page "2" should be active
	
	And user clicks on page "1"
	Then page "1" should be active
	Then Previous button should be disabled

# EXPORT EXCEL ----> FILE DOWNLOAD
Scenario: Export Pdf workflow in surgery advice
    And user selects campId "25"
    And user clicks submit button
    Then selected data "25" details should be displayed
    And user clicks on Export button
    Then file should be downloaded successfully
    Then screenshot should be captured "surgery_advised_25"
    And user waits for "5" seconds
	And user clicks close button
	Then user navigated to the reports page
	And user clicks on home
	









