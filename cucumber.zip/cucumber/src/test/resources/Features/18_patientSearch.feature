#@login 
#@outReach_Event_setup
@patient_Status_Search_clinical_records

Feature: Patient status search workflow

# PATIENT STATUS SEARCH ICON ACTIONS 
Scenario: Patient status search workflow
	And user clicks patient status search icon 
	Then popup "Patient Status" should be displayed 

# NEGATIVE SCENARIO		
Scenario Outline: OID field invalid datas
  When user enters OID "<oid>" common
  And user clicks on Search icon
  Then error message "Invalid OID" should be displayed

Examples:
  | oid           |
  | DD-00041-0029 |
  | D00041-0029   |
  | D-0004-0029   |
  | D-00041-029   |
  | 1-00041-0029  |	 
	
Scenario: Expired OID Validation
  When user enters OID "D-00041-0040" common
  And user clicks on Search icon
  Then error message "This patient has not registered today in this camp" should be displayed
	
Scenario: Valid OID Validation
  When user enters OID "C-00025-0026" common
  And user clicks on Search icon
  Then "Patient Status" existing details should be displayed
  And user clicks close button
  Then user navigated to the clinical records dashboard page












    