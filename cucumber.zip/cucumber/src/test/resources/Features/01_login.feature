@login

Feature: Login Feature

Background:
  Given user is on login page

#Scenario: Login with Empty credentials
  #And user enters username "" and password ""
  #Then login button should be disabled
  
# NEGATIVE SCENARIO
#Scenario Outline: Login with multiple invalid data
  #And user enters username "<username>" and password "<password>"
  #And clicks on login button
  #Then error message should be displayed

#Examples:
 # | username | password     |
 # | 156      | wrong123     |
 # | 999      | Sabitha@123  |
 # | abc      | abc123       |
  
  
Scenario: Valid Login
  And user enters username "156" and password "Sabitha@123"
  And clicks on login button
  Then user is navigated to outReach Event setup page 