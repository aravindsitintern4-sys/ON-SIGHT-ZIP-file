@login

Feature: Login Feature

Background: 
  Given initially on login page

Scenario: Login with Empty credentials
  And I enter username "" and password ""
  Then login button should be disabled
 
Scenario: Login with Empty credentials
  And I enter username "abc" and password "abc123"
  And I click on login button
  Then "Username must contain only numeric digits" toast should be displayed
  
# NEGATIVE SCENARIO
Scenario Outline: Login with multiple invalid data
  And I enter username "<username>" and password "<password>"
  And I click on login button
  Then "Invalid username or password." toast should be displayed

Examples:
  | username | password     |
  | 156      | wrong123     |
  | 999      | Sabitha@123  |

  

#POSITIVE SCENARIO 
Scenario: Valid Login
  And I enter username "156" and password "Sabithak@123"
  And I click on login button
  Then I navigated to outReach Event setup page 
  