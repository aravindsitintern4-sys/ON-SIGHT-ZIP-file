@login

Feature: Login Feature

Background:
  Given initially on login page

Scenario: Login with Empty credentials
  And I enter username "" and password ""
  Then login button should be disabled
  
# NEGATIVE SCENARIO
Scenario Outline: Login with multiple invalid data
  And I enter username "<username>" and password "<password>"
  And I click on login button
  Then error message should be displayed

Examples:
  | username | password     |
  | 156      | wrong123     |
  | 999      | Sabitha@123  |
  | abc      | abc123       |
  
  
Scenario: Valid Login
  And I enter username "156" and password "Sabitha@123"
  And I click on login button
  Then I navigated to outReach Event setup page 