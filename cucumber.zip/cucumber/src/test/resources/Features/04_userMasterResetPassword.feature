@login @outReach_Event_setup 
@user_master_resetPassword

Feature: User Master Delete Workflow

Scenario: user master actions
	And I click on user master option
	Then I navigated to the user master page
	And I clear search box 
 
#RESET PASSWORD
Scenario: Reset password Invalid and valid actions
      And I wait for "2" seconds
      And I clear search box
      When I enter id in search bar "174"
	  Then details for id "174" should be displayed
	  When I select checkbox for data "174" in table
	  Then selected checkbox data should be displayed "174"
	  Then edit and delete and reset password buttons should be enabled and new button should be disabled
	  And I click "Reset-Password" button
	  Then "Password reset successfully!" toast should be displayed
	  And I wait for "5" seconds
	  And I click on Logout 
	  Then I navigated into login page
	  And I enter username "174" and password "Pass@123"
	  And I wait for "2" seconds
	  And I click "Sign In" button  
	  Then I navigated to reset password page
	  And I wait for "1" seconds  
	  #EMPTY FIELD
	  And I enter old password ""
	  And I enter new password ""
	  Then old password Required alert should be appear  	
	  And I enter confirm password ""
	  Then new password Required alert should be appear
	  And I enter old password ""
	  Then confirm password Required alert should be appear
	  And I wait for "1" seconds 
	  #INVALID PASSWORDS
	  And I enter new password "abitha@456"
	  And I enter confirm password "thishf@123"
	  Then alert messege for new password should be displayed
	  And I enter old password "qwerrd@456"
	  Then alert messege for confirm password should be displayed
	  #VALID PASSWORD
	  And I enter old password "Pass@123"
	  And I enter new password "Klmno@456"
      And I enter confirm password "Klmno@456"
	  And I click "Save" button
	  And I enter username "174"
	  And I enter password "Klmno@456"
	  And I wait for "2" seconds 
	  And I click "Sign In" button
	  
Scenario: Event setup 
  	  And I wait for "1" seconds
  	  #When I select hospital "Aravind Eye Hospital-Madurai"
	  And I select eventId "1" 
	  And I click "Save" button
      Then I navigated to the dashboard page
      And I wait for "2" seconds
    

#Scenario: same pasword for last three times
	 #VALID PASSWORDS
	  #And I enter old password "Pass@123"
	 # And I enter new password "Sqatr@456"
      #And I enter confirm password "Sqatr@456"
	  #And I click "Save" button
	  #Then "Last 3 passwords cannot be reused." toast should be displayed
	  #And I wait for "5" seconds	