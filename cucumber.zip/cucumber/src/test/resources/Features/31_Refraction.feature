#@login @outReach_Event_setup
@refraction_clinical_records

Feature: Refraction workflow in clinical records

# GP ADVICE BEFORE FILL REFRACTION
Scenario: Without refraction GP workflow
	And I click "GP" button
	And I wait for "3" seconds
	Then "Please complete refraction or auto refraction before giving a glass prescription" toast should be displayed
	
Scenario: Refraction workflow
	And I click "Refraction" label option
	Then popup "Refraction" should be displayed     
	And I wait for "5" seconds        

# CURRENT SPECTACLES

Scenario: Current Spectacles error alert
	And I click "Save & Next" button in refraction
	Then I should see "This field cannot be empty" field error message
	
Scenario: Current Spectacles Details workflow
	And I select label as "Has Spectacles (or) Prescription?" and option as "No" in refraction
	And I select label as "Has Spectacles (or) Prescription?" and option as "Yes" in refraction
    # FOR ng-select
	And I select label as "Complaints:" option as "Defective vision" for dropdown in refraction
	And I enter "Complaints:" label details as "spec is good" in refraction
	And I click "Save & Next" button in refraction
	And I wait for "5" seconds
	
# CURRENT SPECTACLES --->  CURRENT SPECTACLES(1)	
Scenario: Empty fields in current spectacles part one
	#And I click "Clear" button in current spectacles part one
	#And user waits for "3" seconds
	And I click "Save & Next" button in current spectacles part one
	Then I should see "Please fill in the mandatory fields" field error message
	
Scenario: Current Spectacles part one - Usage
	# ONE LABEL ONE OPTION
	And I select label as "Usage:" and option as "Regular" in refraction
	And I select label as "Usage:" and option as "Irregular" in refraction
	And I select label as "Usage:" and option as "Discontinued" in refraction
	And I select label as "Usage:" and option as "Broken" in refraction
	And I select label as "Usage:" and option as "Has prescription only" in refraction

Scenario: Current Spectacles part one - Duration	
	And I click Duration field in refraction
	And I set duration value "12" in refraction
    And I set duration type "Day" in refraction 
    And I set duration value "12" in refraction
    And I set duration type "Week" in refraction
	And I click "Ok" button in duration in refraction

Scenario: Current Spectacles part one - Type of spectacle
	And I select label as "Type of spectacle:" and option as "DV Only" in refraction
	And I select label as "Type of spectacle:" and option as "NV Only" in refraction
	And I select label as "Type of spectacle:" and option as "Myopia Control Lens" in refraction
	# ONE LABEL ONE SELECT
	And I select label "Type of spectacle:" option "Executive Bifocal" for selection dropdown in refraction

Scenario: Current Spectacles part one - Lens details
	And I select label as "Lens details:" and option as "Glass" in refraction
	And I select label as "Lens details:" and option as "Plastic" in refraction
	And I select label as "Lens details:" and option as "White" in refraction
	And I select label as "Lens details:" and option as "Tint" in refraction
	And I select label as "Lens details:" and option as "Photochromic" in refraction
	And I select label as "Lens details:" and option as "AR Coat" in refraction

Scenario: Current Spectacles part one - Prism
	And I select label as "Prism:" and option as "RE" in refraction
	And I select label as "Prism:" and option as "LE" in refraction
	#TWO LABELS (SELECT)
	And I select main label "RE:" sub label "Prism type:" option "Glass Mounted Prism" for selection dropdown in refraction
	# TWO LABELS INPUT
	And I enter "RE:" parent label "Prism type:" childlabel details as "11" in refraction
	And I select main label "RE:" sub label "Orientation:" option "Base in" for selection dropdown in refraction
	And I select main label "LE:" sub label "Prism type:" option "Peli Prism" for selection dropdown in refraction
	And I enter "LE:" parent label "Prism type:" childlabel details as "11" in refraction
	And I select main label "LE:" sub label "Orientation:" option "Base Out" for selection dropdown in refraction
	
Scenario: Current Spectacles part one - Condition
	# ONE LABEL ONE OPTION NG SELECT
	And I select label as "Condition:" and option as "Good" in refraction
	And I select label as "Condition:" option as "Frame Broken" for dropdown in refraction
	
Scenario: Current Spectacles part one - Fitting of spectacle
	And I select label as "Fitting of spectacle:" and option as "Good" in refraction
	And I select label "Fitting of spectacle:" option "Centering Problem" for selection dropdown in refraction	
	
Scenario: Current Spectacles part one - Satisfaction
	And I select label as "Satisfaction:" and option as "Satisfied" in refraction
	And I select label as "Satisfaction:" and option as "Not Satisfied" in refraction	
	
Scenario: Current Spectacles part one - DBOC
	And I enter "DBOC:" parent label "RE:" childlabel details as "11" in refraction
	And I enter "DBOC:" parent label "LE:" childlabel details as "11" in refraction
	
Scenario: Current Spectacles part one - Chart types	
	And I select label "Chart types:" option "LogMAR (Snellen equ)" for selection dropdown in refraction		

Scenario: Select values for refraction RE
	# RE
	And I select "+1.25" in "RE" for "Spherical" in refraction                                      
	And I select "-0.50" in "RE" for "Cylinder" in refraction 
	And I select "90" in "RE" for "Axis" in refraction
	And I select "6/6P" in "RE" for "V/A with CS" in refraction
	And I select "1.25" in "RE" for "+Spherical" in refraction
	And I select "N8" in "RE" for "NV" in refraction
	And I move to "LE" refraction section

Scenario: Select values for refraction LE
	# LE
	And I select "+1.25" in "LE" for "Spherical" in refraction
	And I select "+0.50" in "LE" for "Cylinder" in refraction
	And I select "90" in "LE" for "Axis" in refraction
	And I select "6/6P" in "LE" for "V/A with CS" in refraction
	And I select "1.25" in "LE" for "+Spherical" in refraction
	And I select "N7" in "LE" for "NV" in refraction	

Scenario: Remarks in Current Spectacles part one
	And I enter Remarks as "Current Spectacles part one remark entered" in refraction
	
Scenario: Summary display in current spectacles part one
	Then current spectacles summary should be displayed
	
Scenario: Actions for buttons in Current spectacles Part one
	And I click "Save & Next" button in current spectacles part one
	#And I click "Save & Add" button in current spectacles part one
	#And I click "Clear" button in current spectacles part one
	And I wait for "5" seconds


# CURRENT SPECTACLES --->  CURRENT SPECTACLES(2)
#Scenario: Current Spectacles part two Details workflow
	#And I click "Current Spectacles(2)" option in refraction	

	
# CURRENT SPECTACLES --->  CURRENT SPECTACLES(3)	
#Scenario: Current Spectacles part three Details workflow
	#And I click "Current Spectacles(3)" option in refraction	

# UNDILATED RR 
#DYNAMIC RR
Scenario: Undilated RR Details workflow
	And I click "Undilated RR" option in refraction
		
Scenario: Dyn RR Details workflow
	And I click "Dyn.RR" sub option in Undilated RR
	
Scenario: Empty fields in Undilated RR
	And I click "Save & Next" button in dynamic RR
	#And I click "Clear" button in dynamic RR
	#And I click "Update & Next" button in dynamic RR
	Then I should see "Please fill in the mandatory fields" field error message

Scenario: working distance Dynamic RR
	And I enter "Working distance:" label details as "80" in undialated RR
	
Scenario: Select Retinoscopy values for RE
# RE
	And I wait for "3" seconds
	And I move to "RE" refraction section
	And I select "130" in "RE" for "Diopter Values (90's)" in refraction
	And I select "+1.25" in "RE" for "Diopter Values (90's)" in refraction
	And I select "180" in "RE" for "Diopter Values (180's)" in refraction
	And I select "-0.25" in "RE" for "Diopter Values (180's)" in refraction
	And I select "Dull Reflex" in "RE" for "Type of Reflex" in refraction
	And I wait for "1" seconds
	And I move to "LE" refraction section

Scenario: Select Retinoscopy values for LE
#LE  
	And I select "70" in "LE" for "Diopter Values (90's)" in refraction
	And I select "+2.25" in "LE" for "Diopter Values (90's)" in refraction
	And I select "145" in "LE" for "Diopter Values (180's)" in refraction
	And I select "-0.50" in "LE" for "Diopter Values (180's)" in refraction
	And I select "Peripheral Reflex" in "LE" for "Type of Reflex" in refraction             
	    
Scenario: Remarks in Dynamic RR
	And I enter Remarks as "Dynamic RR remark entered" in refraction

Scenario: Summary display in Undilated RR
	Then undilated RR summary should be displayed
	
Scenario: Save action in dynamic RR
	And I click "Save & Next" button in dynamic RR
	And I wait for "5" seconds

# SUB RR DV

Scenario: Sub.RR DV Details workflow
	And I click "Sub.RR DV" sub option in Undilated RR
	
Scenario: Empty fields in Sub.RR DV
	And I click "Save & Next" button in Sub.RR DV
	#And I click "Clear" button in dynamic RR
	#And I click "Update & Next" button in dynamic RR
	Then I should see "Please fill in the mandatory fields" field error message
	
Scenario: Sub.RR DV - Chart types	
	And I select label "Chart types:" option "LogMAR (Snellen equ)" for selection dropdown in sub rr dv
		
Scenario: Select Refractions values in sub RR DV for RE
# RE
	And I wait for "3" seconds
	And I move to "RE" refraction section
	And I select "6/3P" in "RE" for "UCVA" in refraction
	And I select "+1.25" in "RE" for "Spherical" in refraction
	And I select "-0.50" in "RE" for "Cylinder" in refraction
	And I select "90" in "RE" for "Axis" in refraction
	And I select "6/6P" in "RE" for "BCVA" in refraction
	And I select "6/12P" in "RE" for "PH BCVA" in refraction
	And I select "11" in "RE" for "MPD" in refraction
	And I wait for "1" seconds
	And I move to "LE" refraction section

Scenario: Select Refractions values in sub RR DV for LE
#LE 
	And I select "12" in "LE" for "MPD" in refraction	
	And I select "6/12P" in "LE" for "UCVA" in refraction
	And I select "+0.25" in "LE" for "Spherical" in refraction
	And I select "-0.25" in "LE" for "Cylinder" in refraction
	And I select "85" in "LE" for "Axis" in refraction
	And I select "6/12P" in "LE" for "BCVA" in refraction
	And I select "6/15P" in "LE" for "PH BCVA" in refraction
	

Scenario: Occupation in Sub.RR DV
	And I select label as "Occupation:" option as "Actor" for dropdown in refraction
	And I enter "Occupation:" label details as "Occupation is entered" for input field

Scenario: Remarks in Sub.RR DV
	And I select label as "Remarks:" option as "BE any correction not taken" for dropdown in refraction
	And I enter "Remarks:" label details as "Remarks is entered" for input field
	
Scenario: Summary display in Undilated RR
	Then undilated RR summary should be displayed
	
Scenario: Save action in Sub RR DV
	And I click "Save & Next" button in Sub.RR DV
	And I wait for "5" seconds

# SUB RR NV
Scenario: Sub.RR NV Details workflow
	And I click "Sub.RR NV" sub option in Undilated RR
	
Scenario: Empty fields in Sub.RR NV
	And I click "Save & Next" button in Sub.RR NV
	Then I should see "Please fill in the mandatory fields" field error message
		
Scenario: Select Refractions values in sub RR NV for RE
# RE
	And I wait for "3" seconds
	And I move to "RE" refraction section
	And I select "N7" in "RE" for "UCNV" in refraction
	And I select "3.50" in "RE" for "Spherical" in refraction
	And I select "N7" in "RE" for "Vision" in refraction
	And I select "10" in "RE" for "Distance" in refraction
	And I select "FRD" in "RE" for "Distance" in refraction
	And I select "1.50" in "RE" for "Intermediate Spherical" in refraction
	And I select "0.1" in "RE" for "LogMAR" in refraction
	And I select "6/12" in "RE" for "Snellen Equ" in refraction
	And I select "11" in "RE" for "Near PD" in refraction
	And I wait for "1" seconds
	And I move to "LE" refraction section

Scenario: Select Refractions values in sub RR DV for LE
#LE 
	And I select "N8" in "LE" for "UCNV" in refraction
	And I select "1.25" in "LE" for "Spherical" in refraction
	And I select "N12" in "LE" for "Vision" in refraction
	And I select "20" in "LE" for "Distance" in refraction
	And I select "FRD" in "LE" for "Distance" in refraction
	And I select "2.00" in "LE" for "Intermediate Spherical" in refraction
	And I select "0.2" in "LE" for "LogMAR" in refraction
	And I select "6/6" in "LE" for "Snellen Equ" in refraction
	And I select "12" in "LE" for "Near PD" in refraction

Scenario: Remarks in Sub.RR NV
	And I select label as "Remarks:" option as "AX Verified" for dropdown in refraction
	And I enter "Remarks:" label details as "Remarks is entered" for input field
	
Scenario: Summary display in SUB RR NV
	Then undilated RR summary should be displayed
	
Scenario: Save action in Sub RR DV
	And I click "Save & Next" button in Sub.RR NV
	And I wait for "5" seconds

# ADDITIONAL INFO

Scenario: Additional Info Details workflow
	And I click "Additional Info" option in refraction
	
Scenario: Empty fields in Additional info
	And I click "Save & Next" button in add info
	Then I should see "Please fill in the mandatory fields" field error message
		
Scenario: Select Additional details - MH present
	And I select label as "MH present?:" and option as "No" in refraction
	And I select label as "MH present?:" and option as "Yes" in refraction

Scenario: Select Additional details - Need dilation refraction
	And I select label as "Need dilation refraction?:" and option as "No" in refraction
	And I select label as "Need dilation refraction?:" and option as "Yes, Tropicamide" in refraction
	And I select label as "Need dilation refraction?:" and option as "Yes, Cyclo" in refraction
	
Scenario: Select Additional details - Comfortable with current spectacles
	And I select label as "Comfortable with current spectacles?:" and option as "No" in refraction
	And I select label as "Comfortable with current spectacles?:" and option as "Yes" in refraction
	
Scenario: Select Additional details - Want spectacles
	And I select label as "Want spectacles?:" and option as "No" in refraction
	And I select label as "Want spectacles?:" and option as "Yes" in refraction
	
Scenario: Select Additional details - Test used
	And I select label "Test used:" option "Worth Four Dot" for selection dropdown in add info
	
Scenario: Select Additional details - Distance vision
	And I select label as "Distance vision:" and option as "Not Done" in refraction
	And I select label as "Distance vision:" and option as "Present" in refraction
	And I select label as "Distance vision:" and option as "Absent" in refraction
	
Scenario: Select Additional details - Near vision
	And I select label as "Near vision:" and option as "Not Done" in refraction
	And I select label as "Near vision:" and option as "Present" in refraction
	And I select label as "Near vision:" and option as "Absent" in refraction
	
Scenario: Select Additional details - Diplopia present
	And I select label as "Diplopia present?:" and option as "Not Done" in refraction
	And I select label as "Diplopia present?:" and option as "No Diplopia" in refraction
	And I select label as "Diplopia present?:" and option as "Diplopia+" in refraction
	
Scenario: Select Additional details - Confrontation fields:
	And I select label as "Confrontation fields:" and option as "Not Done" in refraction
	And I select label as "Confrontation fields:" and option as "Done" in refraction
	And I select label as "RE:" and option as "Normal" in refraction
	And I select label as "RE" and option as "Defective" in refraction
	And I select label as "LE:" and option as "Normal" in refraction
	And I select label as "LE:" and option as "Defective" in refraction

Scenario: Advice in Additional info
	And I select label as "Advice:" option as "Low vision" for ng dropdown in add info
	And I enter "Advice:" label details as "Advice is entered" for input field in add info
	
Scenario: Summary display in Additional Info
	Then additional info summary should be displayed
	
Scenario: Save action in Additional info
	And I click "Save & Next" button in add info
	And I wait for "5" seconds

# DILATED
Scenario: Dilated Details workflow
	And I wait for "5" seconds
	And I click "Dilated" option in refraction

# DYNAMIC RR DILATED	
Scenario: Empty fields in Dilated
	And I click "Save & Next" button in dilated
	Then I should see "Please fill in the mandatory fields" field error message
		
Scenario: working distance Dilated
	And I enter "Working distance:" label details as "70" in undialated RR
	
Scenario: DrugName Dilated
	And I select label as "Drug name:" and option as "Tropicamide Plus" in dilated     
	
Scenario: Select Dilated values for RE
# RE
	And I wait for "3" seconds
	And I move to "RE" refraction section
	And I select "130" in "RE" for "Diopter Values (90's)" in refraction                
	And I select "+1.25" in "RE" for "Diopter Values (90's)" in refraction
	And I select "180" in "RE" for "Diopter Values (180's)" in refraction
	And I select "-0.25" in "RE" for "Diopter Values (180's)" in refraction
	And I select "Dull Reflex" in "RE" for "Type of Reflex" in refraction
	And I wait for "1" seconds
	And I move to "LE" refraction section

Scenario: Select Dilated values for LE
#LE  
	And I select "70" in "LE" for "Diopter Values (90's)" in refraction
	And I select "+2.25" in "LE" for "Diopter Values (90's)" in refraction
	And I select "145" in "LE" for "Diopter Values (180's)" in refraction
	And I select "-0.50" in "LE" for "Diopter Values (180's)" in refraction
	And I select "Peripheral Reflex" in "LE" for "Type of Reflex" in refraction             
	    
Scenario: Remarks in Dilated
	And I enter Remarks as "Dilated remark entered" in refraction
	
Scenario: Summary display in Dilated
	Then undilated RR summary should be displayed
	
Scenario: Save action in Dilated
	And I click "Save & Next" button in dilated
	And I wait for "5" seconds


# SUB RR DV DILATED

# SUB RR DV DILATED
Scenario: Empty fields in Sub.RR DV Dilated
	And I click "Save & Next" button in Sub.RR DV
	#And I click "Clear" button in dynamic RR
	#And I click "Update & Next" button in dynamic RR
	Then I should see "Please fill in the mandatory fields" field error message
	
Scenario: Sub.RR DV - Chart types Dilated
	And I select label "Chart types:" option "LogMAR (Snellen equ)" for selection dropdown in sub rr dv
		
Scenario: Select Refractions values in sub RR DV for RE Dilated
# RE
	And I wait for "3" seconds
	And I move to "RE" refraction section
	And I select "6/3P" in "RE" for "UCVA" in refraction
	And I select "+1.25" in "RE" for "Spherical" in refraction
	And I select "-0.50" in "RE" for "Cylinder" in refraction
	And I select "90" in "RE" for "Axis" in refraction
	And I select "6/6P" in "RE" for "BCVA" in refraction
	And I select "6/12P" in "RE" for "PH BCVA" in refraction
	And I select "11" in "RE" for "MPD" in refraction
	And I wait for "1" seconds
	And I move to "LE" refraction section

Scenario: Select Refractions values in sub RR DV for LE Dilated
#LE 
	And I select "12" in "LE" for "MPD" in refraction	
	And I select "6/12P" in "LE" for "UCVA" in refraction
	And I select "+0.25" in "LE" for "Spherical" in refraction
	And I select "-0.25" in "LE" for "Cylinder" in refraction
	And I select "85" in "LE" for "Axis" in refraction
	And I select "6/12P" in "LE" for "BCVA" in refraction
	And I select "6/15P" in "LE" for "PH BCVA" in refraction
	

Scenario: Occupation in Sub.RR DV Dilated
	And I select label as "Occupation:" option as "Actor" for dropdown in refraction
	And I enter "Occupation:" label details as "Occupation is entered" for input field

Scenario: Remarks in Sub.RR DV Dilated
	And I select label as "Remarks:" option as "BE any correction not taken" for dropdown in refraction
	And I enter "Remarks:" label details as "Remarks is entered" for input field
	
Scenario: Summary display in Undilated RR Dilated Sub RR DV
	Then undilated RR summary should be displayed
	
Scenario: Save action in Sub RR DV Dilated
	And I click "Save & Next" button in Sub.RR DV
	And I wait for "5" seconds

#REPEAT

Scenario: Repeat Details workflow
	And I click "Repeat" option in refraction
	
# REPEAT DYN RR		

Scenario: Repeat Dyn RR Details workflow
	And I click "Repeat Dyn.RR" sub option in Undilated RR
	
Scenario: Empty fields in Undilated RR Repeat
	And I click "Save & Next" button in dynamic RR
	#And I click "Clear" button in dynamic RR
	#And I click "Update & Next" button in dynamic RR
	Then I should see "Please fill in the mandatory fields" field error message

Scenario: working distance Repeat Dynamic RR
	And I enter "Working distance:" label details as "80" in undialated RR 
	
Scenario: Select Retinoscopy values for RE Repeat Dynamic RR
# RE
	And I wait for "3" seconds
	And I move to "RE" refraction section
	And I select "130" in "RE" for "Diopter Values (90's)" in refraction
	And I select "+1.25" in "RE" for "Diopter Values (90's)" in refraction
	And I select "180" in "RE" for "Diopter Values (180's)" in refraction
	And I select "-0.25" in "RE" for "Diopter Values (180's)" in refraction
	And I select "Dull Reflex" in "RE" for "Type of Reflex" in refraction
	And I wait for "1" seconds
	And I move to "LE" refraction section

Scenario: Select Retinoscopy values for LE Repeat Dynamic RR
#LE  
	And I select "70" in "LE" for "Diopter Values (90's)" in refraction
	And I select "+2.25" in "LE" for "Diopter Values (90's)" in refraction
	And I select "145" in "LE" for "Diopter Values (180's)" in refraction
	And I select "-0.50" in "LE" for "Diopter Values (180's)" in refraction
	And I select "Peripheral Reflex" in "LE" for "Type of Reflex" in refraction             
	    
Scenario: Remarks in Repeat Dynamic RR
	And I enter Remarks as "Dynamic RR remark entered" in refraction

Scenario: Summary display in Repeat Dynamic RR
	Then undilated RR summary should be displayed
	
Scenario: Save action in Repeat Dynamic RR
	And I click "Save & Next" button in dynamic RR
	And I wait for "5" seconds

# REPEAT SUB RR DV

Scenario: Repeat Sub.RR DV Details workflow
	And I click "Repeat Sub.RR DV" sub option in Undilated RR
	
Scenario: Empty fields in Repeat Sub.RR DV
	And I click "Save & Next" button in Sub.RR DV
	#And I click "Clear" button in dynamic RR
	#And I click "Update & Next" button in dynamic RR
	Then I should see "Please fill in the mandatory fields" field error message
	
Scenario: Repeat Sub.RR DV - Chart types	
	And I select label "Chart types:" option "LogMAR (Snellen equ)" for selection dropdown in sub rr dv
		
Scenario: Select Refractions values in Repeat Sub.RR DV for RE
# RE
	And I wait for "3" seconds
	And I move to "RE" refraction section
	And I select "6/3P" in "RE" for "UCVA" in refraction
	And I select "+1.25" in "RE" for "Spherical" in refraction
	And I select "-0.50" in "RE" for "Cylinder" in refraction
	And I select "90" in "RE" for "Axis" in refraction
	And I select "6/6P" in "RE" for "BCVA" in refraction
	And I select "6/12P" in "RE" for "PH BCVA" in refraction
	And I select "11" in "RE" for "MPD" in refraction
	And I wait for "1" seconds
	And I move to "LE" refraction section

Scenario: Select Refractions values in Repeat Sub.RR DV for LE
#LE 
	And I select "12" in "LE" for "MPD" in refraction	
	And I select "6/12P" in "LE" for "UCVA" in refraction
	And I select "+0.25" in "LE" for "Spherical" in refraction
	And I select "-0.25" in "LE" for "Cylinder" in refraction
	And I select "85" in "LE" for "Axis" in refraction
	And I select "6/12P" in "LE" for "BCVA" in refraction
	And I select "6/15P" in "LE" for "PH BCVA" in refraction
	

Scenario: Occupation in Repeat Sub.RR DV
	And I select label as "Occupation:" option as "Actor" for dropdown in refraction
	And I enter "Occupation:" label details as "Occupation is entered" for input field

Scenario: Remarks in Repeat Sub.RR DV
	And I select label as "Remarks:" option as "BE any correction not taken" for dropdown in refraction
	And I enter "Remarks:" label details as "Remarks is entered" for input field
	
Scenario: Summary display in Repeat Sub.RR DV
	Then undilated RR summary should be displayed
	
Scenario: Save action in Repeat Sub.RR DV
	And I click "Save & Next" button in Sub.RR DV
	And I wait for "5" seconds

# REPEAT SUB RR NV

Scenario: Repeat Sub.RR NV Details workflow
	And I click "Repeat Sub.RR NV" sub option in Undilated RR
	
Scenario: Empty fields in Repeat Sub.RR NV 
	And I click "Save" button in Sub.RR NV
	Then I should see "Please fill in the mandatory fields" field error message
		
Scenario: Select Refractions values in Repeat Sub.RR NV  for RE
# RE
	And I wait for "3" seconds
	And I move to "RE" refraction section
	And I select "N7" in "RE" for "UCNV" in refraction
	And I select "3.50" in "RE" for "Spherical" in refraction
	And I select "N7" in "RE" for "Vision" in refraction
	And I select "10" in "RE" for "Distance" in refraction
	And I select "FRD" in "RE" for "Distance" in refraction
	And I select "1.50" in "RE" for "Intermediate Spherical" in refraction
	And I select "0.1" in "RE" for "LogMAR" in refraction
	And I select "6/12" in "RE" for "Snellen Equ" in refraction
	And I select "11" in "RE" for "Near PD" in refraction
	And I wait for "1" seconds
	And I move to "LE" refraction section

Scenario: Select Refractions values in Repeat Sub.RR NV  for LE
#LE 
	And I select "12" in "LE" for "Near PD" in refraction
	And I select "N8" in "LE" for "UCNV" in refraction
	And I select "1.25" in "LE" for "Spherical" in refraction
	And I select "N12" in "LE" for "Vision" in refraction
	And I select "20" in "LE" for "Distance" in refraction
	And I select "FRD" in "LE" for "Distance" in refraction
	And I select "2.00" in "LE" for "Intermediate Spherical" in refraction
	And I select "0.2" in "LE" for "LogMAR" in refraction
	And I select "6/6" in "LE" for "Snellen Equ" in refraction
	
Scenario: Remarks in Repeat Sub.RR NV 
	And I select label as "Remarks:" option as "AX Verified" for dropdown in refraction
	And I enter "Remarks:" label details as "Remarks is entered" for input field
	
Scenario: Summary display in Repeat Sub.RR NV 
	Then undilated RR summary should be displayed
	
Scenario: Save action in Repeat Sub.RR NV 
	And I click "Save" button in Sub.RR NV
	And I wait for "5" seconds

#REPEAT DILATED 

Scenario: Repeat dilated Details workflow
	And I click "Repeat Dilated" option in refraction

# REPEATED DIALATED RR 	

Scenario: Empty fields in Repeat Dilated
	And I click "Save & Next" button in dilated
	Then I should see "Please fill in the mandatory fields" field error message
		
Scenario: working distance Repeat Dilated
	And I enter "Working distance:" label details as "80" in undialated RR
	
Scenario: DrugName Dilated
	And I select label as "Drug name:" and option as "Tropicamide Plus" in dilated     
	
Scenario: Select Repeat Dilated values for RE
# RE
	And I wait for "3" seconds
	And I move to "RE" refraction section
	And I select "130" in "RE" for "Diopter Values (90's)" in refraction                
	And I select "+1.25" in "RE" for "Diopter Values (90's)" in refraction
	And I select "180" in "RE" for "Diopter Values (180's)" in refraction
	And I select "-0.25" in "RE" for "Diopter Values (180's)" in refraction
	And I select "Dull Reflex" in "RE" for "Type of Reflex" in refraction
	And I wait for "1" seconds
	And I move to "LE" refraction section

Scenario: Select Repeat Dilated values for LE
#LE  
	And I select "70" in "LE" for "Diopter Values (90's)" in refraction
	And I select "+2.25" in "LE" for "Diopter Values (90's)" in refraction
	And I select "145" in "LE" for "Diopter Values (180's)" in refraction
	And I select "-0.50" in "LE" for "Diopter Values (180's)" in refraction
	And I select "Peripheral Reflex" in "LE" for "Type of Reflex" in refraction             
	    
Scenario: Remarks in Repeat Dilated
	And I enter Remarks as "Repeat Dilated remark entered" in refraction
	
Scenario: Summary display in Repeat Dilated
	Then undilated RR summary should be displayed
	
Scenario: Save action in Repeat Dilated
	And I click "Save & Next" button in dilated
	And I wait for "5" seconds

# REPEAT SUB RR DV DILATED

Scenario: Empty fields in Sub.RR DV Repeat Dilated
	And I click "Save" button in Sub.RR DV
	#And I click "Clear" button in dynamic RR
	#And I click "Update & Next" button in dynamic RR
	Then I should see "Please fill in the mandatory fields" field error message
	
Scenario: Sub.RR DV - Chart types Repeat Dilated
	And I select label "Chart types:" option "LogMAR (Snellen equ)" for selection dropdown in sub rr dv
		
Scenario: Select Refractions values in sub RR DV for RE Repeat Dilated
# RE
	And I wait for "3" seconds
	And I move to "RE" refraction section
	And I select "6/3P" in "RE" for "UCVA" in refraction
	And I select "+1.25" in "RE" for "Spherical" in refraction
	And I select "-0.50" in "RE" for "Cylinder" in refraction
	And I select "90" in "RE" for "Axis" in refraction
	And I select "6/6P" in "RE" for "BCVA" in refraction
	And I select "6/12P" in "RE" for "PH BCVA" in refraction
	And I select "11" in "RE" for "MPD" in refraction
	And I wait for "1" seconds
	And I move to "LE" refraction section

Scenario: Select Refractions values in sub RR DV for LE Repeat Dilated
#LE 
	And I select "12" in "LE" for "MPD" in refraction	
	And I select "6/12P" in "LE" for "UCVA" in refraction
	And I select "+0.25" in "LE" for "Spherical" in refraction
	And I select "-0.25" in "LE" for "Cylinder" in refraction
	And I select "85" in "LE" for "Axis" in refraction
	And I select "6/12P" in "LE" for "BCVA" in refraction
	And I select "6/15P" in "LE" for "PH BCVA" in refraction
	
Scenario: Occupation in Sub.RR DV Repeat Dilated
	And I select label as "Occupation:" option as "Actor" for dropdown in refraction
	And I enter "Occupation:" label details as "Occupation is entered" for input field

Scenario: Remarks in Sub.RR DV Repeat Dilated
	And I select label as "Remarks:" option as "BE any correction not taken" for dropdown in refraction
	And I enter "Remarks:" label details as "Remarks is entered" for input field
	
Scenario: Summary display in Undilated RR Repeat Dilated Sub RR DV
	Then undilated RR summary should be displayed
	
Scenario: Save action in Sub RR DV Repeat Dilated
	And I click "Save" button in Sub.RR DV
	And I wait for "5" seconds

# GLASS PRESCRIPTION
Scenario: Glass Prescription Details workflow
	And I click "Glass Prescription" option in refraction
	
Scenario: Empty fields in Glass Prescription
	And I click "Save" button in Glass Prescription
	Then popup "Confirm" should be displayed
	And I click "No,edit again" button in window

Scenario: label click in glass prescription in refraction
	And I select "Subjective RR" RR type
	And I select "Dilated RR" RR type

Scenario: Lens type selection Glass prescription
	And I select lens types as "univis"
	And I select lens types as "executive"
	And I select lens types as "kryptok"
	And I select lens types as "pal"

Scenario: Lens details Glass prescription
	And I select label as "Lens details:" and option as "Glass" in refraction
	And I select label as "Lens details:" and option as "Plastic" in refraction
	And I select label as "Lens details:" and option as "White" in refraction
	And I select label as "Lens details:" and option as "Photochromic" in refraction
	And I select label as "Lens details:" and option as "AR Coat" in refraction
	And I select label as "Lens details:" and option as "Tint" in refraction
	
Scenario: Tint Details 
	And I select "Tint colour" from "Blue" in glass prescription in refraction
	And I select "Tint type" from "ET4 - Sun Blue" in glass prescription in refraction

Scenario: Glass prescription - Prism
	And I select label as "Prism:" and option as "LE" in refraction
	And I select label as "Prism:" and option as "RE" in refraction
	And I select main label "LE:" sub label "Prism type:" option "Glass Mounted Prism" for selection dropdown in refraction
	And I enter "LE" as parentLabel "Prism type:" as childLabel data as "11" for input field in refraction on Repeat
	And I select main label "LE:" sub label "Orientation:" option "Base in" for selection dropdown in refraction
	And I select main label "RE:" sub label "Prism type:" option "Peli Prism" for selection dropdown in refraction
	And I enter "RE" as parentLabel "Prism type:" as childLabel data as "11" for input field in refraction on Repeat
	And I select main label "RE:" sub label "Orientation:" option "Base Out" for selection dropdown in refraction

Scenario: Instruction Glass prescription
	And I select label as "Instruction:" and option as "Near Vision Only" in refraction
	And I select label as "Instruction:" and option as "Distance Vision Only" in refraction
	And I select label as "Instruction:" and option as "Constant Wear" in refraction
	And I select label as "Instruction:" and option as "Vocational Use" in refraction

Scenario: Remarks in Glass prescription
	And I select label "Remarks:" option "Same PG" for selection dropdown in refraction on GP
	And I enter "Remarks:" label details as "GP Remarks is entered" for input field in refraction on GP

Scenario: Summary display in Glass Prescription
	Then refraction glass prescription summary should be displayed
	
Scenario: Save actions in Glass prescription 
	And I click "Save" button in Glass Prescription
	Then popup "Confirm" should be displayed
	And I click "Yes, proceed" button in window
	And I click "Proceed and Save" button in window
	
Scenario: Refraction summary displayed in doctor screen
	Then Refraction summary should be displayed

              
                
	
	
	






	



	













	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	