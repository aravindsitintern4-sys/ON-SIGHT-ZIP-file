@login  @outReach_Event_setu
@edit_patient_details

Feature: Edit Patient details in Registration

Scenario: Click Registration actions
	When I click on Registration option
	Then patient should be navigated to the registration page

Scenario: Edit Vaildation with Empty credentials for OID
  And I click "Edit" button
  Then edit popup should be displayed
  And I enter OID "" for edit
  And I click on Search icon in edit
  Then update button should be disabled
  And I click "Cancel" button from popup
  
Scenario: Edit Vaildation with patient  not reg today old OID
  And I click "Edit" button
  Then edit popup should be displayed
  And I enter OID "D-00041-0036" for edit
  And I click on Search icon in edit
  And error message "Patients not registered today cannot be edited." should be displayed in edit
  And I click "Cancel" button from popup

#RECALL TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: OID field validation in Edit
  And I click "Edit" button
  And I enter OID "<oid>" for edit
  And I click on Search icon in edit
  Then I should see OID validation message "No data available for the given UID!"
  And I click "Ok" button from popup
  And I click "Cancel" button from popup

Examples:
  | oid           |
  | DD-00041-0029 |	
  | D00041-0029	  |
  | D-0004-0029	  |
  | D-00041-029	  |
  | 1-00041-0029  |	    


# VALID EDIT TEST DATAS

Scenario: Edit a patient

  And I click "Edit" button
  Then edit popup should be displayed
  # GIVE TODAY REGISTERED OID
  And I enter OID "C-00001-0225" for edit
  And I click on Search icon in edit
  And I click "Update" button from popup
   
  And I enter Age "29"
  And I click "Update" button
  
  And I wait for "3" seconds
  And I capture and store the generated OID and PIN from registration popup
  
  And I wait for "3" seconds
  And I click "Ok" button from popup
  Then print preview should be displayed
  And I click "Close" button
  
  And I click "Cancel" button





  