@login @outReach_Event_setup
@outReach_master_NewEvent

Feature: OutReach Master Workflow

# OUTREACH EVENT MASTER
Scenario: OutReach Master actions 
   And I click on outReach event master option
   Then I navigated to the outreach event master page
   And I wait for "2" seconds
   Then edit and delete buttons should be disable initially
       
Scenario: New button work
   And I click "New" button
   Then popup "Outreach Event Master" should be displayed
   And I wait for "2" seconds
	
# ACTIVE STATUS ---> CHECK BOX	
Scenario: Active status checkbox validation
    And I click active checkbox
	And I click "Clear" button
		
# HOSPITAL	
Scenario Outline: Hospital validation
	And I select hospital "<hospitalName>" dropdown
	And I click "Clear" button
	
Examples:
  | hospitalName                  | 
  | Aravind Eye Hospital-Madurai  | 
  | Aravind Eye Hospital-Dindigul |	

Scenario: Empty credential for hospital
	And I click "Save" button
	Then I should see hospital name empty field validation in outreach
	And I click "Clear" button
	
# EVENT ORGANIZER NAME	
Scenario Outline: Organizer name validation
	And I select hospital "Aravind Eye Hospital-Madurai" dropdown
	And I select event organizer name "<orgName>" dropdown
	And I click "Clear" button
	
Examples:
  | orgName | 
  | Mad-org | 

	

Scenario: Vaildation for Invalid Organizer name
  And I select event organizer name "indian" dropdown
  Then no items found message should be displayed in dropdown
  And I click "Clear" button
  
Scenario: Empty credential for organizer name
	And I click "Save" button
	Then organizer name Required alert should be appear
	And I click "Clear" button
	  
# PLACE	
Scenario Outline: Place validation
	And I enter place "<placeName>"
	And I click "Clear" button
	
Examples:
  | placeName    | 
  | Madurai      | 
  | Salem-(main) |	

Scenario: Empty credential for Place
	And I click "Save" button
	Then place Required alert should be appear
	And I click "Clear" button
	
 # CITY / TALUK	
Scenario Outline: City Taluk validation
	And I select city "<cityName>" dropdown
	And I click "Clear" button
	
Examples:
  | cityName          | 
  | TADWAI            | 
  | RAMADUGU          |	
  
Scenario: Vaildation for Invalid city
  And I select city "Japan" dropdown
  Then no data found messege should be displayed in dropdown in event
  And I click "Clear" button

Scenario: Empty credential for City
	And I click save button in event popup
	Then city Required alert should be appear
	And I click "Clear" button
		
# DISTRICT	
Scenario Outline: District validation
	And I select district "<districtName>" dropdown
	And I click "Clear" button
	
Examples:
  | districtName      | 
  | Virudhunagar      | 
  | Salem             |	
  
Scenario: Vaildation for Invalid District
  And I select district "Japan" dropdown
  Then no data found messege should be displayed in dropdown in event
  And I click "Clear" button

Scenario: Empty credential for District
	And I click "Save" button
	Then district Required alert should be appear
	And I click "Clear" button		
	
# DISTANCE FROM HQ
Scenario Outline: Distance from HQ validation
	And I select distance "<distanceHQ>" dropdown
	And I click "Clear" button

Examples:
  | distanceHQ        | 
  | Nearby (5–10 km)  | 
  | Remote (> 60 km)  |	

Scenario: Empty credential for Distance from HQ
	And I click "Save" button
	Then Distance From HQ Required alert should be appear
	And I click "Clear" button
		
# LANGUAGE OF PRESCRIPTION  (CHANGE TEST DATA AND REQIRED FIELD NAME CHANGE AFTER FIX)
#Scenario Outline: Language of Prescription validation
	#And I select language of prescription "<languagePres>" dropdown
	#And I click clear button in event popup

#Examples:
  #| languagePres      | 
  #| Nearby (5–10 km)  | 
  #| Remote (> 60 km)  |	

#Scenario: Empty credential for Distance from HQ
	#And I click save button in event popup
	#Then Language for Prescription Required alert should be appear
	#And I click clear button in event popup
		
# START DATE  ---> (FOR PAST DATE VALIDATION CHANGE THE MONTH NAME INTO CURRENT MONTH FOR START AND END)
Scenario: Past start date should be disabled in date picker
    And I wait for "2" seconds
    And I click event start date calendar icon
    And I select start month "Jun"
	And I select start year "2026"
    Then past dates should be disabled in date picker
    And I click "Clear" button
    And I wait for "2" seconds
    
# END DATE
Scenario: Past end date should be disabled in date picker
    And I wait for "2" seconds
    And I click event end date calendar icon
	And I select start month "Jun"
	And I select start year "2026"
    Then past dates should be disabled in date picker
    And I click "Clear" button
    And I wait for "2" seconds
    	
Scenario: Start Date validation
    #START DATE
	And I click event start date calendar icon
    And I select start month "Jun"
	And I select start year "2026"
	And I select start date "25" from date picker
	And I click "Clear" button
	And I wait for "2" seconds

Scenario: Empty credential for Event Start date
	And I click "Save" button
	Then start date Required alert should be appear
	And I click "Clear" button
	And I wait for "2" seconds
	 	
Scenario: End Date validation
    And I wait for "2" seconds
    #END DATE
	And I click event end date calendar icon
	And I select end month "Jun"
	And I select end year "2026"
	And I select end date "30" from date picker
	And I click "Clear" button
	And I wait for "2" seconds

Scenario: Empty credential for Event End date
	And I click "Save" button
	Then end date Required alert should be appear
	And I click "Clear" button
	
# EVENT TYPE
Scenario Outline: Event Type validation
	And I select event type "<eventType>" dropdown
	And I click "Clear" button
   
Examples:
  | eventType            | 
  | DR Screening         | 
  | Workplace Screening  |	

Scenario: Empty credential for Event Type
	And I click "Save" button
	Then Event Type Required alert should be appear
	And I click "Clear" button
	
# EVENT LOCATION	
Scenario Outline: Event Location validation
	And I select event location "<eventLocation>" dropdown
	And I click "Clear" button
	
Examples:
  | eventLocation  | 
  | school         | 
  | camp           |	

Scenario: Empty credential for Event Location
	And I click "Save" button
	Then Event Location Required alert should be appear
	And I click "Clear" button
	
# PROJECT NAME
Scenario Outline: Project Name validation
	And I select project name "<projectName>" dropdown
	And I click "Clear" button
	
Examples:
  | projectName        | 
  | Mission for vision | 
  | Lions Sight First  |	

Scenario: Empty credential Poject name
	And I click "Save" button
	And I click "Clear" button
	
# LOCAL PARTNER
Scenario Outline: Local Partner validation
	And I enter local partner "<localPartnerName>"
	And I click "Clear" button
	
Examples:
  | localPartnerName | 
  | Local Test-41    | 
  | Main Test-(main) |	

Scenario: Empty credential for Local Partner
	And I click "Save" button
	And I click "Clear" button
	
# EXPECTED OP
Scenario Outline: Expected OP field validation
  And I enter expected op "<op>"
  Then validation for expected op field
  And I click "Clear" button

Examples:
  | op            |
  | g1thr@        |    
  | 987654        | 
  | 123456789012  |
  | 3643257886    | 

Scenario: Empty credential for Expected OP
	And I click "Save" button
	Then Expected op Required alert should be appear
	And I click "Clear" button
	
# EXPECTED IP
Scenario Outline: Expected IP field validation
  And I enter expected ip "<ip>"
  Then validation for expected ip field
  And I click "Clear" button

Examples:
  | ip            |
  | 102           |    
  | 987654        | 
  | 3643257886    | 

Scenario: Empty credential for Expected IP
	And I click "Save" button
	Then Expected ip Required alert should be appear
	And I click "Clear" button	
	
# EXPECTED SPECIALITY REFERRAL
Scenario Outline: Expected Speciality Referral field validation
  And I enter expected speciality referral "<specRef>"
  Then validation for expected speciality referral field
  And I click "Clear" button

Examples:
  | specRef       |
  | g100thr@      |    
  | 987654        | 
  | 120           |

Scenario: Empty credential for Expected Speciality Referral
	And I click "Save" button
	Then Expected speciality referral Required alert should be appear
	And I click "Clear" button
	
# EXPECTED GP
Scenario Outline: Expected GP field validation
  And I enter expected GP "<gp>"
  Then validation for expected GP field
  And I click "Clear" button

Examples:
  | gp            |
  | g100thr@      |    
  | 987654        |   
  | 120           |

Scenario: Empty credential for Expected GP
	And I click "Save" button
	Then Expected GP Required alert should be appear
	And I click "Clear" button
	
# IHMS CAMP ID
Scenario Outline: IHMS Camp Id validation
	And I enter camp id "<campid>" in event
	Then validation for IHMS camp id field
	And I click "Clear" button
	
Examples:
  | campid        | 
  | g1thr@        |    
  | 987654        | 
  | 123456789012  |
  | 3643257886    |	

Scenario: Empty credential for IHMS Camp Id
	And I click "Save" button
	And I click "Clear" button

	
# VALID TEST DATAS			
Scenario: Valid Test Datas for New event 
	And I wait for "2" seconds
	And I select hospital "Aravind Eye Hospital-Madurai" dropdown
	
	# Active is uncheck firsttime if we click ----> Checked always when we enter
	And I click active checkbox
	
	And I select event organizer name "Mad-org" dropdown	
	And I enter place "Madurai"
	And I wait for "5" seconds
	And I select city "INDI" dropdown
	And I press "ENTER" key
	And I wait for "2" seconds
	And I select district "Madurai" dropdown
	And I press "ENTER" key
	And I select distance "Remote (> 60 km)" dropdown
	
	# CHANGE TEST DATA AFTER FIX
	#And I select language of prescription "Nearby (5–10 km)" dropdown
		
	#START DATE
	And I click event start date calendar icon
    And I select start month "Jun"
	And I select start year "2026"
	And I select start date "19" from date picker
	Then selected date should be displayed in event start date field
	#END DATE
	And I click event end date calendar icon
	And I select end month "Jun"
	And I select end year "2026"
	And I select end date "30" from date picker
	Then selected date should be displayed in event end date field
	
	And I select event type "DR Screening" dropdown
	And I select event location "school" dropdown
	And I select project name "Mission for vision" dropdown
	And I enter local partner "Local-Test-41"

	And I enter expected op "579"
	And I enter expected ip "77"
	And I enter expected speciality referral "70"
	And I enter expected GP "86"
	
	And I enter camp id "23456" in event
	
	And I click "Save" button
	Then "Event created successfully" toast should be displayed
	#And I click "Clear" button
	#And I click "Cancel" button
	
Scenario: check the created event details
	And I wait for "2" seconds
	And I clear search box
	When I enter id in search bar "Mad-org"
    Then details for id "Mad-org" should be displayed
    When I select checkbox for data "Mad-org" in table
    Then selected checkbox data should be displayed "Mad-org"
    And I wait for "3" seconds
	
Scenario: Navigate to Hospital master Edit actions
	And I click on home
	And I click on master option
    And I navigated to the master page	
    
	
	
	