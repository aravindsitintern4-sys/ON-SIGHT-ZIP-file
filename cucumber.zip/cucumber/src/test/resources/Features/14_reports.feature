@login @outReach_Event_setup
@reports

Feature: Reports actions

Background:
    Given placed on dashboard page
    
Scenario: Reports actions
    And I click on reports option
    Then I navigated to the reports page


    
