@login @outReach_Event_setup
@reports

Feature: Reports actions

Background:
    Given user is on the dashboard page
    
Scenario: Reports actions
    And user clicks on reports option
    Then user navigated to the reports page


    
