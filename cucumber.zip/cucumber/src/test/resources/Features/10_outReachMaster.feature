@login @outReach_Event_setup
@outReach_master_NewEvent

Feature: OutReach Master Workflow

# OUTREACH EVENT MASTER
Scenario: OutReach Master actions 
   And I click on outReach event master option
   Then I navigated to the outreach event master page
   Then edit and delete buttons should be disable initially
       
Scenario: New button work
   When I click New button in outreach event master
   Then new event creation popup should be displayed
	
# ACTIVE STATUS ---> CHECK BOX	
Scenario: Active status checkbox validation
    And I click active checkbox
	And I click clear button in event popup
		
# HOSPITAL	
Scenario Outline: Hospital validation
	And I select hospital "<hospitalName>" dropdown
	And I click clear button in event popup
	
Examples:
  | hospitalName                         | 
  | Aravind Eye Hospital - Virudhunagar  | 
  | Aravind Eye Hospital - Salem         |	

Scenario: Empty credential for hospital
	And I click save button in event popup
	Then I should see hospital name empty field validation in outreach
	And I click clear button in event popup
	
# EVENT ORGANIZER NAME	
Scenario Outline: Organizer name validation
	And I select hospital "Aravind Eye Hospital - Virudhunagar" dropdown
	And I select event organizer name "<orgName>" dropdown
	And I click clear button in event popup
	
Examples:
  | orgName | 
  | Ram     | 
  | Priya   |
	

Scenario: Vaildation for Invalid Organizer name
  And I select event organizer name "indian" dropdown
  Then no items found message should be displayed in dropdown
  And I click clear button in event popup
  
Scenario: Empty credential for organizer name
	And I click save button in event popup
	Then organizer name Required alert should be appear
	And I click clear button in event popup	
	  
# PLACE	
Scenario Outline: Place validation
	And I enter place "<placeName>"
	And I click clear button in event popup
	
Examples:
  | placeName                         | 
  | Virudhunagar-41  | 
  | Salem-(main)     |	

Scenario: Empty credential for Place
	And I click save button in event popup
	Then place Required alert should be appear
	And I click clear button in event popup
	
 # CITY / TALUK	
Scenario Outline: City Taluk validation
	And I select city "<cityName>" dropdown
	And I click clear button in event popup
	
Examples:
  | cityName          | 
  | TADWAI            | 
  | RAMADUGU          |	
  
Scenario: Vaildation for Invalid city
  And I select city "Japan" dropdown
  Then no data found messege should be displayed in dropdown in event
  And I click clear button in event popup

Scenario: Empty credential for City
	And I click save button in event popup
	Then city Required alert should be appear
	And I click clear button in event popup 
		
# DISTRICT	
Scenario Outline: District validation
	And I select district "<districtName>" dropdown
	And I click clear button in event popup
	
Examples:
  | districtName      | 
  | Virudhunagar      | 
  | Salem             |	
  
Scenario: Vaildation for Invalid District
  And I select district "Japan" dropdown
  Then no data found messege should be displayed in dropdown in event
  And I click clear button in event popup

Scenario: Empty credential for District
	And I click save button in event popup
	Then district Required alert should be appear
	And I click clear button in event popup			
	
# DISTANCE FROM HQ
Scenario Outline: Distance from HQ validation
	And I select distance "<distanceHQ>" dropdown
	And I click clear button in event popup

Examples:
  | distanceHQ        | 
  | Nearby (5–10 km)  | 
  | Remote (> 60 km)  |	

Scenario: Empty credential for Distance from HQ
	And I click save button in event popup
	Then Distance From HQ Required alert should be appear
	And I click clear button in event popup
		
# LANGUAGE OF PRESCRIPTION  (CHANGE TEST DATA AND REQIRED FIELD NAME CHANGE AFTER FIX)
#Scenario Outline: Language of Prescription validation
	#And I select language of prescription "<languagePres>" dropdown
	#And I click clear button in event popup

#Examples:
  #| languagePres      | 
  #| Nearby (5–10 km)  | 
  #| Remote (> 60 km)  |	

#Scenario: Empty credential for Distance from HQ
	#And I click save button in event popup
	#Then Language for Prescription Required alert should be appear
	#And I click clear button in event popup
		
# START DATE  ---> (FOR PAST DATE VALIDATION CHANGE THE MONTH NAME INTO CURRENT MONTH FOR START AND END)
Scenario: Past start date should be disabled in date picker
    And I click event start date calendar icon
    And I select start month "Apr"
	And I select start year "2026"
    Then past dates should be disabled in date picker
    And I click clear button in event popup
    	
Scenario: Start Date validation
    And I click event start date calendar icon
    And I select start month "Nov"
	And I select start year "2027"
	And I select start date "15" from date picker
	Then selected date should be displayed in event start date field
	And I click clear button in event popup

Scenario: Empty credential for Event Start date
	And I click save button in event popup
	Then start date Required alert should be appear
	And I click clear button in event popup
	
# END DATE
Scenario: Past end date should be disabled in date picker
    And I click event end date calendar icon
	And I select start month "Apr"
	And I select start year "2026"
    Then past dates should be disabled in date picker
    And I click clear button in event popup
    	
Scenario: End Date validation
    And I click event end date calendar icon
	And I select end month "Nov"
	And I select end year "2027"
	And I select end date "15" from date picker
	Then selected date should be displayed in event end date field
	And I click clear button in event popup

Scenario: Empty credential for Event End date
	And I click save button in event popup
	Then end date Required alert should be appear
	And I click clear button in event popup
	
# EVENT TYPE
Scenario Outline: Event Type validation
	And I select event type "<eventType>" dropdown
	And I click clear button in event popup
   
Examples:
  | eventType            | 
  | DR Screening         | 
  | Workplace Screening  |	

Scenario: Empty credential for Event Type
	And I click save button in event popup
	Then Event Type Required alert should be appear
	And I click clear button in event popup
	
# EVENT LOCATION	
Scenario Outline: Event Location validation
	And I select event location "<eventLocation>" dropdown
	And I click clear button in event popup
	
Examples:
  | eventLocation  | 
  | school         | 
  | camp           |	

Scenario: Empty credential for Event Location
	And I click save button in event popup
	Then Event Location Required alert should be appear
	And I click clear button in event popup	
	
# PROJECT NAME
Scenario Outline: Project Name validation
	And I select project name "<projectName>" dropdown
	And I click clear button in event popup
	
Examples:
  | projectName        | 
  | Mission for vision | 
  | Lions Sight First  |	

Scenario: Empty credential Poject name
	And I click save button in event popup
	And I click clear button in event popup
	
# LOCAL PARTNER
Scenario Outline: Local Partner validation
	And I enter local partner "<localPartnerName>"
	And I click clear button in event popup
	
Examples:
  | localPartnerName | 
  | Local Test-41    | 
  | Main Test-(main) |	

Scenario: Empty credential for Local Partner
	And I click save button in event popup
	And I click clear button in event popup
	
# EXPECTED OP
Scenario Outline: Expected OP field validation
  And I enter expected op "<op>"
  Then validation for expected op field
  And I click clear button in event popup

Examples:
  | op            |
  | g1thr@        |    
  | 987654        | 
  | 123456789012  |
  | 3643257886    | 

Scenario: Empty credential for Expected OP
	And I click save button in event popup
	Then Expected op Required alert should be appear
	And I click clear button in event popup	
	
# EXPECTED IP
Scenario Outline: Expected IP field validation
  And I enter expected ip "<ip>"
  Then validation for expected ip field
  And I click clear button in event popup

Examples:
  | ip            |
  | 102           |    
  | 987654        | 
  | 3643257886    | 

Scenario: Empty credential for Expected IP
	And I click save button in event popup
	Then Expected ip Required alert should be appear
	And I click clear button in event popup	
	
# EXPECTED SPECIALITY REFERRAL
Scenario Outline: Expected Speciality Referral field validation
  And I enter expected speciality referral "<specRef>"
  Then validation for expected speciality referral field
  And I click clear button in event popup

Examples:
  | specRef       |
  | g100thr@      |    
  | 987654        | 
  | 120           |

Scenario: Empty credential for Expected Speciality Referral
	And I click save button in event popup
	Then Expected speciality referral Required alert should be appear
	And I click clear button in event popup
	
# EXPECTED GP
Scenario Outline: Expected GP field validation
  And I enter expected GP "<gp>"
  Then validation for expected GP field
  And I click clear button in event popup

Examples:
  | gp            |
  | g100thr@      |    
  | 987654        |   
  | 120           |

Scenario: Empty credential for Expected GP
	And I click save button in event popup
	Then Expected GP Required alert should be appear
	And I click clear button in event popup
	
# IHMS CAMP ID
Scenario Outline: IHMS Camp Id validation
	And I enter camp id "<campid>" in event
	Then validation for IHMS camp id field
	And I click clear button in event popup
	
Examples:
  | campid        | 
  | g1thr@        |    
  | 987654        | 
  | 123456789012  |
  | 3643257886    |	

Scenario: Empty credential for IHMS Camp Id
	And I click save button in event popup
	And I click clear button in event popup

	
# VALID TEST DATAS			
Scenario: Valid Test Datas for New event 

	And I select hospital "Aravind Eye Hospital - Virudhunagar" dropdown
	
	# Active is uncheck firsttime if we click ----> Checked always when we enter
	And I click active checkbox
	
	And I select event organizer name "Ram" dropdown	
	And I enter place "Virudhunagar-41"
	And I select city "TADWAI" dropdown
	And I select district "Virudhunagar" dropdown
	And I select distance "Remote (> 60 km)" dropdown
	
	# CHANGE TEST DATA AFTER FIX
	#And I select language of prescription "Nearby (5–10 km)" dropdown
		
	#START DATE
	And I click event start date calendar icon
    And I select start month "Nov"
	And I select start year "2026"
	And I select start date "15" from date picker
	Then selected date should be displayed in event start date field
	#END DATE
	And I click event end date calendar icon
	And I select end month "Nov"
	And I select end year "2026"
	And I select end date "16" from date picker
	Then selected date should be displayed in event end date field
	
	And I select event type "DR Screening" dropdown
	And I select event location "school" dropdown
	And I select project name "Mission for vision" dropdown
	And I enter local partner "Local-Test-41"

	And I enter expected op "579"
	And I enter expected ip "77"
	And I enter expected speciality referral "70"
	And I enter expected GP "86"
	
	And I enter camp id "23456" in event
	
	And I click save button in event popup
	Then "Event created successfully" toast should be displayed
	#And I click clear button in event popup
	#And I click cancel button in event popup
	
Scenario: Navigate to Hospital master Edit actions
	And I click on home
	And I click on master option
    And I navigated to the master page	
    And I click on hospital master option
	Then I navigated to the hospital master page
	Then edit and delete buttons should be disable initially
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	