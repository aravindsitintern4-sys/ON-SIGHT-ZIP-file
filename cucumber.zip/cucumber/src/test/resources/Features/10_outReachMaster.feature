#@login @outReach_Event_setup
@outReach_master_NewEvent

Feature: OutReach Master Workflow

# OUTREACH EVENT MASTER
Scenario: OutReach Master actions 
   And user clicks on outReach event master option
   Then user navigated to the outreach event master page
   Then edit and delete buttons should be disable initially
       
Scenario: New button work
   When user clicks New button in outreach event master
   Then new event creation popup should be displayed
	
# ACTIVE STATUS ---> CHECK BOX	
Scenario: Active status checkbox validation
    And user clicks active checkbox
	And user clicks clear button in event popup
		
# HOSPITAL	
Scenario Outline: Hospital validation
	And user selects hospital "<hospitalName>" dropdown
	And user clicks clear button in event popup
	
Examples:
  | hospitalName                         | 
  | Aravind Eye Hospital - Virudhunagar  | 
  | Aravind Eye Hospital - Salem         |	

Scenario: Empty credential for hospital
	And user clicks save button in event popup
	Then user should see hospital name empty field validation in outreach
	And user clicks clear button in event popup
	
# EVENT ORGANIZER NAME	
Scenario Outline: Organizer name validation
	And user selects hospital "Aravind Eye Hospital - Virudhunagar" dropdown
	And user selects event organizer name "<orgName>" dropdown
	And user clicks clear button in event popup
	
Examples:
  | orgName | 
  | Ram     | 
  | Priya   |
	

Scenario: Vaildation for Invalid Organizer name
  And user selects event organizer name "indian" dropdown
  Then no items found message should be displayed in dropdown
  And user clicks clear button in event popup
  
Scenario: Empty credential for organizer name
	And user clicks save button in event popup
	Then organizer name Required alert should be appear
	And user clicks clear button in event popup	
	  
# PLACE	
Scenario Outline: Place validation
	And user enters place "<placeName>"
	And user clicks clear button in event popup
	
Examples:
  | placeName                         | 
  | Virudhunagar-41  | 
  | Salem-(main)     |	

Scenario: Empty credential for Place
	And user clicks save button in event popup
	Then place Required alert should be appear
	And user clicks clear button in event popup
	
 # CITY / TALUK	
Scenario Outline: City Taluk validation
	And user selects city "<cityName>" dropdown
	And user clicks clear button in event popup
	
Examples:
  | cityName          | 
  | TADWAI            | 
  | RAMADUGU          |	
  
Scenario: Vaildation for Invalid city
  And user selects city "Japan" dropdown
  Then no data found messege should be displayed in dropdown in event
  And user clicks clear button in event popup

Scenario: Empty credential for City
	And user clicks save button in event popup
	Then city Required alert should be appear
	And user clicks clear button in event popup 
		
# DISTRICT	
Scenario Outline: District validation
	And user selects district "<districtName>" dropdown
	And user clicks clear button in event popup
	
Examples:
  | districtName      | 
  | Virudhunagar      | 
  | Salem             |	
  
Scenario: Vaildation for Invalid District
  And user selects district "Japan" dropdown
  Then no data found messege should be displayed in dropdown in event
  And user clicks clear button in event popup

Scenario: Empty credential for District
	And user clicks save button in event popup
	Then district Required alert should be appear
	And user clicks clear button in event popup			
	
# DISTANCE FROM HQ
Scenario Outline: Distance from HQ validation
	And user selects distance "<distanceHQ>" dropdown
	And user clicks clear button in event popup

Examples:
  | distanceHQ        | 
  | Nearby (5–10 km)  | 
  | Remote (> 60 km)  |	

Scenario: Empty credential for Distance from HQ
	And user clicks save button in event popup
	Then Distance From HQ Required alert should be appear
	And user clicks clear button in event popup
		
# LANGUAGE OF PRESCRIPTION  (CHANGE TEST DATA AND REQIRED FIELD NAME CHANGE AFTER FIX)
#Scenario Outline: Language of Prescription validation
	#And user selects language of prescription "<languagePres>" dropdown
	#And user clicks clear button in event popup

#Examples:
  #| languagePres      | 
  #| Nearby (5–10 km)  | 
  #| Remote (> 60 km)  |	

#Scenario: Empty credential for Distance from HQ
	#And user clicks save button in event popup
	#Then Language for Prescription Required alert should be appear
	#And user clicks clear button in event popup
		
# START DATE  ---> (FOR PAST DATE VALIDATION CHANGE THE MONTH NAME INTO CURRENT MONTH FOR START AND END)
Scenario: Past start date should be disabled in date picker
    And user clicks event start date calendar icon
    And user selects start month "Apr"
	And user selects start year "2026"
    Then past dates should be disabled in date picker
    And user clicks clear button in event popup
    	
Scenario: Start Date validation
    And user clicks event start date calendar icon
    And user selects start month "Nov"
	And user selects start year "2027"
	And user selects start date "15" from date picker
	Then selected date should be displayed in event start date field
	And user clicks clear button in event popup

Scenario: Empty credential for Event Start date
	And user clicks save button in event popup
	Then start date Required alert should be appear
	And user clicks clear button in event popup
	
# END DATE
Scenario: Past end date should be disabled in date picker
    And user clicks event end date calendar icon
	And user selects start month "Apr"
	And user selects start year "2026"
    Then past dates should be disabled in date picker
    And user clicks clear button in event popup
    	
Scenario: End Date validation
    And user clicks event end date calendar icon
	And user selects end month "Nov"
	And user selects end year "2027"
	And user selects end date "15" from date picker
	Then selected date should be displayed in event end date field
	And user clicks clear button in event popup

Scenario: Empty credential for Event End date
	And user clicks save button in event popup
	Then end date Required alert should be appear
	And user clicks clear button in event popup
	
# EVENT TYPE
Scenario Outline: Event Type validation
	And user selects event type "<eventType>" dropdown
	And user clicks clear button in event popup
   
Examples:
  | eventType            | 
  | DR Screening         | 
  | Workplace Screening  |	

Scenario: Empty credential for Event Type
	And user clicks save button in event popup
	Then Event Type Required alert should be appear
	And user clicks clear button in event popup
	
# EVENT LOCATION	
Scenario Outline: Event Location validation
	And user selects event location "<eventLocation>" dropdown
	And user clicks clear button in event popup
	
Examples:
  | eventLocation  | 
  | school         | 
  | camp           |	

Scenario: Empty credential for Event Location
	And user clicks save button in event popup
	Then Event Location Required alert should be appear
	And user clicks clear button in event popup	
	
# PROJECT NAME
Scenario Outline: Project Name validation
	And user selects project name "<projectName>" dropdown
	And user clicks clear button in event popup
	
Examples:
  | projectName        | 
  | Mission for vision | 
  | Lions Sight First  |	

Scenario: Empty credential Poject name
	And user clicks save button in event popup
	And user clicks clear button in event popup
	
# LOCAL PARTNER
Scenario Outline: Local Partner validation
	And user enters local partner "<localPartnerName>"
	And user clicks clear button in event popup
	
Examples:
  | localPartnerName | 
  | Local Test-41    | 
  | Main Test-(main) |	

Scenario: Empty credential for Local Partner
	And user clicks save button in event popup
	And user clicks clear button in event popup
	
# EXPECTED OP
Scenario Outline: Expected OP field validation
  And user enters expected op "<op>"
  Then validation for expected op field
  And user clicks clear button in event popup

Examples:
  | op            |
  | g1thr@        |    
  | 987654        | 
  | 123456789012  |
  | 3643257886    | 

Scenario: Empty credential for Expected OP
	And user clicks save button in event popup
	Then Expected op Required alert should be appear
	And user clicks clear button in event popup	
	
# EXPECTED IP
Scenario Outline: Expected IP field validation
  And user enters expected ip "<ip>"
  Then validation for expected ip field
  And user clicks clear button in event popup

Examples:
  | ip            |
  | 102           |    
  | 987654        | 
  | 3643257886    | 

Scenario: Empty credential for Expected IP
	And user clicks save button in event popup
	Then Expected ip Required alert should be appear
	And user clicks clear button in event popup	
	
# EXPECTED SPECIALITY REFERRAL
Scenario Outline: Expected Speciality Referral field validation
  And user enters expected speciality referral "<specRef>"
  Then validation for expected speciality referral field
  And user clicks clear button in event popup

Examples:
  | specRef       |
  | g100thr@      |    
  | 987654        | 
  | 120           |

Scenario: Empty credential for Expected Speciality Referral
	And user clicks save button in event popup
	Then Expected speciality referral Required alert should be appear
	And user clicks clear button in event popup
	
# EXPECTED GP
Scenario Outline: Expected GP field validation
  And user enters expected GP "<gp>"
  Then validation for expected GP field
  And user clicks clear button in event popup

Examples:
  | gp            |
  | g100thr@      |    
  | 987654        |   
  | 120           |

Scenario: Empty credential for Expected GP
	And user clicks save button in event popup
	Then Expected GP Required alert should be appear
	And user clicks clear button in event popup
	
# IHMS CAMP ID
Scenario Outline: IHMS Camp Id validation
	And user enters camp id "<campid>" in event
	Then validation for IHMS camp id field
	And user clicks clear button in event popup
	
Examples:
  | campid        | 
  | g1thr@        |    
  | 987654        | 
  | 123456789012  |
  | 3643257886    |	

Scenario: Empty credential for IHMS Camp Id
	And user clicks save button in event popup
	And user clicks clear button in event popup

	
# VALID TEST DATAS			
Scenario: Valid Test Datas for New event 

	And user selects hospital "Aravind Eye Hospital - Virudhunagar" dropdown
	
	# Active is uncheck firsttime if we click ----> Checked always when we enter
	And user clicks active checkbox
	
	And user selects event organizer name "Ram" dropdown	
	And user enters place "Virudhunagar-41"
	And user selects city "TADWAI" dropdown
	And user selects district "Virudhunagar" dropdown
	And user selects distance "Remote (> 60 km)" dropdown
	
	# CHANGE TEST DATA AFTER FIX
	#And user selects language of prescription "Nearby (5–10 km)" dropdown
		
	#START DATE
	And user clicks event start date calendar icon
    And user selects start month "Nov"
	And user selects start year "2026"
	And user selects start date "15" from date picker
	Then selected date should be displayed in event start date field
	#END DATE
	And user clicks event end date calendar icon
	And user selects end month "Nov"
	And user selects end year "2026"
	And user selects end date "16" from date picker
	Then selected date should be displayed in event end date field
	
	And user selects event type "DR Screening" dropdown
	And user selects event location "school" dropdown
	And user selects project name "Mission for vision" dropdown
	And user enters local partner "Local-Test-41"

	And user enters expected op "579"
	And user enters expected ip "77"
	And user enters expected speciality referral "70"
	And user enters expected GP "86"
	
	And user enters camp id "23456" in event
	
	And user clicks save button in event popup
	Then "Event created successfully" toast should be displayed
	#And user clicks clear button in event popup
	#And user clicks cancel button in event popup
	
Scenario: Navigate to Hospital master Edit actions
	And user clicks on home
	And user clicks on master option
    And user navigated to the master page	
    And user clicks on hospital master option
	Then user navigated to the hospital master page
	Then edit and delete buttons should be disable initially
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	