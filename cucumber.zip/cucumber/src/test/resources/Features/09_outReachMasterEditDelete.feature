@login @outReach_Event_setup
@outReach_master_EditEvent

Feature: OutReach Master EditWorkflow

Scenario:  Outreach event Master page navigation
  And I click on outReach event master option
   Then I navigated to the outreach event master page
   And I wait for "2" seconds
   Then edit and delete buttons should be disable initially
	
#EDIT WORKFLOW
Scenario: Edit button workflow invalid Test datas in event
    And I enter data in search bar "1000"
    Then no data found messege should be displayed in dropdown in event
    And I clear search box
    
Scenario: Edit button workflow invalid Test datas in event
	And I enter data in search bar "india"
    Then no data found messege should be displayed in dropdown in event
    And I clear search box

Scenario Outline: Edit workflow using Valid data
  And I clear search box
  When I enter data in search bar "<datas>"
  Then event details for data "<datas>" should be displayed
  When I select checkbox for data "<datas>"
  Then checkbox for data "<datas>" should be selected
  Then edit and delete buttons should be enabled and new button should be disabled
  And I click "Edit" button
  Then event creation popup with existing details should be displayed
  And I click "Cancel" button
  
 Examples:
      | datas    |
      | 41       |
      | Madurai  |
      
Scenario: Edit OP data in aready created event
  And I clear search box
  When I enter data in search bar "41"
  Then event details for data "41" should be displayed
  When I select checkbox for data "41"
  Then checkbox for data "41" should be selected
  Then edit and delete buttons should be enabled and new button should be disabled
  And I click "Edit" button
  Then event creation popup with existing details should be displayed
  And I select hospital "Aravind Eye Hospital-Madurai" dropdown
  And I select event organizer name "dhaas" dropdown	
  And I select district "Madurai" dropdown
  #START DATE
	And I click event start date calendar icon
    And I select start month "Jun"
	And I select start year "2026"
	And I select start date "15" from date picker
	Then selected date should be displayed in event start date field
	And I select event location "school" dropdown
    And I enter expected op "700"
    And I click "Update" button 
  
Scenario: Delete event workflow with Confirmation Cancel (Do not delete event)
	 And I clear search box
	  When I enter data in search bar "64"
	  Then event details for data "64" should be displayed
	  When I select checkbox for data "64"
	  Then checkbox for data "64" should be selected
	  Then edit and delete buttons should be enabled and new button should be disabled
	   And I click "Delete" button
	   And I click "Cancel" button


Scenario: Delete event workflow with Confirmation Ok (delete event)
	  And I clear search box
	  When I enter data in search bar "153"
	  Then event details for data "153" should be displayed
	  When I select checkbox for data "153"
	  Then checkbox for data "153" should be selected
	  Then edit and delete buttons should be enabled and new button should be disabled
	  And I click "Delete" button
	  And I click "OK" button
	  
Scenario: Check the deleted event
	  And I wait for "2" seconds
	  And I clear search box
	  And I enter data in search bar "153"
	  And I press "ENTER" key
  	  Then no data found messege should be displayed in dropdown in event   

Scenario: Navigate to master page
	 And I click on home
	 And I click on master option
     And I navigated to the master page	
   
  