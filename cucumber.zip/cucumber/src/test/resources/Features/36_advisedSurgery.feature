#@login @outReach_Event_setup
@admission_onboarding

Feature: Surgery Advised inside dashboard Workflow

Scenario: Surgery Advised inside dashboard actions
	And I click patient surgery confirmed section in dashboard
	Then I navigated to the surgery advised onboarding page

Scenario: Search patient
	And  I enter id in search bar "Wabjfdolcsaz" in Surgery advised
	And I click filtered option in surgery advised

Scenario: button actions in patient onboarding
    And I click "Done" button in surgery adviced onboarding