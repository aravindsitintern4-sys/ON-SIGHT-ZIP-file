@login @outReach_Event_setup
@anterior_segment_clinical_records

Feature: Anterior Segment workflow in clinical records
		
Scenario: Anterior Segment navigation flow
	And I wait for "2" seconds
	And I click "Ant. Segment" label option
	Then popup "Anterior Segment" should be displayed
	
Scenario: Save button should be disable initially
	Then save button should be disable
	
Scenario: Anterior segment actions for label Lid
	 And I select "Lid:" label for "RE" with "Clear" option
	 And I select "Lid:" label for "LE" with "Blepharitis" option
	 And I select "Lid:" label for "LE" with "Ptosis" option
	 And I select "Lid:" label for "LE" with "Deep Socket" option
	 And I select "Lid:" label for "LE" with "MGD" option
	
Scenario: Anterior segment actions for label Conjunctiva
	 And I select "Conjunctiva:" label for "RE" with "Normal" option
	 And I select "Conjunctiva:" label for "LE" with "Pterygium" option
	 And I select "Conjunctiva:" label for "RE" with "Congestion" option	
	
Scenario: Anterior segment actions for label Cornea
	 And I select "Cornea:" label for "RE" with "Clear" option
	 And I select "Cornea:" label for "LE" with "Scar" option
	 And I select "Cornea:" label for "LE" with "Arcus Senilis" option
	 And I select "Cornea:" label for "LE" with "CDK" option  
	
Scenario: Anterior segment actions for label Anterior Chamber
	 And I select "Anterior Chamber:" label for "RE" with "Normal Depth" option
	 And I select "Anterior Chamber:" label for "LE" with "Depth - Shallow" option
	 And I select "Anterior Chamber:" label for "LE" with "Depth - Deep" option 
	 
Scenario: Anterior segment actions for label Iris
	 And I select "Iris:" label for "RE" with "Normal Colour and Pattern" option
	 And I select "Iris:" label for "LE" with "PI" option
	 And I select "Iris:" label for "LE" with "Iris Chaffing" option
	 And I select "Iris:" label for "LE" with "Coloboma" option  
	 And I select "Iris:" label for "LE" with "PXF" option 

Scenario: Anterior segment actions for label Pupil
	 And I select "Pupil:" label for "RE" with "Normal Size and Reaction to Light" option
	 And I select "Pupil:" label for "LE" with "RAPD" option
	 And I select "Pupil:" label for "LE" with "Sluggish Reaction" option 

Scenario: Anterior segment actions for label Lens
	 And I select "Lens:" label for "RE" with "Clear" option
	 And I select "Lens:" label for "LE" with "Immature Cataract" option
	 And I select "Lens:" label for "LE" with "PCIOL" option
	 And I select "Lens:" label for "LE" with "Mature Cataract" option 
	 And I select "Lens:" label for "LE" with "Brown Cataract" option
	 
Scenario: Anterior segment actions for label Ocular Movements
	 And I select "Ocular Movements:" label for "RE" with "Full" option
	 And I select "Ocular Movements:" label for "LE" with "Nystagmus" option
	 And I select "Ocular Movements:" label for "LE" with "Restricted" option 
	 
Scenario: Anterior segment actions for label Corneal Reflex
	 And I select "Corneal Reflex:" label for "RE" with "Orthophoric" option
	 And I select "Corneal Reflex:" label for "LE" with "Exotropia" option
	 And I select "Corneal Reflex:" label for "LE" with "Esotropia" option 
	 
Scenario: Anterior segment actions for label Globe
	 And I select "Globe:" label for "RE" with "Normal" option
	 And I select "Globe:" label for "LE" with "Pthisical" option
	 
Scenario: Remarks for Anterior segment
	And I enter remarks for "RE" as "RE remarks entered"
	And I enter remarks for "LE" as "LE remarks entered"
	
Scenario: Save action in Anterior Segment
	And I wait for "1" seconds
    And I click save or update button in examination
    And I wait for "3" seconds
	#And I click close icon
	#And I click "Discard" button in window
	Then Anti. segment summary should be displayed
		
Scenario: Update action in Anterior Segment
    And I click "Ant. Segment" label option
    And I select "Globe:" label for "Anophthalmous" option in examination
    And I wait for "1" seconds
    And I click save or update button in examination
    And I wait for "3" seconds
	Then Anti. segment summary should be displayed
		
Scenario: Anterior Segment info icon
	When I hover Anti. segment summary info icon
	
Scenario: Anterior Segment summary Delete icon
 	And I click anti. segment summary delete icon
	Then popup "Confirm" should be displayed
	And I click "Delete" button in window
	Then Anti. segment summary should be not displayed
	
Scenario: Final Datas for segment
    And I click "Ant. Segment" label option
    And I select "Globe:" label for "Anophthalmous" option in examination
    And I select "Corneal Reflex:" label for "LE" with "Esotropia" option 
    And I select "Pupil:" label for "LE" with "RAPD" option
    And I wait for "1" seconds
    And I click save or update button in examination
    And I wait for "3" seconds
	Then Anti. segment summary should be displayed
	And I wait for "2" seconds
	
  	         
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	