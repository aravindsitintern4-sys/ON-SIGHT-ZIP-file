#@login @outReach_Event_setup
@new_registration
Feature: Patient Registration

Background:
  Given user is on the dashboard page
  When user clicks on Registration option  
  Then patient should be navigated to the registration page
  
#FIRST NAME TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: First Name field validation
  And user enters First Name "<input>"
  Then only alphabets should be entered in name field
  And user clicks on Cancel button in registration

Examples:
  | input     |
  | g1thr     |
  | {},@;     |
  | 12345     |
  | Siva123   |
  | Siv@      |
  
Scenario: Registration Vaildation with Empty credentials for First Name
  And user enters First Name ""
  And user clicks on Submit button in registration
  Then Required alert should be appear
  And user clicks on Cancel button in registration
  
# LAST NAME TEST DATAS
 # NEGATIVE SCENARIO 
Scenario Outline: Last Name field validation
  And user enters Last Name "<input>"
  Then only alphabets should be entered in name field
  And user clicks on Cancel button in registration

Examples:
  | input     |
  | g1thr     |
  | {},@;     |
  | 12345     |
  | Siva123   |
  | Siv@      |
  
Scenario: Registration Vaildation with Empty credentials for Last Name
  And user enters Last Name ""
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration
  
# AGE TEST DATAS  
 # NEGATIVE SCENARIO
Scenario Outline: Age field validation
  And user enters Age "<input>"
  Then only numbers should be accepted in field
  And user clicks on Cancel button in registration

Examples:
  | input   |
  | g1thr   |  
  | {},@;   |   
  | Siva123 |   
  | Siv@    |  
  | 0       |   
  | -5      |

Scenario: Registration Vaildation for more age
  And user enters Age "131"
  And user clicks on Submit button in registration
  Then Invalid alert should be appear
  And user clicks on Cancel button in registration
 
Scenario: Registration Vaildation with Empty credentials for Age
  And user enters Age ""
  And user clicks on Submit button in registration
  Then Required alert should be appear
  And user clicks on Cancel button in registration

# GENDER TEST DATAS

Scenario: Registration Vaildation for Male
  And user selects Gender "Male"
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration
  
Scenario: Registration Vaildation for Female
  And user selects Gender "Female"
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration
  
Scenario: Registration Vaildation for Transgender Yes
  And user selects Gender "Transgender" 
  And user clicks Yes button
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration
  
Scenario: Registration Vaildation for Transgender No
  And user selects Gender "Transgender" 
  And user clicks No button
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration
 
Scenario: Registration Vaildation with Empty credentials for Gender
  When user clicks on Gender dropdown
  And user clicks on Submit button in registration
  Then Required alert should be appear
  And user clicks on Cancel button in registration
  
# NEXT OF KIN TEST DATAS
Scenario Outline: Registration Vaildation for Male KIN
  And user selects Gender "Male"
  And user selects Next of Kin "<Mkin>"
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration
  
  Examples:
  | Mkin |
  | S/O  |
  | F/O  |
  | H/O  |
  | C/O  |
  
Scenario Outline: Registration Vaildation for Female KIN
  And user selects Gender "Female"
  And user selects Next of Kin "<Fkin>"
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration
  
  Examples:
  | Fkin |
  | D/O  |
  | M/O  |
  | W/O  |
  | C/O  |
  
Scenario: Registration Vaildation for Female KIN
  And user selects Gender "Transgender" 
  And user clicks Yes button
  And user enters Kin Name "gre"
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration
  
 
Scenario: Registration Vaildation with Empty credentials for KIN
  And user selects Gender "Female"
  When user clicks on Next of Kin dropdown
  And user clicks on Submit button in registration
  Then Required alert should be appear
  And user clicks on Cancel button in registration 
  
# KIN NAME TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: KIN Name field validation
  And user selects Gender "Female"
  And user selects Next of Kin "D/O"
  And user enters Kin Name "<kinName>"
  Then only alphabets should be entered in name field
  And user clicks on Cancel button in registration

Examples:
  | kinName   |
  | g1thr     |
  | {},@;     |
  | 12345     |
  | Siva123   |
  | Siv@      |
  
Scenario: Registration Vaildation with Empty credentials for KIN Name
  And user selects Gender "Female"
  And user selects Next of Kin "D/O"
  And user enters Kin Name ""
  And user clicks on Submit button in registration
  Then Required alert should be appear
  And user clicks on Cancel button in registration
  
# LOCALITY TEST DATAS
Scenario: Registration Vaildation with Empty credentials for Locality
  And user enters Locality ""
  And user clicks on Submit button in registration
  Then Required alert should be appear
  And user clicks on Cancel button in registration
  
# PIN CODE TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: PinCode field validation
  And user enters PinCode "<input>"
  Then validation for pincode field
  And user clicks on Cancel button in registration

Examples:
  | input   |
  | g1thr   |  
  | {},@;   |   
  | Siva123 |   
  | Siv@    |  
  | 0       |   
  | -5      |
  |643234436|
  
Scenario: Registration Vaildation with Empty credentials for PinCode
  And user enters PinCode ""
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration

# TALUK TEST DATAS

Scenario: Registration Vaildation for Invalid Taluk
  And user selects Taluk "Japan"
  Then no data found messege should be displayed
  And user clicks on Cancel button in registration
  
Scenario: Registration Vaildation with Empty credentials for Taluk
  And user selects Taluk ""
  And user clicks on Submit button in registration
  Then Required alert should be appear
  And user clicks on Cancel button in registration

# MOBILE NUMBER TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: Mobile No field validation
  And user enters Mobile No "<mobileno>"
  Then validation for Mobile No field
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration

Examples:
  | mobileno    |
  | g1thr@      |    
  | 987654      | 
  | 1234567890  |
  | 3643257886  | 
  
Scenario: Registration Vaildation with Empty credentials for Mobile number
  And user enters Mobile No ""
  And user clicks on Cancel button in registration
  
# AADHAAR NUMBER TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: Aadhaar No field validation
  And user enters Aadhaar No "<aadhaarno>"
  Then validation for Aadhaar No field
  And user clicks on Cancel button in registration

Examples:
  | aadhaarno     |
  | g1thr@        |    
  | 987654        | 
  | 123456789012  |
  | 3643257886    | 
  
Scenario: Registration Vaildation with Empty credentials for Aadhaar number
  And user enters Aadhaar No ""
  And user clicks on Submit button in registration
  And user clicks on Cancel button in registration

# VALID REGISTRATION DETAILS

Scenario: Register a new patient successfully 
  And user enters First Name "pout"
  And user enters Last Name "tyugre"
  And user enters Age "24"
  And user selects Gender "Male"
  And user selects Next of Kin "S/O"
  And user enters Kin Name "gre"
  And user enters Door "33EE"
  And user enters Locality "Madurai"
  
  When user clicks on Area button
  And user selects Area "Anaiyur"

  And user selects Taluk "Aalur"
  
  And user enters PinCode "600001"
  And user enters Mobile No "9948579632"
  #And user enters Aadhaar No "658426731556"

  #And user clicks on Submit button in registration
  #Then patient should be registered successfully
  
  #And user clicks close icon in oid generated pop up in registration

  And user clicks on Clear button in registration
  #Then patient entered details should be cleared
  
  And user clicks on Cancel button in registration
  #Then user should be navigated to dashboard page