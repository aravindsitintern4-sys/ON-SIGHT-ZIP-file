#@login @outReach_Event_setup
@new_registration
Feature: Patient Registration

Scenario: Click Registration actions
	When I click on Registration option
	Then patient should be navigated to the registration page

  
#FIRST NAME TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: First Name field validation
  And I enter First Name "<input>"
  Then only alphabets should be entered in name field
  And I click on Clear button in registration

Examples:
  | input     |
  | g1thr     |
  | {},@;     |
  | 12345     |
  | Siva123   |
  | Siv@      |
  
Scenario: Registration Vaildation with Empty credentials for First Name
  And I enter First Name ""
  And I click on Submit button in registration
  Then Required alert should be appear
  And I click on Clear button in registration
  
# LAST NAME TEST DATAS
 # NEGATIVE SCENARIO 
Scenario Outline: Last Name field validation
  And I enter Last Name "<input>"
  Then only alphabets should be entered in name field
  And I click on Clear button in registration

Examples:
  | input     |
  | g1thr     |
  | {},@;     |
  | 12345     |
  | Siva123   |
  | Siv@      |
  
Scenario: Registration Vaildation with Empty credentials for Last Name
  And I enter Last Name ""
  And I click on Submit button in registration
  And I click on Clear button in registration
  
# AGE TEST DATAS  
 # NEGATIVE SCENARIO
Scenario Outline: Age field validation
  And I enter Age "<input>"
  Then only numbers should be accepted in field
  And I click on Clear button in registration

Examples:
  | input   |
  | g1thr   |  
  | {},@;   |   
  | Siva123 |   
  | Siv@    |  
  | 0       |   
  | -5      |

Scenario: Registration Vaildation for more age
  And I enter Age "131"
  And I click on Submit button in registration
  Then Invalid alert should be appear
  And I click on Clear button in registration
 
Scenario: Registration Vaildation with Empty credentials for Age
  And I enter Age ""
  And I click on Submit button in registration
  Then Required alert should be appear
  And I click on Clear button in registration

# GENDER TEST DATAS

Scenario: Registration Vaildation for Male
  And I select Gender "Male"
  And I click on Submit button in registration
  And I click on Clear button in registration
  
Scenario: Registration Vaildation for Female
  And I select Gender "Female"
  And I click on Submit button in registration
  And I click on Clear button in registration
  
Scenario: Registration Vaildation for Transgender Yes
  And I select Gender "Transgender" 
  And I click Yes button
  And I click on Submit button in registration
  And I click on Clear button in registration
  
Scenario: Registration Vaildation for Transgender No
  And I select Gender "Transgender" 
  And I click No button
  And I click on Submit button in registration
  And I click on Clear button in registration
 
Scenario: Registration Vaildation with Empty credentials for Gender
  When I click on Gender dropdown
  And I click on Submit button in registration
  Then Required alert should be appear
  And I click on Clear button in registration
  
# NEXT OF KIN TEST DATAS
Scenario Outline: Registration Vaildation for Male KIN
  And I select Gender "Male"
  And I select Next of Kin "<Mkin>"
  And I click on Submit button in registration
  And I click on Clear button in registration
  
  Examples:
  | Mkin |
  | S/O  |
  | F/O  |
  | H/O  |
  | C/O  |
  
Scenario Outline: Registration Vaildation for Female KIN
  And I select Gender "Female"
  And I select Next of Kin "<Fkin>"
  And I click on Submit button in registration
  And I click on Clear button in registration
  
  Examples:
  | Fkin |
  | D/O  |
  | M/O  |
  | W/O  |
  | C/O  |
  
Scenario: Registration Vaildation for Female KIN
  And I select Gender "Transgender" 
  And I click Yes button
  And I enter Kin Name "gre"
  And I click on Submit button in registration
  And I click on Clear button in registration
  
 
Scenario: Registration Vaildation with Empty credentials for KIN
  And I select Gender "Female"
  When I click on Next of Kin dropdown
  And I click on Submit button in registration
  Then Required alert should be appear
  And I click on Clear button in registration 
  
# KIN NAME TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: KIN Name field validation
  And I select Gender "Female"
  And I select Next of Kin "D/O"
  And I enter Kin Name "<kinName>"
  Then only alphabets should be entered in name field
  And I click on Clear button in registration

Examples:
  | kinName   |
  | g1thr     |
  | {},@;     |
  | 12345     |
  | Siva123   |
  | Siv@      |
  
Scenario: Registration Vaildation with Empty credentials for KIN Name
  And I select Gender "Female"
  And I select Next of Kin "D/O"
  And I enter Kin Name ""
  And I click on Submit button in registration
  Then Required alert should be appear
  And I click on Clear button in registration
  
# LOCALITY TEST DATAS
Scenario: Registration Vaildation with Empty credentials for Locality
  And I enter Locality ""
  And I click on Submit button in registration
  Then Required alert should be appear
  And I click on Clear button in registration
  
# PIN CODE TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: PinCode field validation
  And I enter PinCode "<input>"
  Then validation for pincode field
  And I click on Clear button in registration

Examples:
  | input   |
  | g1thr   |  
  | {},@;   |   
  | Siva123 |   
  | Siv@    |  
  | 0       |   
  | -5      |
  |643234436|
  
Scenario: Registration Vaildation with Empty credentials for PinCode
  And I enter PinCode ""
  And I click on Submit button in registration
  And I click on Clear button in registration

# TALUK TEST DATAS

Scenario: Registration Vaildation for Invalid Taluk
  And I select Taluk "Japan"
  Then no data found messege should be displayed
  And I click on Clear button in registration
  
Scenario: Registration Vaildation with Empty credentials for Taluk
  And I select Taluk ""
  And I click on Submit button in registration
  Then Required alert should be appear
  And I click on Clear button in registration

# MOBILE NUMBER TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: Mobile No field validation
  And I enter Mobile No "<mobileno>"
  Then validation for Mobile No field
  And I click on Submit button in registration
  And I click on Clear button in registration

Examples:
  | mobileno    |
  | g1thr@      |    
  | 987654      | 
  | 1234567890  |
  | 3643257886  | 
  
Scenario: Registration Vaildation with Empty credentials for Mobile number
  And I enter Mobile No ""
  And I click on Clear button in registration
  
# AADHAAR NUMBER TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: Aadhaar No field validation
  And I enter Aadhaar No "<aadhaarno>"
  Then validation for Aadhaar No field
  And I click on Clear button in registration

Examples:
  | aadhaarno     |
  | g1thr@        |    
  | 987654        | 
  | 123456789012  |
  | 3643257886    | 
  
Scenario: Registration Vaildation with Empty credentials for Aadhaar number
  And I enter Aadhaar No ""
  And I click on Submit button in registration
  And I click on Clear button in registration

# VALID REGISTRATION DETAILS

Scenario: Register a new patient successfully 
  And I enter First Name "cdsiyewqvbha"
  And I enter Last Name "twibs"
  And I enter Age "24"
  And I select Gender "Male"
  And I select Next of Kin "S/O"
  And I enter Kin Name "gre"
  And I enter Door "33EE"
  And I enter Locality "Madurai"
  
  When I click on Area button
  And I select Area "Anaiyur"

  And I select Taluk "Aalur"
  
  And I enter PinCode "600001"
  And I enter Mobile No "9948579632"
  #And I enter Aadhaar No "658426731556"

  And I click on Submit button in registration
  Then patient should be registered successfully
  
  And I wait for "5" seconds
  
  And I click close icon in oid generated pop up in registration

  #And I click on Clear button in registration
  #Then patient entered details should be cleared
  
  And I click on Cancel button in registration
  Then I should be navigated to dashboard page