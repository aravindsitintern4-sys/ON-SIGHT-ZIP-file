@login @outReach_Event_setup 
@user_master_EditUser

Feature: User Master Edit Workflow

Scenario: Navigation for user master
    And I click on user master option
    Then I navigated to the user master page
    Then edit and delete and reset password buttons should be disable initially

#EDIT WORKFLOW
Scenario: Edit button workflow invalid Test datas in user
    And I enter id in search bar "1000"
    Then no data found messege should be displayed
    And I clear search box
    
Scenario: Edit button workflow invalid Test datas in user
    And I clear search box
    And I enter data in search bar "india"
    Then no data found messege should be displayed
    
Scenario Outline: Edit workflow using Valid datas in user Edit
	  And I clear search box
	  When I enter id in search bar "<datas>"
	  Then details for id "<datas>" should be displayed
	  When I select checkbox for data "<datas>" in table
	  Then selected checkbox data should be displayed "<datas>"
	  Then edit and delete and reset password buttons should be enabled and new button should be disabled
	  When I click "Edit" button
	  Then "User Master" existing details should be displayed
	  And I click "Cancel" button
	  
 Examples:
      | datas    |
      | 156      |
      | 3        |
      | sabitha  |
      
Scenario: Edit user details
	  And I clear search box
	  When I enter id in search bar "156"
	  Then details for id "156" should be displayed
	  When I select checkbox for data "156" in table
	  Then selected checkbox data should be displayed "156"
	  Then edit and delete and reset password buttons should be enabled and new button should be disabled
	  When I click edit button
	  Then "User Master" existing details should be displayed
	  #EDIT EMAIL ID
	  And I enter email "sabitha123@gmail.com" in user
	  And I select hospital name "Aravind Eye Hospital-Dindigul" userMaster dropdown
	  And I select alias "Ms" dropdown
	  And I click "Update" button
	  Then "User updated successfully!" toast should be displayed
	  And I wait for "3" seconds	


# DELETE BUTTON  
Scenario: Delete workflow with Confirmation Cancel in user master
	  And I clear search box
	  When I enter id in search bar "183"
	  Then details for id "183" should be displayed
	  When I select checkbox for data "183" in table
	  Then selected checkbox data should be displayed "183"
	  Then edit and delete and reset password buttons should be enabled and new button should be disabled
	  And I click "Delete" button
	  And I click "Cancel" button
	  And I wait for "3" seconds
	  
Scenario: Delete workflow with Confirmation Ok in user master
	  And I clear search box
	  When I enter id in search bar "ddd"
	  Then details for id "ddd" should be displayed
	  When I select checkbox for data "ddd" in table
	  Then selected checkbox data should be displayed "ddd"
	  Then edit and delete and reset password buttons should be enabled and new button should be disabled
	  And I click "Delete" button
	  And I click "OK" button 
	  Then "User deleted successfully" toast should be displayed
	  And I clear search box
	  When I enter id in search bar "ddd"
	  And I press "ENTER" key
	  Then no data found messege should be displayed
	  And I wait for "3" seconds	
	  
Scenario: Dashboard page navigation
	  And I click on home
	  #And I click on master option
      #And I navigated to the master page
      And I wait for "2" seconds

 




