#@login @outReach_Event_setup 
@user_master_newUser

Feature: User Master Workflow Actions
	
# USER MASTER  
Scenario: User Master actions 
    And I click on user master option
    Then I navigated to the user master page
    Then edit and delete and reset password buttons should be disable initially
 
Scenario: New button in User master
	And I click "New" button
	Then popup "User Master" should be displayed
	
# ALIAS 	
Scenario Outline: Alias Validation
	And I select alias "<aliasInput>" dropdown
	And I click "Clear" button
	
Examples:
  | aliasInput | 
  | Ms         | 
  | Mrs        |
  | Mr         |	

Scenario: Empty credential for Alias 
	And I click "Save" button
	Then alias Required alert should be appear
	And I click "Clear" button
	
# FIRST NAME 	
Scenario Outline: First name Validation
	And I enter First name "<firstName>" in user
	And I click "Clear" button

Examples:
  | firstName   | 
  | N@me- Test  | 
  | RAM         |
  | RANI        |	

Scenario: Empty credential for Alias 
	And I click "Save" button
	Then first name Required alert should be appear
	And I click "Clear" button	
	
# LAST NAME 	
Scenario Outline: Last name Validation
	And I enter Last name "<lastName>" in user
	And I click "Clear" button

Examples:
  | lastName    | 
  | N@me- Test  | 
  | RAM         |
  | RANI        |
  
# EMAIL  	
Scenario Outline: Email Validation
	And I enter email "<email>" in user
	And I click "Save" button
	And I should see "Please enter a valid email address" validation message
	And I click "Clear" button

Examples:
  | email            | 
  | N@me- Test       | 
  | wasrd@@gmail.com |
  | 5146533@.com     |
  
# ROLES 	
Scenario Outline: Roles Validation
	And I select role "<roleInput>" dropdown
	And I click "Clear" button

Examples:
  | roleInput  | 
  | Admin      | 
  | Doctor     |
  | Organizer  |	

Scenario: Empty credential for Role 
	And I click "Save" button
	Then role Required alert should be appear
	And I click "Clear" button
  
# HOSPITAL NAME 	
Scenario Outline: Hospital name Validation
	And I select hospital name "<hospitalInput>" userMaster dropdown
	And I click "Clear" button

Examples:
  | hospitalInput                    | 
  | Aravind Eye Hospital-Tirunelveli | 
  | Aravind Eye Hospital-Dindigul    |
	

Scenario: Empty credential for Hospital name userMaster 
	And I click "Save" button
	Then I should see hospital name empty field validation in user master
	And I click "Clear" button

# MCIR NUMBER  	
Scenario Outline: MCIR number Validation
	And I select role "Doctor" dropdown
	And I enter MCIR number "<mcirNum>" in user
	And I click "Clear" button
	
Examples:
  | mcirNum         | 
  | N@me- Test123   | 
  | 67747647647647  |
  | {123456}        |
	
#ACTIVE STATUS ---> CHECK BOX	
Scenario: Active status checkbox validation in userMaster
    And I click active checkbox
	And I click "Clear" button		
	
# VALID TEST DATAS
Scenario: Valid Test Datas
	And I enter First name "ddd" in user
	And I enter Last name "User" in user
	And I enter email "nametest123@gmail.com" in user
	And I select role "Admin" dropdown	
	And I select hospital name "Aravind Eye Hospital-Dindigul" userMaster dropdown
    #And I enter MCIR number "6774" in user
	And I click active checkbox
	And I select alias "Ms" dropdown
		
	And I click "Save" button
	Then "User created successfully!" toast should be displayed
	#And I click "Clear" button
	#And I click "Cancel" button
	
Scenario: check the created user details
	And I wait for "2" seconds
	And I clear search box
	When I enter id in search bar "ddd"
    Then details for id "ddd" should be displayed
    When I select checkbox for data "ddd" in table
    Then selected checkbox data should be displayed "ddd"
    And I wait for "3" seconds
    
#Scenario: Verify newly created user using generated User ID
    #Then I verify the newly created user using the generated User ID from the success toast message
	                     	
Scenario: Navigate to Outreach event master page
	And I click on home
	And I click on master option
    And I navigated to the master page
    And I wait for "2" seconds

	

	
	

	  		

  

 

  	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	