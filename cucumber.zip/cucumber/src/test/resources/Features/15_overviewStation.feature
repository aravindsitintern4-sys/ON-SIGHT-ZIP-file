@login @outReach_Event_setup
@station_overview_dashboard

Feature: Station Overview Workflow

Scenario: Station Overview actions
	And I wait for "1" seconds
	And I click patient station overview section in dashboard
	Then popup "Station Overview" should be displayed
		
Scenario: Validate total OP calculation
    Then total OP should equal sum of waiting and completed
    And I wait for "1" seconds

Scenario: Validate station list is displayed
    Then all station names should be visible
    And I wait for "1" seconds

Scenario: Validate waiting counts are correct
    Then waiting count for each station should match 
    And I wait for "1" seconds

Scenario: Validate progress bar visibility
    Then progress bar should be displayed for stations with waiting > 0
    And I wait for "1" seconds

Scenario: Validate zero values handling
    Then stations with zero waiting should show empty progress bar  
    And I wait for "1" seconds

Scenario: Close station overview
	And I click close icon
	And I click on home
    And I wait for "2" seconds


            