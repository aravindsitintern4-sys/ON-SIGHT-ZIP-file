@login  @outReach_Event_setu
@edit_patient_details

Feature: Edit Patient details in Registration

Scenario: Click Registration actions
	When I click on Registration option
	Then patient should be navigated to the registration page

Scenario: Edit Vaildation with Empty credentials for OID
  When I click on Edit button
  Then edit popup should be displayed
  And I enter OID "" for edit
  And I click on Search icon in edit
  Then update button should be disabled
  And I click on Cancel button in edit
  
Scenario: Edit Vaildation with patient  not reg today old OID
  When I click on Edit button
  Then edit popup should be displayed
  And I enter OID "D-00041-0036" for edit
  And I click on Search icon in edit
  And error message "Patients not registered today cannot be edited." should be displayed in edit
  And I click on Cancel button in edit

#RECALL TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: OID field validation in Edit
  When I click on Edit button
  And I enter OID "<oid>" for edit
  And I click on Search icon in edit
  Then I should see OID validation message "No data available for the given UID!"
  And I click on OK button
  And I click on Cancel button in edit

Examples:
  | oid           |
  | DD-00041-0029 |	
  | D00041-0029	  |
  | D-0004-0029	  |
  | D-00041-029	  |
  | 1-00041-0029  |	    


# VALID EDIT TEST DATAS

Scenario: Edit a patient

  When I click on Edit button
  Then edit popup should be displayed
  And I enter OID "C-00025-0064" for edit
  And I click on Search icon in edit
  And I click on update button in edit
  #Then patient address details should be displayed
  
   #And I click on Cancel button in edit
   #Then I should be navigated to registration page
   
  And I enter Age "23"
  And I click update button in edit registration
  
  And I click close icon in oid generated pop up in registration
  
  And I click on Cancel button in registration 
  
  