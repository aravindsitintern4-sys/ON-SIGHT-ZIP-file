#@login  @outReach_Event_setu
@edit_patient_details

Feature: Edit Patient details in Registration

Background:
  Given user is on the dashboard page
  When user clicks on Registration option
  Then patient should be navigated to the registration page

Scenario: Edit Vaildation with Empty credentials for OID
  When user clicks on Edit button
  Then edit popup should be displayed
  And user enters OID "" for edit
  And user clicks on Search icon in edit
  Then update button should be disabled
  And user clicks on Cancel button in edit
  And user clicks on Cancel button in registration
  
Scenario: Edit Vaildation with patient  not reg today old OID
  When user clicks on Edit button
  Then edit popup should be displayed
  And user enters OID "D-00041-0036" for edit
  And user clicks on Search icon in edit
  And error message "Patients not registered today cannot be edited." should be displayed in edit
  And user clicks on Cancel button in edit
  And user clicks on Cancel button in registration

#RECALL TEST DATAS
# NEGATIVE SCENARIO
Scenario Outline: OID field validation in Edit
  When user clicks on Edit button
  And user enters OID "<oid>" for edit
  And user clicks on Search icon in edit
  Then user should see OID validation message "No data available for the given UID!"
  And user clicks on OK button
  And user clicks on Cancel button in edit
  And user clicks on Cancel button in registration

Examples:
  | oid           |
  | DD-00041-0029 |	
  | D00041-0029	  |
  | D-0004-0029	  |
  | D-00041-029	  |
  | 1-00041-0029  |	    


# VALID EDIT TEST DATAS

Scenario: Edit a patient

  When user clicks on Edit button
  Then edit popup should be displayed
  And user enters OID "D-00041-0040" for edit
  And user clicks on Search icon in edit
  And user clicks on update button in edit
  #Then patient address details should be displayed
  
   #And user clicks on Cancel button in edit
   #Then user should be navigated to registration page
   
  And user enters Age "28"
  And user clicks update button in edit registration
  
  And user clicks close icon in oid generated pop up in registration
  
  And user clicks on Cancel button in registration 
  
  