@login  @outReach_Event_setup
@patient_Status_Search_clinical_records

Feature: Patient status search workflow

# PATIENT STATUS SEARCH ICON ACTIONS 
Scenario: Patient status search workflow
	And I click patient status search icon 
	Then popup "Patient Status" should be displayed 
  
# NEGATIVE SCENARIO		
Scenario Outline: OID field invalid datas
  When I enter OID "<oid>" common
  And I click on Search icon
  Then error message "Invalid OID" should be displayed

Examples:
  | oid           |
  | DD-00041-0029 |
  | D00041-0029   |
  | D-0004-0029   |
  | D-00041-029   |
  | 1-00041-0029  |	 
  
  
Scenario: Expired OID Validation
  When I enter OID "D-00041-0040" common
  And I click on Search icon
  Then error message "This patient has not registered today in this camp" should be displayed

Scenario: Valid Name Validation
  When I enter OID "Xyza" common
  And I click on Search icon
  Then "Patient Status" existing details should be displayed
  
Scenario: Valid OID Validation
  When I enter OID "C-00001-0138" common
  And I click on Search icon
  Then "Patient Status" existing details should be displayed
  And I click close icon
  Then I navigated to the clinical records dashboard page

                         










    