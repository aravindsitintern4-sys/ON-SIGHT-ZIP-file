package pages;

import org.openqa.selenium.WebDriver;
import locators.LoginLocator;

public class LoginPage {

    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterUsername(String user) {
        driver.findElement(LoginLocator.username).sendKeys(user);
    }

    public void enterPassword(String pass) {
        driver.findElement(LoginLocator.password).sendKeys(pass);
    }

    public void clickLogin() {
        driver.findElement(LoginLocator.loginBtn).click();
    }

}