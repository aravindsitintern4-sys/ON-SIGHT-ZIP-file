package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import locators.LoginLocator;

public class LoginPage {

    WebDriver driver;
    WebDriverWait wait;
    
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void enterUsername(String user) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(LoginLocator.username));
		element.clear();
		element.sendKeys(user);
    }

    public void enterPassword(String pass) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(LoginLocator.password));
		element.clear();
		element.sendKeys(pass);
    }

    public void clickLogin() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(LoginLocator.loginBtn));
		element.click();
    }

}