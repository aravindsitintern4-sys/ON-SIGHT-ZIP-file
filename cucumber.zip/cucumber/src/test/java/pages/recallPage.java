package pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import locators.recallLocator;

public class recallPage {

    WebDriver driver;
    WebDriverWait wait;

    public recallPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void clickRecallBtn() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(recallLocator.recallBtn));
        element.click();
    }
    
//    ENTER OID
    public void enterOid(String oid) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(recallLocator.oidInput));
        element.sendKeys(oid);       
    }

//    SUBMIT BUTTON
//    public void clickSubmitBtn() {
//    	 WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(recallLocator.submitBtn));
//    	 btn.click();
//    }
    public void clickSubmitBtn() {
        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(recallLocator.submitBtn));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
    }
  
    
//    CANCEL BUTTON   
    public void clickCancelBtn() {
   	 WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(recallLocator.cancelBtn));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
    }   
    
//    CLOSE BUTTON   
 public void clickCloseBtn() {
	 WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(recallLocator.closeBtn));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
 } 

    
//  OK BUTTON   
 public void clickOkBtn() {
	 WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(recallLocator.okBtn));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
 }
    
}
