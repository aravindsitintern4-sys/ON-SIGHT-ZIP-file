package pages;
	
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import locators.outReachMasterLocator;
import utils.DriverFactory;

public class outReachMasterPage {

    WebDriver driver;
    WebDriverWait wait;

    public outReachMasterPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
//  MASTER OPTION CLICK
    public void clickMasterOption() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.masterOption));
        element.click();
    }
    	
// OUTREACH EVENT MASTER
    public void clickOutReachMasterOption() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.outReachMasterOption));
        element.click();
    }
	
// CREATE NEW EVENT
	public void clickNewBtn() {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.newBtn));
	    element.click();
	}
		
// SAVE BUTTON
	public void clickSaveButton() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.saveBtn));
		 element.click();
	}	
	
// CLEAR BUTTON
	public void clickClearButton() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.clearBtn));
		 element.click();
	}	
	
// CANCEL BUTTON
	public void clickCancelButton() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.cancelBtn));
		 element.click();
	}	

// ORGANIZER NAME
//public void selectOrganizerName(String orgName) {
//    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.eventOrgName));
//    element.click();    
//    WebElement eventOrgName = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.eventOrgNameInput));
//    eventOrgName.sendKeys(orgName);
//    eventOrgName.sendKeys(Keys.ENTER);
//}

	public void selectOrganizerName(String orgName) {
	
	    WebElement dropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.eventOrgName));
	   
	    Actions actions = new Actions(driver);
	    actions.moveToElement(dropdown).pause(Duration.ofMillis(300)).click().perform();
	
	    WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.eventOrgNameInput));
	
	    input.clear(); 
	    input.sendKeys(orgName);
	    input.sendKeys(Keys.ENTER);
	}
	
//HOSPITAL NAME
	public void selectHospitalName(String hospitalName) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.hospitalName));  
		
		 Select select = new Select(element);
		 select.selectByVisibleText(hospitalName);
	}	
	
//PLACE NAME
	public void enterPlaceName(String place) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.placeName));  
		 element.sendKeys(place);
	}	

//CITY NAME
	public void selectCityName(String city) {	
	
		 WebElement input = wait.until(ExpectedConditions.presenceOfElementLocated(outReachMasterLocator.cityName));
		    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", input);
	
		    input.clear();
		    input.sendKeys(city);
	}
	
//DISTRICT NAME
	public void selectDistrictName(String district) {
		 WebElement input = wait.until(ExpectedConditions.presenceOfElementLocated(outReachMasterLocator.districtName));  
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", input);
	
		    input.clear();
		    input.sendKeys(district);
		    input.sendKeys(Keys.ENTER);
	}

//DISTANCE FROM HQ
	public void selectDistance(String distance) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.distanceInput));  
		
		 Select select = new Select(element);
		 select.selectByVisibleText(distance);
	}

//LANGUAGE OF PRESCRIPTION
	public void selectLanguage(String language) {  
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.languageInput));
		 Select select = new Select(element);
		 select.selectByVisibleText(language);
	}

//EVENT TYPE
	public void selectEventType(String eventType) {  
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.eventTypeInput));
		 
		 Select select = new Select(element);
		 select.selectByVisibleText(eventType);
	}

//EVENT LOCATION
	public void selectEventLocation(String eventLocation) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.eventLocationInput));  
		 element.sendKeys(eventLocation);
		 element.sendKeys(Keys.ENTER);
	}

//PROJECT NAME
	public void selectProject(String project) {  
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.projectInput));
		 Select select = new Select(element);
		 select.selectByVisibleText(project);
	}

//LOCAL PARTNER
	public void enterLocalPartner(String localPartner) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.localPartnerName));  
		 element.sendKeys(localPartner);
	}

//IHMS CAMP ID
	public void enterCampId(String campid) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.campIdInput));  
		 element.sendKeys(campid);
	}

// START DATE BY DATE PICKER

// CALENDER
	public void clickStartDateCalendar() {
		 WebElement calendar = wait.until(
		            ExpectedConditions.elementToBeClickable(outReachMasterLocator.startDateCalendar));

		    ((JavascriptExecutor) DriverFactory.getDriver())
		            .executeScript("arguments[0].click();", calendar);

	}
	
//SELECT MONTH
	public void selectStartMonth(String month) {
		 WebElement element=wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.monthInput));
		 
		 Select select = new Select(element);
		 select.selectByVisibleText(month);
	}

//SELECT YEAR
	public void selectStartYear(String year) {
		 WebElement element=wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.yearInput));
		 
		 Select select = new Select(element);
		 select.selectByVisibleText(year);
	}

// SELECT START DATE
	public void selectStartDate(String date) {
		 WebElement element=wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.selectStartDate(date)));
		 ((JavascriptExecutor) DriverFactory.getDriver()).executeScript("arguments[0].click();", element);
	}

// Get selected value (from location)
	public String getSelectedStartDate() {
	    return driver.findElement(outReachMasterLocator.startDateInput).getAttribute("value");
	}	
	
//END DATE BY DATE PICKER

// END CALENDAR
	public void clickEndDateCalendar() {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.endDateCalendar));
	    ((JavascriptExecutor) DriverFactory.getDriver()).executeScript("arguments[0].click();", element);
	}

// Select End Month (IMPORTANT - separate)
	public void selectEndMonth(String month) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.monthInput));
	    Select select = new Select(element);
	    select.selectByVisibleText(month);
	}

// Select End Year (IMPORTANT - separate)
	public void selectEndYear(String year) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.yearInput));
	    Select select = new Select(element);
	    select.selectByVisibleText(year);
	}

// Select End Date
	public void selectEndDate(String date) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.selectEndDate(date)));
	    ((JavascriptExecutor) DriverFactory.getDriver()).executeScript("arguments[0].click();", element);
	}

// Get End Date Value
	public String getSelectedEndDate() {
	    return driver.findElement(outReachMasterLocator.endDateInput).getAttribute("value");
	}

//EXPECTED OP 
	public void enterExpectedOP(String op) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.expectedOPInput));  
		 element.sendKeys(op);
	}

//EXPECTED IP 
	public void enterExpectedIP(String ip) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.expectedIPInput));  
		 element.sendKeys(ip);
	}

//EXPECTED SPECIALITY REFERRAL 
	public void enterExpectedSpecReferral(String specRef) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.expectedSpecRefInput));  
		 element.sendKeys(specRef);
	}

//EXPECTED GP
	public void enterExpectedGP(String gp) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.expectedGPInput));  
		 element.sendKeys(gp);
	}

// ACTIVE CHECKBOX
	public void clickActiveCheckbox() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.clickActive));
		 element.click();
	}


// EDIT BUTTON WORKFLOW 

// SEARCH BAR
	public void enterEventIdInSearchBar(String data) {
	    WebElement searchBarInput = wait.until(ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.searchBar) );
	    searchBarInput.click();
	//    searchBarInput.clear();
	    searchBarInput.sendKeys(data);	
	}

//CLICK CHECKBOX
	public void clickCheckbox() {
		WebElement checkbox = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.clickCheckboxTable));
	    checkbox.click();
	}

//CLICK EDIT BUTTON
	public void clickEditBtn() {
	    WebElement editBtn = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.editBtnEnable));
	    editBtn.click();
	}

//CLICK CLEAR SEARCH BAR
	public void clickClearSearch() {
	    WebElement searchBar = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.searchBar));
	    searchBar.click();
	    searchBar.sendKeys(Keys.CONTROL + "a");
	    searchBar.sendKeys(Keys.BACK_SPACE);
	
	    wait.until(ExpectedConditions.attributeToBe(searchBar, "value", ""));
	}

//CLICK UPDATE BUTTON
	public void clickUpdateBtn() {
	  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.updateBtn));
	  element.click();
	}
 
//CLICK DELETE BUTTON
	public void clickDeleteBtn() {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.deleteBtnEnable));
		element.click();
	}
	
//CLICK DELETE CONFIRAMTION OK BUTTON
	public void clickOKBtn() {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.confirmOkBtn));
		element.click();
	}

//CLICK DELETE CONFIRMATION CANCEL BUTTON
	public void clickCancelBtn() {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(outReachMasterLocator.confirmCancelBtn));
		element.click();
	}































	
}
