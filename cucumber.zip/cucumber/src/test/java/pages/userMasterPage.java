package pages;

import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import locators.userMasterLocator;

public class userMasterPage {

    WebDriver driver;
    WebDriverWait wait; 

    public userMasterPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    	
// USER MASTER
    public void clickUserMasterOption() {

        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(userMasterLocator.userMasterOption));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        try {
            element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver)
                .executeScript("arguments[0].click();", element);
        }
    }

 // CREATE NEW USER
    public void clickNewBtn() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(userMasterLocator.newBtn));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        try {
            element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver)
                .executeScript("arguments[0].click();", element);
        }
    }
    		
// SAVE BUTTON
    public void clickSaveButton() {
	     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(userMasterLocator.saveBtn));
	     element.click();
    }	
    	
	 // CLEAR BUTTON
    public void clickClearButton() {
	     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(userMasterLocator.clearBtn));
	     element.click();
    }	
    	
// CANCEL BUTTON
    public void clickCancelButton() {
	     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(userMasterLocator.cancelBtn));
	     element.click();
    }

 // ALIAS
    public void selectAlias(String alias) {
	     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(userMasterLocator.aliasInput));
	     
	     Select select = new Select(element);
	     select.selectByVisibleText(alias);
    }
    
 // FIRST NAME
    public void enterFirstName(String Fname) {
	     WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(userMasterLocator.firstNameInput));
	     element.sendKeys(Fname);
    }    
    
// LAST NAME
	public void enterLastName(String Lname) {
	     WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(userMasterLocator.lastNameInput));
	     element.sendKeys(Lname);
	}    
    
//EMAIL
	public void enterEmail(String email) {
	  WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(userMasterLocator.emailInput));
	  element.clear();
	  element.sendKeys(email);
	}    
    
// ROLES
	public void selectRoles(String role) {
	     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(userMasterLocator.roleInput));
	     
	     Select select = new Select(element);
	     select.selectByVisibleText(role);
	}    
    
//HOSPITAL NAME
	public void selectHospital(String hospital) {
	  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(userMasterLocator.hospitalInput));
	  
	  Select select = new Select(element);
	  select.selectByVisibleText(hospital);
	}    
    
//MCIR NUMBER
	public void enterMCIR(String mcir) {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(userMasterLocator.mcirNumberInput));
		element.sendKeys(mcir);
	}    
    
//OLD PASSWORD
	public void enterOldPassword(String old) {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(userMasterLocator.oldPasswordInput));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		element.clear();
		element.sendKeys(old);
	}    
    
//NEW PASSWORD
	public void enterNewPassword(String newpass) {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(userMasterLocator.newPasswordInput));
		element.clear();
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		
		element.sendKeys(newpass);
	}    
    
//CONFIRM PASSWORD
	public void enterConfirmPassword(String confirm) {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(userMasterLocator.confirmPasswordInput));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		element.clear();
		element.sendKeys(confirm);
	}    
    
	public void verifyNewlyCreatedUserUsingGeneratedId() {

	    // GET TOAST MESSAGE
	    WebElement toast = wait.until(ExpectedConditions.visibilityOfElementLocated(userMasterLocator.toast));

	    String toastMessage = toast.getText();
	    System.out.println("Toast Message: " + toastMessage);

	    // EXTRACT THE USER ID
	    Pattern pattern = Pattern.compile("User ID:\\s*(\\d+)");
	    Matcher matcher = pattern.matcher(toastMessage);

	    String generatedUserId;

	    if (matcher.find()) {
	        generatedUserId = matcher.group(1);
	        System.out.println("Generated User ID: " + generatedUserId);
	    } else {
	        Assert.fail("User ID not found in toast message");
	        return;
	    }

	    // SEARCH USING USER ID 
	    WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(userMasterLocator.search));

	    searchBox.clear();
	    searchBox.sendKeys(generatedUserId);

	    driver.findElement(userMasterLocator.searchStyle).click();

	    // VERIFY RECORD EXISTS
	    WebElement userIdCell = wait.until(ExpectedConditions.visibilityOfElementLocated(userMasterLocator.recordVerify(generatedUserId)));

	    Assert.assertTrue(userIdCell.isDisplayed(),"User record not found for ID: " + generatedUserId);

	    System.out.println("Successfully verified user with ID: " + generatedUserId);
	}    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}
