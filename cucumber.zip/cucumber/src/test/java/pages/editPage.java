package pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import locators.editLocator;

public class editPage {

    WebDriver driver;
    WebDriverWait wait;

    public editPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void clickEditBtn() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(editLocator.editBtn));
        element.click();
    }
    
//    ENTER OID
    public void enterOid(String oid) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(editLocator.oidInput));
        element.sendKeys(oid);       
    }
    
//  SEARCH ICON
    public void clickSearchIcon() {
        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(editLocator.searchIconBtn));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
    } 

//    UPDATE BUTTON
    public void clickUpdateBtn() {
        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(editLocator.updateBtn));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
    }
  
    
//    CANCEL BUTTON   
    public void clickCancelBtn() {
   	 WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(editLocator.cancelBtn));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
    }   
  
//  UPDATE BUTTON IN REGISTRATION PAGE
    public void clickUpdateRegBtn() {
        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(editLocator.updateRegBtn));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
    }   
    
    
    
     
}
