package pages;



import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import locators.reportsLocator;

public class reportsPage {

    WebDriver driver;
    WebDriverWait wait;

    public reportsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
//  REPORTS OPTION CLICK
    public void clickreportsOption() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.reportsOption));
        element.click();
    }
    
//  CAMP ID

    public void selectCampId(String campid) {

    	 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.campId));
        element.click();

        WebElement input=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ng-select[contains(@class,'ng-select-opened')]//input")));
        input.sendKeys(campid);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ng-dropdown-panel")));

        if (driver.findElements(By.xpath("//ng-dropdown-panel//*[contains(text(),'No items found')]")).size() > 0) {
            System.out.println("No data found for: " + campid);
            return;
        }

        // OTHERWISE SELECT OPTION
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//ng-dropdown-panel//div[@role='option'][.//strong[contains(text(),'ID: " + campid.trim() + "')]]")
        )).click();
    }   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}
