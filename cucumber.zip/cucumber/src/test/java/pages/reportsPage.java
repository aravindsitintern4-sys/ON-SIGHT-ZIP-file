package pages;



import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import locators.reportsLocator;

public class reportsPage {

    WebDriver driver;
    WebDriverWait wait;

    public reportsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
//  REPORTS OPTION CLICK
    public void clickreportsOption() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.reportsOption));
        element.click();
    }
    
//  CAMP ID

    public void selectCampId(String campid) {

        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.campId));
        element.click();

        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(reportsLocator.campIdInput));
        input.sendKeys(campid);

        wait.until(ExpectedConditions.visibilityOfElementLocated(reportsLocator.dropdownPanel));

        if (driver.findElements(reportsLocator.noDataFound).size() > 0) {
            System.out.println("No data found for: " + campid);
            return;
        }

        WebElement option = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.campOptionById(campid)));

        option.click();

        System.out.println("Selected Camp ID: " + campid);
    }
    
    
    
// REPORTS -----> CAMP SUMMARY
	
 		// BUTTON ACTIONS 
 		public void ClickBtnCampSummaryReport(String button) {
 		    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.BtnCampSummary(button)));
 		    btn.click();  
 		}
 	
 		// INPUT ACTIONS 
 		public void enterFromDateCampSummary(String FromDate) {
 		    WebElement btn = wait.until(ExpectedConditions.visibilityOfElementLocated(reportsLocator.fromDateInputCampSummary));
 		    btn.sendKeys(FromDate); 
 		    btn.sendKeys(Keys.TAB);
 		}
 	
 		public void enterToDateCampSummary(String ToDate) {
 		    WebElement btn = wait.until(ExpectedConditions.visibilityOfElementLocated(reportsLocator.toDateInputCampSummary));
 		    btn.sendKeys(ToDate); 
 		    btn.sendKeys(Keys.TAB);
 		}
 		
 		// DROPDOWN
 		public void selectCampIdOrPlace(String value) {

 			WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.campDropdown));
 		    dropdown.click();
 		    WebElement option = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.campOption(value)));
 		    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", option);
 		    option.click();
 		} 
 		
 		public void selectCampIdOrPlaceInvalid(String value) {

 		    WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.campDropdown));
 		    dropdown.click();
 		    WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(reportsLocator.campInput));
 		    input.clear();
 		    input.sendKeys(value);
 		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='listbox']"))); 
 		} 
 		
 		// TABLE VISIBLITY AFTER SUBMIT
 		public void isReportTableDisplayed() {
 	        WebElement table = wait.until(ExpectedConditions.visibilityOfElementLocated(reportsLocator.reportTable));
 	        if (!table.isDisplayed()) {
 	            throw new AssertionError("Report table is NOT displayed");
 	        }
 	    }
 		
 		                
 		public void validateNoItemsFoundMessageCommon() {

 		    WebElement message = wait.until(ExpectedConditions.presenceOfElementLocated(reportsLocator.noItemsFoundMsgDropdown));
 		    Assert.assertTrue(message.isDisplayed(), "No items found message not displayed");
 		    System.out.println("'No items found' message is displayed");
 		}
 		
 		public void openCampDropdown() {
 		    WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.campSummaryDropdown));
 		    dropdown.click();
 		}
 		
 		public void clickSelectAllCheckbox() {
 		    WebElement selectAll = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.selectAllCheckbox));
 		    selectAll.click();
 		}
 		
 		public void verifyAllOptionsSelected() {

 		    WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(reportsLocator.campDropdown));
 		    dropdown.click();

 		    wait.until(ExpectedConditions.visibilityOfElementLocated(reportsLocator.dropdownPanel));

 		    List<WebElement> all = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(reportsLocator.allOptions));

 		    List<WebElement> selected = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(reportsLocator.selectedOptions));

 		    if (all.size() == 0) {
 		        throw new AssertionError("No options available in dropdown");
 		    }

 		    if (all.size() != selected.size()) {
 		        throw new AssertionError("Not all options are selected");
 		    }

 		    System.out.println("All options selected successfully");
 		}
 		    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}
