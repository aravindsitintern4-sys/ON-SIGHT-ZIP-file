package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import locators.OutReachEventSetupLocator;

public class OutReachEventSetupPage {

    WebDriver driver;
    WebDriverWait wait;

    public OutReachEventSetupPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void selectHospital(String hospital) {

        WebElement dropdown = driver.findElement(OutReachEventSetupLocator.hospitalDropdown);
        dropdown.click();
        dropdown.sendKeys(hospital);   
        WebElement option = driver.findElement(By.xpath("//*[contains(text(),'" + hospital + "')]"));
        option.click();
    }    
    
    public void enterEventId(String eventId) {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(OutReachEventSetupLocator.eventDropdown));
        dropdown.click();

        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(OutReachEventSetupLocator.eventInput));
        input.clear();
        input.sendKeys(eventId);

        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//ng-dropdown-panel")));

        By option = By.xpath("//ng-dropdown-panel//div[@role='option'][.//strong[contains(text(),'ID: " + eventId + "')]]");
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(option));

        try {
            element.click();
        } catch (Exception e) {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", element);
        }
    }
    
    public void clickSave() {
    	WebElement saveBtn = driver.findElement(OutReachEventSetupLocator.saveButton);
    	saveBtn.click();
    }
    
    public void clickCancel() {
    	WebElement cancelBtn = driver.findElement(OutReachEventSetupLocator.cancelButtonORE);
    	cancelBtn.click();
    }
    
    
}