package pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import locators.reprintLocator;

public class reprintPage {

    WebDriver driver;
    WebDriverWait wait;

    public reprintPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

//    REPRINT BUTTON
    public void clickReprintBtn() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reprintLocator.reprintBtn));
        element.click();
    }
    
//	PATIENT TYPE
	public void selectpatientType(String patientType) {
	    WebElement patientTypeDropdown = wait.until(ExpectedConditions.elementToBeClickable(reprintLocator.patientTypeInput));

	    Select select = new Select(patientTypeDropdown);
	    select.selectByVisibleText(patientType);
	    
	    patientTypeDropdown.sendKeys(Keys.TAB);
	    
	}
    
//  ENTER DATE
  public void enterDate(String date) {
      WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(reprintLocator.dateInput));
      element.sendKeys(date);       
  }
  
//    ENTER OID
    public void enterOid(String oid) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(reprintLocator.oidInput));
        element.clear();
        element.sendKeys(oid);       
    }
 
//    SUBMIT BUTTON
    public void clickSubmitBtn() {
        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(reprintLocator.submitBtn));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
    }
  
    
//    CANCEL BUTTON   
    public void clickCancelBtn() {
   	 WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(reprintLocator.cancelBtn));
//	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
   	 btn.click();
    }   
    
//    CLOSE BUTTON   
 public void clickCloseBtn() {
	 WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(reprintLocator.closeBtn));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
 } 

    
    
}
