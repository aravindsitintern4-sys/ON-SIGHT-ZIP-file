package pages;


import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import locators.clinicalRecordsLocator;





public class clinicalRecordsPage {

    WebDriver driver;
    WebDriverWait wait;

    public clinicalRecordsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
//  CLINICAL RECORDS OPTION CLICK
    public void clickClinicalRecordsOption() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.clinicalRecordsOption));
        element.click();
    }
  
//  PATIENT STATUS SEARCH CLICK
    public void clickPatientStatusSearch() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.patientStatusSearchOption));
        element.click();
    }    
    
 // REPORT VIEW ICON ACTION INSIDE CLINICAL RECORDS
    public void clickReportViewIcon() {
         WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.viewIcon));
         element.click();
    }  

//  ENTER PIN 
    public void enterPin(String value) {

        // RESET BUTTON
        if (value.equalsIgnoreCase("Reset")) {
        	JavascriptExecutor js = (JavascriptExecutor) driver;
            WebElement resetBtn = wait.until(ExpectedConditions.elementToBeClickable( clinicalRecordsLocator.pinButton("Reset")));
            js.executeScript("arguments[0].click();", resetBtn);
            System.out.println("Clicked Reset");

        } 
        // REMOVE ICON
        else if (value.equalsIgnoreCase("Delete")) {
        	JavascriptExecutor js = (JavascriptExecutor) driver;
            WebElement deleteBtn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.deletePinBtn));
            js.executeScript("arguments[0].click();", deleteBtn);
            System.out.println("Clicked Delete");
        }
        // NUMERIC VALUES
        else {
        	JavascriptExecutor js = (JavascriptExecutor) driver;
           for (char digit : value.toCharArray()) {
              WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.enterPin(String.valueOf(digit))));
              js.executeScript("arguments[0].click();", btn);
            }
        }
    }
    
//  VISION  
// VISION CHART    
    public void selectVisionChart(String option) {

        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.visionChart));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        Select select = new Select(element);
        select.selectByVisibleText(option);

        System.out.println("Selected: " + select.getFirstSelectedOption().getText());
    }
    
// UCVA DROPDOWN VISION CHART   
    public void selectUCVA(String reValue, String leValue) {

        By dropdownBtn = By.id("dropdownLabelUcva");
        By dropdownVisible = By.xpath("//div[contains(@class,'dropdown-content') and not(contains(@style,'display: none'))]");
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdownBtn));
        dropdown.click();
        WebElement re = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectRE(reValue)));
        re.click();
        if (driver.findElements(dropdownVisible).isEmpty()) {
            dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdownBtn));
            dropdown.click();
        }
        WebElement le = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectLE(leValue)));
        le.click();    
    }
    
 // UCVAph DROPDOWN VISION CHART   
    public void selectUCVAph(String reValue, String leValue) {
        By dropdownBtn = By.id("dropdownLabelUcvaph");
        By dropdownVisible = By.xpath("//div[@id='customDropdownUcvaph']//div[contains(@class,'dropdown-content') and not(contains(@style,'display: none'))]");
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdownBtn));
        dropdown.click();
        WebElement re = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectREph(reValue)));
        re.click();
        if (driver.findElements(dropdownVisible).isEmpty()) {
            dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdownBtn));
            dropdown.click();
        }
        WebElement le = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectLEph(leValue)));
        le.click();
    }
 
//    METHODS DROPDOWN IN VISION
    public void selectMethod(String option) {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.methodInput));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dropdown);
        
        Select select = new Select(dropdown);
        select.selectByVisibleText(option);
    }
  
// SAVE BUTTON IN VISION     
    public void clickSaveBtn() {
    	System.out.println("SAVE BTN STRAT IN VISION");
    	 WebElement saveBtn = wait.until(
    		        ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.saveVisBtn));
    		    wait.until(driver -> saveBtn.isEnabled());

    		    ((JavascriptExecutor) driver)
    		        .executeScript("arguments[0].scrollIntoView(true);", saveBtn);

    		    saveBtn.click();
    		    System.out.println("SAVE BTN CLICKED IN VISION");
    }



    
// INVESTIGATIONS

// IOP

	// RE IOP INPUT
	public void enterREIOP(String iop) {
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.IOPREInput));
	    element.sendKeys(iop);
	}  
	// RE IOP DROPDOWN
	public void selectREIOP(String iop) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.IOPREdropdown));
	    Select select = new Select(element);
	    select.selectByVisibleText(iop);
	}    
	    
	//LE IOP INPUT
	public void enterLEIOP(String iop) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.IOPLEInput));
		 element.sendKeys(iop);	 
	}  
	//LE IOP DROPDOWN
	public void selectLEIOP(String iop) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.IOPLEdropdown));
		 Select select = new Select(element);
		 select.selectByVisibleText(iop);
	}   

// DUCT
	
	// DUCT RE LOWER 
	public void selectREDuctLower(String duct) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Duct_RE_Lower));
		 Select select = new Select(element);
		 select.selectByVisibleText(duct);
	}
	//DUCT RE UPPER 
	public void selectREDuctUpper(String duct) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Duct_RE_Upper));
		 Select select = new Select(element);
		 select.selectByVisibleText(duct);
	} 
	//DUCT LE LOWER 
	public void selectLEDuctLower(String duct) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Duct_LE_Lower));
		 Select select = new Select(element);
		 select.selectByVisibleText(duct);
	}
	//DUCT LE UPPER 
	public void selectLEDuctUpper(String duct) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Duct_LE_Upper));
		 Select select = new Select(element);
		 select.selectByVisibleText(duct);
	}

// ROPLAS
	
	//ROPLAS RE
	public void selectRoplasRE(String value) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Roplas_RE));
		 Select select = new Select(element);
		 select.selectByVisibleText(value);
	}
	//ROPLAS LE
	public void selectRoplasLE(String value) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Roplas_LE));
		 Select select = new Select(element);
		 select.selectByVisibleText(value);
	}
	
// BLOOD SUGAR
	// TYPE OF BLOOD SUGAR
	public void selectBloodSugarType(String type) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BloodSugar_Type));
	    Select select = new Select(element);
		 select.selectByVisibleText(type);
	}
	// LEVEL OF SUGAR
	public void enterBloodSugarValue(String value) {
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.BloodSugar_Value));
	    element.click();
	    element.clear();
	    element.sendKeys(value);
	}
	// BLOOD SUGAR TEST LOCATION
	public void selectBloodSugarLocation(String location) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BloodSugar_Location));
	    new Select(element).selectByVisibleText(location);
	}
	// BLOOD SUGAR TESTED DATE
	public void selectBloodSugarDate(String date) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BloodSugar_Date));
	    element.sendKeys(date); // format: yyyy-MM-dd
	}
	
// BLOOD PRESSURE
	
	// BP SYSTOLIC INPUT BOX
	public void enterBPSystolic(String value) {
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.BP_Systolic));
	    element.click();
	    element.clear();
	    element.sendKeys(value);
	}
	// BP DIASTOLIC
	public void enterBPDiastolic(String value) {
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.BP_Diastolic));
	    element.click();
	    element.clear();
	    element.sendKeys(value);
	}

public void clickDeleteIcon(String name) {
    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DeleteIcon(name)));
    element.click();
}    
    
public void clickSaveIcon(String name) {
    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.SaveIcon(name)));
    element.click();
}    
    
public void clickEditIcon(String name) {
    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.EditIcon(name)));
    element.click();
}    
    
public void clickRepeatIcon(String name) {
    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.RepeatIcon(name)));
    element.click();
}    
    
public void clickPlusIcon(String name) {

    WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.PlusIcon(name)));

    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

    try {
        element.click();
    } catch (Exception e) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }
}    
    
    
//COMPLAINTS


	//SELECT EYE AND TYPE OF COMPLAINT
	public void selectEyeComplaints(String complaint, String eye) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.eyeForComplaint(complaint,eye)));
	    element.click();
	}
	    
	//SELECT COMPLAINTS NAME
	public void selectComplaints(String complaints) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectComplaints(complaints)));
		 element.click();
	}    
	    
	//SELECT DURATION VALUE FOR COMPLAINTS (0-9)
	public void selectDurationValue(String value) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectDurationValueComplaints(value)));
		element.click();
	}     
	    
	//SELECT DURATION TYPE FOR COMPLAINTS (year, month..)
	public void selectDurationType(String type) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectDurationTypeComplaints(type)));
		element.click();
	} 
	
	// OPEN DURATION 
	public void openDuration(String complaint) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationOpen(complaint)));
	    element.click();
	}
	
	// DURATION SETTING WITH VALUES (0-9)
	public void setDurationValue(String value) {
	
	//ACCEPT ONLY 2 DIGITs
	//	  if (value.length() > 2) {
	//	        value = value.substring(0, 2);
	//	    }
		  
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    for (char digit : value.toCharArray()) {
	        String num = String.valueOf(digit);
	        WebElement valueBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.durationValue(num)));
	        js.executeScript("arguments[0].click();", valueBtn);
	    }
	}
	
	//DURATION TYPE (Day,Month,Year,...)
	public void setDurationType(String type) {
		WebElement typeBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.durationType(type)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", typeBtn);
	}
	
	// DURATION BUTTONS (RESET, BACK, OK)
	public void setDurationBtn(String button) {
		 WebElement Btn = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.durationBtn(button)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", Btn);
	}
	
	//INVALID DURATION ERROR 
	public void validateInvalidDuration() {
	
	    WebElement error = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.invalidDurationMsg));
	    System.out.println("Error displayed: " + error.getText());
	}
	
	// SELECTED DURATION DISPLAY
	public void validateComplaintWithDurationDisplayed() {
	
	    WebElement textarea = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.complaintTextArea));
	    String text = textarea.getAttribute("value").toLowerCase().trim();
	    if (text.isEmpty() || !(text.contains("day") || text.contains("month") || 
	         text.contains("year") || text.contains("week"))) {
	
	        throw new AssertionError("Duration not displayed properly: " + text);
	    }
	
	    System.out.println("Displayed: " + text);
	}
	
	// SYSTEM ALERT CONFIRMATION AND CANCELATION
	public void confirmationBtnDelete(String btn) {
		   Alert alert = wait.until(ExpectedConditions.alertIsPresent());
	
		    if (btn.equalsIgnoreCase("OK")) {
		        alert.accept();   
		    } else if (btn.equalsIgnoreCase("Cancel")) {
		        alert.dismiss();  
		    } else {
		        throw new IllegalArgumentException("Invalid button: " + btn);
		    }
	}
	
	// COMPLAINT DROPDOWN ( ALL COMPLAINTS )
	public void selectComplaintsDropdown(String complaints) {
	
	    WebElement panel = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dropdownPannelComplaints));
	    panel.click();
	
	    WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.dropdownInput));
	
	    // INPUTS SEPERATED BY COMMA
	    String[] complaintList = complaints.split(",");
	
	    for (String complaint : complaintList) {
	        input.clear(); 
	        input.sendKeys(complaint.trim());
	        input.sendKeys(Keys.ENTER);
	    }
	    input.sendKeys(Keys.TAB);
	}
	
	public void openDuration() {
	
	    WebElement duration = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationOpenBtn));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", duration);
	}
	
	
	//DURATION SETTING WITH VALUES (0-9)
	public void setDurationValueAllComplaints(String value) {
	
	    for (char digit : value.toCharArray()) {
	
	        String num = String.valueOf(digit);
	        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationValueAllComplaints(num)));
	        btn.click();
	        try {
	            Thread.sleep(200);  
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	}
	
	
	public void setDurationTypeAllComplaints(String type) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationTypeAllComplaints(type)));
	    btn.click();   
	}
	
	public void setDurationBtnAllComplaints(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationBtnAllComplaints(button)));
	    btn.click();  
	}
	
	//SAVE BUTTON
	public void clickSaveBtnComplaint() {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.saveBtn));
	    element.click();
	}

//COMPLAINT SUMMARY


	//COMPLAINT SUMMARY DISPLAYED  
	public void verifyComplaintSummaryDisplayed() {
	
	 WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.ComplaintSummary));
	
	 if (!summary.isDisplayed()) {
	     throw new AssertionError("Referral summary is NOT displayed");
	 }
	
	 System.out.println("Referral summary is displayed");
	} 
	
	//COMPLAINT SUMMARY NOT DISPLAYED
	public void verifyComplaintSummaryNotDisplayed() {
	
		 boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.ComplaintSummary));
		
		 if (!isNotVisible) {
		     throw new AssertionError("Referral summary is STILL displayed");
		 }
		
		 System.out.println("Referral summary is NOT displayed");
	}
	 
	//COMPLAINTS SUMMARY DELETE ICON
	public void ClickComplaintSummaryDeleteIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ComplaintSummaryDeleteIcon));
		 element.click();
	}
	 
	// COMPLAINT SUMMARY INFO ICON
	public void ClickComplaintSummaryInfoIcon() {
	
	    WebElement element = wait.until(
	        ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.ComplaintSummaryInfoIcon)
	    );
	
	    Actions actions = new Actions(driver);
	    actions.moveToElement(element)
	           .pause(Duration.ofMillis(300))
	           .click()
	           .perform();
	}
	//CHECK INFO ICON INFORMATION
	public void verifyComplaintInfoDisplayed(String name) {
	
		 WebElement hoverElement = driver.findElement(clinicalRecordsLocator.ComplaintSummaryInfoIcon); 
		 Actions actions = new Actions(driver);
		 actions.moveToElement(hoverElement).perform();
		
		 WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.complaintInfoByName(name)));
		
		 if (!info.isDisplayed()) {
		     throw new AssertionError("Patient info is NOT displayed after hover");
		 }
		
		 System.out.println("Patient info displayed: " + info.getText());
	}    
 


// SYSTEMIC HISTORY

	// SELECT OPTIONS
	public void selectSystemicHistory(String label, String option) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.systemicHistoryOption(label, option)));
	    element.click();
	}
	
	// DURATION FOR EVERY OPTION
	public void setDurationValueHistory(String value) {
	
	    for (char digit : value.toCharArray()) {
	        String num = String.valueOf(digit);
	        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationValueHistory(num)));
	        btn.click();
	    }
	}
	
	public void setDurationTypeHistory(String type) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationTypeHistory(type)));
	    btn.click();   
	}
	
	public void setDurationBtnHistory(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationBtnHistory(button)));
	    btn.click();  
	}
	
	// ADDITIONAL INPUT
	public void enterAdditionalDetail(String label, String info) {
	    WebElement btn = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.additionalInfoInput(label)));
	    btn.sendKeys(info);  
	}
	
	public void enterOtherAllergyInput(String info) {
	    WebElement btn = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.otherAllergyInput));
	    btn.sendKeys(info);  
	}
	
	public void selectDrugAllergy(String option) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.drugDropdown));
	    element.click();    
	    WebElement DrugName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.drugNameInput));
	    DrugName.sendKeys(option);
	    DrugName.sendKeys(Keys.ENTER);
	}   


// SYSTEMIC HISTORY SUMMARY

	//SYSTEMIC HISTORY SUMMARY DISPLAYED  
	public void verifyHistorySummaryDisplayed() {
	
	WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.HistorySummary));
	
	if (!summary.isDisplayed()) {
	   throw new AssertionError("Referral summary is NOT displayed");
	}
	
	System.out.println("Referral summary is displayed");
	} 
	
	//SYSTEMIC HISTORY SUMMARY NOT DISPLAYED
	public void verifyHistorySummaryNotDisplayed() {
	
		boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.HistorySummary));
		
		if (!isNotVisible) {
		   throw new AssertionError("Referral summary is STILL displayed");
		}
		
		System.out.println("Referral summary is NOT displayed");
	}
	
	//SYSTEMIC HISTORY SUMMARY INFO ICON
	public void ClickHistorySummaryInfoIcon() {
	
	  WebElement element = wait.until(
	      ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.HistorySummaryInfoIcon)
	  );
	
	  Actions actions = new Actions(driver);
	  actions.moveToElement(element)
	         .pause(Duration.ofMillis(300))
	         .click()
	         .perform();
	}
	//CHECK INFO ICON INFORMATION IN SYSTEMIC HISTORY
	public void verifyHistoryInfoDisplayed(String name) {
	
		WebElement hoverElement = driver.findElement(clinicalRecordsLocator.HistorySummaryInfoIcon); 
		Actions actions = new Actions(driver);
		actions.moveToElement(hoverElement).perform();
		
		WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.HistoryInfoByName(name)));
		
		if (!info.isDisplayed()) {
		   throw new AssertionError("User info is NOT displayed after hover");
		}
		
		System.out.println("Patient info displayed: " + info.getText());
	}    
	
	//CLEAR BUTTON IN HISTORY
	public void clickClearButton() {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.clearBtnHistory));
	    btn.click();  
	}
	
	// MANDATORY FIELD ACTION IN HISTORY
	public void validateMandatoryAlert() {
	    WebElement msg = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.mandatoryAlertMsg));
	    System.out.println("Alert: " + msg.getText());
	
	    if (!msg.isDisplayed()) {
	        throw new AssertionError("Mandatory alert not displayed");
	    }
	}


// ANTERIOR SEGMENT

	// SELECT SEGMENT OPTIONS WITH EYE
	public void selectAntiSegment(String segment, String eye , String option) {
	  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectOptionAntiSegment(segment,eye,option)));
	  element.click();
	}
	
	//SELECT SEGMENT OPTIONS WITHOUT EYE
	public void selectAntiSegmentFullOption(String segment, String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectFullOptionAntiSegment(segment,option)));
		  element.click();
	}
	
	// REMARKS FOR ANTERIOR SEGMENT
	public void enterRemarksAnteriorSegment(String eye, String remark) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.remarkInputAnteriorSegment(eye)));
		  element.sendKeys(remark);
	}

//ANTERIOR SEGMENT SUMMARY

	//ANTERIOR SEGMENT SUMMARY DISPLAYED  
	public void verifyAntiSegmentSummaryDisplayed() {
	
		WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.AntiSegmentSummary));
		
		if (!summary.isDisplayed()) {
		throw new AssertionError("Segment summary is NOT displayed");
		}
		
		System.out.println("Segment summary is displayed");
	} 
	
	//ANTERIOR SEGMENT SUMMARY NOT DISPLAYED
	public void verifyAntiSegmentSummaryNotDisplayed() {
	
		String text = driver.findElement(clinicalRecordsLocator.AntiSegmentSummary).getText();
	
	    if (text.contains("RE:") || text.contains("LE:")) {
	        throw new AssertionError("Ant. Segment data is STILL present");
	    }
	
	    System.out.println("Ant. Segment data is cleared successfully");
	}
	
	//ANTERIOR SEGMENT SUMMARY INFO ICON
	public void ClickAntiSegmentSummaryInfoIcon() {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.AntiSegmentSummaryInfoIcon));
		
		Actions actions = new Actions(driver);
		actions.moveToElement(element)
		      .pause(Duration.ofMillis(300))
		      .click()
		      .perform();
	}
	//CHECK INFO ICON INFORMATION IN ANTERIOR SEGMENT
	public void verifyAntiSegmentInfoDisplayed(String name) {
	
		WebElement hoverElement = driver.findElement(clinicalRecordsLocator.AntiSegmentSummaryInfoIcon); 
		Actions actions = new Actions(driver);
		actions.moveToElement(hoverElement).perform();
		
		WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.AntiSegmentInfoByName(name)));
		
		if (!info.isDisplayed()) {
		   throw new AssertionError("User info is NOT displayed after hover");
		}
		
		System.out.println("Patient info displayed: " + info.getText());
	}    
	
	
	//CLEAR BUTTON IN EXAMINATION
	public void clickClearButtonExamination() {
	  WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.clearBtnExamination));
	  btn.click();  
	}
	
	//SAVE BUTTON IN EXAMINATION
	public void clickSaveBtnExamination() {
		WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.saveBtnExamination));
		btn.click();  
	}
	
	//ANTERIOR SEGMENT SUMMARY DELETE ICON
	public void ClickAntiSegmentSummaryDeleteIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.AntiSegmentSummaryDeleteIcon));
	
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}
	
	// SAVE OR UPDATE BUTTONS
	public void clickSaveOrUpdateButton() {
	    
	    List<WebElement> saveBtn = driver.findElements(clinicalRecordsLocator.saveBtnExamination);
	    List<WebElement> updateBtn = driver.findElements(clinicalRecordsLocator.updateBtnExamination);
	
	    if (!saveBtn.isEmpty() && saveBtn.get(0).isDisplayed()) {
	        clickSaveBtnExamination();
	        System.out.println("Clicked Save button");
	    } 
	    else if (!updateBtn.isEmpty() && updateBtn.get(0).isDisplayed()) {
	        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(updateBtn.get(0)));
	        btn.click();
	        System.out.println("Clicked Update button");
	    } 
	    else {
	        throw new RuntimeException("Neither Save nor Update button is present");
	    }
	}


//FUNDUS 

	//SELECT FUNDUS OPTIONS WITH EYE
	public void selectFundus(String segment, String eye , String option) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectOptionFundus(segment,eye,option)));
		element.click();
	}
	
	//SELECT FUNDUS OPTIONS WITHOUT EYE
	public void selectFundusFullOption(String segment, String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectFullOptionFundus(segment,option)));
		  element.click();
	}
	
	//REMARKS FOR FUNDUS
	public void enterRemarksFundus(String eye, String remark) {
		  WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.remarkInputFundus(eye)));  
		  element.sendKeys(remark);
	}


// FUNDUS HISTORY SUMMARY

	//FUNDUS SUMMARY DISPLAYED  
	public void verifyFundusSummaryDisplayed() {
	
		WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.FundusSummary));
		
		if (!summary.isDisplayed()) {
		throw new AssertionError("Fundus summary is NOT displayed");
		}
		
		System.out.println("Fundus summary is displayed");
	} 
	
	//FUNDUS SUMMARY NOT DISPLAYED
	public void verifyFundusSummaryNotDisplayed() {
	
		String text = driver.findElement(clinicalRecordsLocator.FundusSummary).getText();
	
	  if (text.contains("RE:") || text.contains("LE:")) {
	      throw new AssertionError("Fundus data is STILL present");
	  }
	
	  System.out.println("Fundus data is cleared successfully");
	}
	
	//FUNDUS SUMMARY INFO ICON
	public void ClickFundusSummaryInfoIcon() {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.FundusSummaryInfoIcon));
		
		Actions actions = new Actions(driver);
		actions.moveToElement(element)
		      .pause(Duration.ofMillis(300))
		      .click()
		      .perform();
	}
	//CHECK INFO ICON INFORMATION IN FUNDUS
	public void verifyFundusInfoDisplayed(String name) {
	
		WebElement hoverElement = driver.findElement(clinicalRecordsLocator.FundusSummaryInfoIcon); 
		Actions actions = new Actions(driver);
		actions.moveToElement(hoverElement).perform();
		
		WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.FundusInfoByName(name)));
		
		if (!info.isDisplayed()) {
		   throw new AssertionError("User info is NOT displayed after hover");
		}
		
		System.out.println("User info displayed: " + info.getText());
	}    
	
	//FUNDUS SUMMARY DELETE ICON
	public void ClickFundusSummaryDeleteIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.FundusSummaryDeleteIcon));
	
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}


//DIAGNOSIS 

	//SELECT EYE AND TYPE OF DIAGNOSIS
	public void selectEyeDignosis(String diagnosis, String eye) {
	  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectOptionDiagnosis(diagnosis,eye)));
	  element.click();
	}
	  
	//SELECT DIAGNOSIS NAME
	public void selectDiagnosis(String diagnosis) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectFullOptionDiagnosis(diagnosis)));
		 element.click();
	}    
	
	//OTHER DIAGNOSIS DROPDOWN
	public void selectDiagnosisDropdown(String diagnosis) {
	
	    WebElement input = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectDropdownDiagnosis));
	
	    input.click();
	    input.clear();
	    input.sendKeys(diagnosis);
	    
	    WebElement optionElement = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.optionOtherDiagnosisDropdown(diagnosis)));
	
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", optionElement);
	} 
	
	//REMARKS FOR FUNDUS
	public void enterRemarksDiagnosis(String eye, String remark) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.remarkInputDiagnosis(eye)));
		  element.sendKeys(remark);
	}
	
	// ALERT IN DIAGNOSIS
	public void validateAlertDiagnosis() {
	 WebElement msg = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.AlertMsgDiagosis));
	 System.out.println("Alert: " + msg.getText());
	
	 if (!msg.isDisplayed()) {
	     throw new AssertionError("Not allowed alert not displayed");
	 }
	}

//DIAGNOSIS HISTORY SUMMARY

	//DIAGNOSIS SUMMARY DISPLAYED  
	public void verifyDiagnosisSummaryDisplayed() {
	
		WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.DiagnosisSummary));
		
		if (!summary.isDisplayed()) {
		throw new AssertionError("Diagnosis summary is NOT displayed");
		}
		
		System.out.println("Diagnosis summary is displayed");
	} 
	
	//DIAGNOSIS SUMMARY NOT DISPLAYED
	public void verifyDiagnosisSummaryNotDisplayed() {
	
		String text = driver.findElement(clinicalRecordsLocator.DiagnosisSummary).getText();
	
		if (text.contains("RE:") || text.contains("LE:")) {
		   throw new AssertionError("Diagnosis data is STILL present");
		}
		
		System.out.println("Diagnosis data is cleared successfully");
	}
	
	//DIAGNOSIS SUMMARY INFO ICON
	public void ClickDiagnosisSummaryInfoIcon() {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.DiagnosisSummaryInfoIcon));
		
		Actions actions = new Actions(driver);
		actions.moveToElement(element)
		      .pause(Duration.ofMillis(300))
		      .click()
		      .perform();
	}
	//CHECK INFO ICON INFORMATION IN DIAGNOSIS
	public void verifyDiagnosisInfoDisplayed(String name) {
	
		WebElement hoverElement = driver.findElement(clinicalRecordsLocator.DiagnosisSummaryInfoIcon); 
		Actions actions = new Actions(driver);
		actions.moveToElement(hoverElement).perform();
		
		WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.DiagnosisInfoByName(name)));
		
		if (!info.isDisplayed()) {
		   throw new AssertionError("User info is NOT displayed after hover");
		}
		
		System.out.println("User info displayed: " + info.getText());
	}    
	
	//DIAGNOSIS SUMMARY DELETE ICON
	public void ClickDiagnosisSummaryDeleteIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DiagnosisSummaryDeleteIcon));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}
	
	//OTHER DIAGNOSIS EYE TYPE
	public void ClickOtherDiagnosisEyeType(String eye) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.otherDiagnosisEyeType(eye)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}
	
	
// ADVICE


//  REFERRAL ADVICE MODULE
    
	//HOSPITAL DROPDOWN   
	  public void selectHospitalDropdown(String option) {
	      WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.hospitalInput));
	      element.click();    
	      WebElement eventOrgName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.hosInput));
	      eventOrgName.sendKeys(option);
	      eventOrgName.sendKeys(Keys.ENTER);
	  }
	  
	//CLINIC DROPDOWN   
	public void selectclinicDropdown(String option) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.clinicInput));
	    element.click();    
	    WebElement eventOrgName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.cliInput));
	    eventOrgName.sendKeys(option);
	    eventOrgName.sendKeys(Keys.ENTER);
	}    
	  
	//REASON FOR REFERRAL DROPDOWN   
	public void selectReasonRefDropdown(String option) {
	  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.reasonInput));
	  element.click();    
	  WebElement reasonRefName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.reasonRefInput));
	  reasonRefName.sendKeys(option);
	  reasonRefName.sendKeys(Keys.ENTER);
	}   
	     
	//SAVE BUTTON IN REFERRAL     
	public void clickSaveRefBtn() {
		WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.saveRefBtn));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn);
		wait.until(ExpectedConditions.elementToBeClickable(saveBtn)).click();
	}  

//REFERRAL ADVICE SUMMARY
	
	//REFERRAL ADVICE SUMMARY DISPLAYED  
	public void verifyReferralSummaryDisplayed() {
		  WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.ReferralSummary));
		  if (!summary.isDisplayed()) {
		      throw new AssertionError("Referral summary is NOT displayed");
		  }
		  System.out.println("Referral summary is displayed");
	} 
	
	//REFERRAL ADVICE SUMMARY NOT DISPLAYED
	public void verifyReferralSummaryNotDisplayed() {
		  boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.ReferralSummary));
		  if (!isNotVisible) {
		      throw new AssertionError("Referral summary is STILL displayed");
		  }
		  System.out.println("Referral summary is NOT displayed");
	}
	  
	//REFERRAL ADVICE SUMMARY DELETE ICON
	public void ClickReferralSummaryDeleteIcon() {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ReferralSummaryDeleteIcon));
		  element.click();
	}
	
	//REFERRAL ADVICE SUMMARY PRINT ICON
	public void ClickReferralSummaryPrintIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ReferralSummaryPrintIcon));
		 element.click();
	}
	  
	//REFERRAL ADVICE SUMMARY INFO ICON
	public void ClickReferralSummaryInfoIcon() {
		 Actions actions = new Actions(driver);
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ReferralSummaryInfoIcon));
		 actions.moveToElement(element).perform();
	} 
	
	//CHECK INFO ICON INFORMATION
	public void verifyPatientInfoDisplayed(String name) {
	  WebElement hoverElement = driver.findElement(clinicalRecordsLocator.ReferralSummaryInfoIcon); 
	  Actions actions = new Actions(driver);
	  actions.moveToElement(hoverElement).perform();
	  
	  WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.patientInfoByName(name)));
	  if (!info.isDisplayed()) {
	      throw new AssertionError("Patient info is NOT displayed after hover");
	  }
	
	  System.out.println("Patient info displayed: " + info.getText());
	}    
  
  
// DRUG PRESCRIPTION (DP) ADVICE
	
	//SELECT EYE AND TYPE OF DRUG
	public void selectEyeDrug(String drug, String eye) {
	  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectOptionDrug(drug,eye)));
	  element.click();
	}
		  
	//SELECT DRUG NAME
	public void selectDrug(String drug) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectFullOptionDrug(drug)));
		 element.click();
	}   
	
	//SELECT EYE TYPE 
	public void selectEyeTypeDP(String drug) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectEyeType));
		 Select select = new Select(element);
		 select.selectByVisibleText(drug);
	}

	//DRUG NAME DROPDOWN   
	public void selectDrugNameDP(String option) {
	  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.drugNameDropdown));
	  element.click();    
	  WebElement DrugName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.drugNameDropdownInput));
	  DrugName.sendKeys(option);
	  DrugName.sendKeys(Keys.ENTER);
	}  

	//SELECT FREQUENCY DROPDOWN
	public void selectFrequencyDropDP(String frequency) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectFrequency));
		 Select select = new Select(element);
		 select.selectByVisibleText(frequency);
	}

	// DURATION INPUT
	public void enterDurationDP(String duration) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.DurationInputDP));
		 element.sendKeys(duration);
	}

	//SELECT DURATION TYPE DROPDOWN
	public void selectDurationTypeDP(String type) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectDurationType));
		 Select select = new Select(element);
		 select.selectByVisibleText(type);
	}

	//REMARKS INPUT
	public void enterRemarkDP(String remark) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.enterRemarksDP));
		 element.sendKeys(remark);
	}
	
	//SELECT PRESCRIPTION LANGUAGE DROPDOWN
	public void selectPresLanguageDP(String language) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectPresLanguage));
		 Select select = new Select(element);
		 select.selectByVisibleText(language);
	}

	//BUTTON ACTIONS IN DP
	public void buttonActionsDP(String btn) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DPButtons(btn)));
		 element.click();
	}

// DRUG PRESCRIPTION (DP) ADVICE SUMMARY
	
	//DP ADVICE SUMMARY DISPLAYED  
	public void verifyDPSummaryDisplayed() {
		  WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.DPSummary));
		  if (!summary.isDisplayed()) {
		      throw new AssertionError("DP summary is NOT displayed");
		  }
		  System.out.println("DP summary is displayed");
	} 
	
	//DP ADVICE SUMMARY NOT DISPLAYED
	public void verifyDPSummaryNotDisplayed() {
		  boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.DPSummary));
		  if (!isNotVisible) {
		      throw new AssertionError("DP summary is STILL displayed");
		  }
		  System.out.println("DP summary is NOT displayed");
	}
	  
	//DP ADVICE SUMMARY DELETE ICON
	public void ClickDPSummaryDeleteIcon() {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DPSummaryDeleteIcon));
		  element.click();
	}
	
	//DP ADVICE SUMMARY PRINT ICON
	public void ClickDPSummaryPrintIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DPSummaryPrintIcon));
		 element.click();
	}
	  
	//DP ADVICE SUMMARY INFO ICON
	public void ClickDPSummaryInfoIcon() {
		 Actions actions = new Actions(driver);
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DPSummaryInfoIcon));
		 actions.moveToElement(element).perform();
	}

	//CHECK INFO ICON INFORMATION
	public void verifyPatientInfoDisplayedDP(String name) {
	  WebElement hoverElement = driver.findElement(clinicalRecordsLocator.DPSummaryInfoIcon); 
	  Actions actions = new Actions(driver);
	  actions.moveToElement(hoverElement).perform();
	  
	  WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.patientInfoByNameDP(name)));
	  if (!info.isDisplayed()) {
	      throw new AssertionError("User info is NOT displayed after hover");
	  }
	
	  System.out.println("User info displayed: " + info.getText());
	}   


// SURGERY ADVICE
	
	//SELECT EYE TYPE
	public void selectEyeSurgery(String label, String eye) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectEyeTypeSurgery(label,eye)));
		  element.click();
	}

	//OTHER SURGERY DROPDOWN   
	public void selectSurgeryDropdown(String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.surgeryNameDropdown));
		  element.click();    
		  WebElement SurgeryName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.surgeryNameDropdownInput));
		  SurgeryName.sendKeys(option);
		  SurgeryName.sendKeys(Keys.ENTER);
	}
	
	//REMARKS
	public void enterRemarkSurgery(String remark) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.remarkInputSurgery));
		  element.sendKeys(remark);
	}

	// SURGERY DATE
	public void enterSurgeryDate(String date) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dateInputSurgery));
		  element.sendKeys(date);
	}

	// SURGERY NOT CONFIRMED REASON DROPDOWN   
	public void selectSurgeryReasonDropdown(String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.surgeryReasonDropdown));
		  element.click();    
		  WebElement SurgeryReason = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.surgeryReasonDropdownInput));
		  SurgeryReason.sendKeys(option);
		  SurgeryReason.sendKeys(Keys.ENTER);
	}

	//BUTTON ACTIONS IN SURGERY
	public void buttonActionsSurgery(String btn) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.SurgeryButtons(btn)));
		 element.click();
	}
	
	//BUTTON ACTIONS IN SURGERY
	public void buttonActionsSurgeryCounselling(String btn) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.SurgeryCounsellingButtons(btn)));
		 element.click();
	}

// SURGERY ADVICE SUMMARY
	
	//LINK ACTIONS IN SURGERY
	public void linkActionsSurgery(String link) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.CounsellingLink(link)));
		 element.click();
	}
		
	//SURGERY ADVICE SUMMARY DISPLAYED  
	public void verifySurgerySummaryDisplayed() {
		  WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.SurgerySummary));
		  if (!summary.isDisplayed()) {
		      throw new AssertionError("Surgery summary is NOT displayed");
		  }
		  System.out.println("Surgery summary is displayed");
	} 
	
	//SURGERY ADVICE SUMMARY NOT DISPLAYED
	public void verifySurgerySummaryNotDisplayed() {
		  boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.SurgerySummary));
		  if (!isNotVisible) {
		      throw new AssertionError("Surgery summary is STILL displayed");
		  }
		  System.out.println("Surgery summary is NOT displayed");
	}
	  
	//SURGERY ADVICE SUMMARY DELETE ICON
	public void ClickSurgerySummaryDeleteIcon() {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.SurgerySummaryDeleteIcon));
		  element.click();
	}

	//SURGERY ADVICE SUMMARY INFO ICON
	public void ClickSurgerySummaryInfoIcon() {
		 Actions actions = new Actions(driver);
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.SurgerySummaryInfoIcon));
		 actions.moveToElement(element).perform();
	}

	//CHECK INFO ICON INFORMATION
	public void verifyPatientInfoDisplayedSurgery(String name) {
	  WebElement hoverElement = driver.findElement(clinicalRecordsLocator.SurgerySummaryInfoIcon); 
	  Actions actions = new Actions(driver);
	  actions.moveToElement(hoverElement).perform();
	  
	  WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.patientInfoByNameSurgery(name)));
	  if (!info.isDisplayed()) {
	      throw new AssertionError("User info is NOT displayed after hover");
	  }
	
	  System.out.println("User info displayed: " + info.getText());
	}   

































}
