package pages;


import java.time.Duration;
//import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import locators.clinicalRecordsLocator;




public class clinicalRecordsPage {

    WebDriver driver;
    WebDriverWait wait;

    public clinicalRecordsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
    
//  CLINICAL RECORDS OPTION CLICK
    public void clickClinicalRecordsOption() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.clinicalRecordsOption));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
    }
    
//  STATION SELCTION DROPDOWN 
    public void clickStationSelectionDropdown(String option) {

        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.stationDropdown));

        Select select = new Select(element);
        wait.until(driver -> select.getOptions().size() > 1);

        select.selectByVisibleText(option);
        }
  
//  PATIENT STATUS SEARCH CLICK
    public void clickPatientStatusSearch() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.patientStatusSearchOption));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
    }    
    
 // REPORT VIEW ICON ACTION INSIDE CLINICAL RECORDS
    public void clickReportViewIcon() {
         WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.viewIcon));
         ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
    }  

//  ENTER PIN 
    public void enterPin(String value) {

        // RESET BUTTON
        if (value.equalsIgnoreCase("Reset")) {
        	JavascriptExecutor js = (JavascriptExecutor) driver;
            WebElement resetBtn = wait.until(ExpectedConditions.elementToBeClickable( clinicalRecordsLocator.pinButton("Reset")));
            js.executeScript("arguments[0].click();", resetBtn);
            System.out.println("Clicked Reset");

        } 
        // REMOVE ICON
        else if (value.equalsIgnoreCase("Delete")) {
        	JavascriptExecutor js = (JavascriptExecutor) driver;
            WebElement deleteBtn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.deletePinBtn));
            js.executeScript("arguments[0].click();", deleteBtn);
            System.out.println("Clicked Delete");
        }
        // NUMERIC VALUES
        else {
        	JavascriptExecutor js = (JavascriptExecutor) driver;
           for (char digit : value.toCharArray()) {
              WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.enterPin(String.valueOf(digit))));
              js.executeScript("arguments[0].click();", btn);
            }
        }
    }
    
//  VISION  
// VISION CHART    
    public void selectVisionChart(String option) {

        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.visionChart));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        Select select = new Select(element);
        select.selectByVisibleText(option);

        System.out.println("Selected: " + select.getFirstSelectedOption().getText());
    }
    
// UCVA DROPDOWN VISION CHART   
    public void selectUCVA(String reValue, String leValue) {
                        
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dropdownBtnUcva));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", dropdown);

        try {
            dropdown.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", dropdown);         
        }
        
        WebElement re = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectRE(reValue)));
        re.click();
        if (driver.findElements(clinicalRecordsLocator.dropdownVisibleUcva).isEmpty()) {
            dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dropdownBtnUcva));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", dropdown);
            try {
                dropdown.click();
            } catch (Exception e) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", dropdown); 
            }
        }
        
        WebElement le = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectLE(leValue)));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", le);

        try {
            le.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", le);       
        }    
    }
    
 // UCVAph DROPDOWN VISION CHART   
    public void selectUCVAph(String reValue, String leValue) {
                
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dropdownBtn));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", dropdown);

        try {
            dropdown.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", dropdown);
         
        }
        WebElement re = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectREph(reValue)));
        re.click();
        if (driver.findElements(clinicalRecordsLocator.dropdownVisible).isEmpty()) {
            dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdown));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", dropdown);

            try {
                dropdown.click();
            } catch (Exception e) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", dropdown);
             
            }
        }
        WebElement le = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectLEph(leValue)));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", le);

        try {
            le.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", le);
         
        }
    }
 
//  METHODS DROPDOWN IN VISION
    public void selectMethod(String option) {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.methodInput));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dropdown);
        
        Select select = new Select(dropdown);
        select.selectByVisibleText(option);
    }
  
//  SAVE BUTTON IN VISION     
    public void clickSaveBtn() {
    	System.out.println("SAVE BTN STRAT IN VISION");
    	WebElement saveBtn = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.saveVisBtn));
	    wait.until(driver -> saveBtn.isEnabled());

	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn);

	    saveBtn.click();
	    System.out.println("SAVE BTN CLICKED IN VISION");
    }



    
// INVESTIGATIONS

// IOP

	// RE IOP INPUT
	public void enterREIOP(String iop) {
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.IOPREInput));
	    element.sendKeys(iop);
	}  
	// RE IOP DROPDOWN
	public void selectREIOP(String iop) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.IOPREdropdown));
	    Select select = new Select(element);
	    select.selectByVisibleText(iop);
	}    
	    
	//LE IOP INPUT
	public void enterLEIOP(String iop) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.IOPLEInput));
		 element.sendKeys(iop);	 
	}  
	//LE IOP DROPDOWN
	public void selectLEIOP(String iop) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.IOPLEdropdown));
		 Select select = new Select(element);
		 select.selectByVisibleText(iop);
	}   

// DUCT
	
	// DUCT RE LOWER 
	public void selectREDuctLower(String duct) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Duct_RE_Lower));
		 Select select = new Select(element);
		 select.selectByVisibleText(duct);
	}
	//DUCT RE UPPER 
	public void selectREDuctUpper(String duct) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Duct_RE_Upper));
		 Select select = new Select(element);
		 select.selectByVisibleText(duct);
	} 
	//DUCT LE LOWER 
	public void selectLEDuctLower(String duct) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Duct_LE_Lower));
		 Select select = new Select(element);
		 select.selectByVisibleText(duct);
	}
	//DUCT LE UPPER 
	public void selectLEDuctUpper(String duct) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Duct_LE_Upper));
		 Select select = new Select(element);
		 select.selectByVisibleText(duct);
	}

// ROPLAS
	
	//ROPLAS RE
	public void selectRoplasRE(String value) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Roplas_RE));
		 Select select = new Select(element);
		 select.selectByVisibleText(value);
	}
	//ROPLAS LE
	public void selectRoplasLE(String value) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.Roplas_LE));
		 Select select = new Select(element);
		 select.selectByVisibleText(value);
	}
	
// BLOOD SUGAR
	
	// TYPE OF BLOOD SUGAR
	public void selectBloodSugarType(String type) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BloodSugar_Type));
	    Select select = new Select(element);
		 select.selectByVisibleText(type);
	}
	
	// LEVEL OF SUGAR
	public void enterBloodSugarValue(String value) {
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.BloodSugar_Value));
	    element.click();
	    element.clear();
	    element.sendKeys(value);
	}
	
	// BLOOD SUGAR TEST LOCATION
	public void selectBloodSugarLocation(String location) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BloodSugar_Location));
	    new Select(element).selectByVisibleText(location);
	}
	
	// BLOOD SUGAR TESTED DATE
	public void selectBloodSugarDate(String date) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BloodSugar_Date));
	    element.sendKeys(date); // FORMAT: YYYY-MM-DD
	}
	
// BLOOD PRESSURE
	
	// BP SYSTOLIC INPUT BOX
	public void enterBPSystolic(String value) {
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.BP_Systolic));
	    element.click();
	    element.clear();
	    element.sendKeys(value);
	}
	
	// BP DIASTOLIC
	public void enterBPDiastolic(String value) {
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.BP_Diastolic));
	    element.click();
	    element.clear();
	    element.sendKeys(value);
	}

	public void clickDeleteIcon(String name) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DeleteIcon(name)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}    
	    
	public void clickSaveIcon(String name) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.SaveIcon(name)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}    
	    
	public void clickEditIcon(String name) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.EditIcon(name)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}    
	    
	public void clickRepeatIcon(String name) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.RepeatIcon(name)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}    
	    
	public void clickPlusIcon(String name) {
	
	    WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.PlusIcon(name)));
	
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
	
	    try {
	        element.click();
	    } catch (Exception e) {
	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	    }
	}    
	    
    
//COMPLAINTS


	//SELECT EYE AND TYPE OF COMPLAINT
	public void selectEyeComplaints(String complaint, String eye) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.eyeForComplaint(complaint,eye)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}
	    
	//SELECT COMPLAINTS NAME
	public void selectComplaints(String complaints) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectComplaints(complaints)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}    
	    
	//SELECT DURATION VALUE FOR COMPLAINTS (0-9)
	public void selectDurationValue(String value) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectDurationValueComplaints(value)));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}     
	    
	//SELECT DURATION TYPE FOR COMPLAINTS (year, month..)
	public void selectDurationType(String type) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectDurationTypeComplaints(type)));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	} 
	
	// OPEN DURATION 
	public void openDuration(String complaint) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationOpen(complaint)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}
	
	// DURATION SETTING WITH VALUES (0-9)
	public void setDurationValue(String value) {
	
	//ACCEPT ONLY 2 DIGITs
	//	  if (value.length() > 2) {
	//	        value = value.substring(0, 2);
	//	    }
		  
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    for (char digit : value.toCharArray()) {
	        String num = String.valueOf(digit);
	        WebElement valueBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.durationValue(num)));
	        js.executeScript("arguments[0].click();", valueBtn);
	    }
	}
	
	//DURATION TYPE (Day,Month,Year,...)
	public void setDurationType(String type) {
		WebElement typeBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.durationType(type)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", typeBtn);
	}
	
	// DURATION BUTTONS (RESET, BACK, OK)
	public void setDurationBtn(String button) {
		 WebElement Btn = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.durationBtn(button)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", Btn);
	}
	
	//INVALID DURATION ERROR 
	public void validateInvalidDuration() {
	
	    WebElement error = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.invalidDurationMsg));
	    System.out.println("Error displayed: " + error.getText());
	}
	
	// SELECTED DURATION DISPLAY
	public void validateComplaintWithDurationDisplayed() {
	
	    WebElement textarea = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.complaintTextArea));
	    String text = textarea.getAttribute("value").toLowerCase().trim();
	    if (text.isEmpty() || !(text.contains("day") || text.contains("month") || 
	         text.contains("year") || text.contains("week"))) {
	
	        throw new AssertionError("Duration not displayed properly: " + text);
	    }
	
	    System.out.println("Displayed: " + text);
	}
	
	// SYSTEM ALERT CONFIRMATION AND CANCELATION
	public void confirmationBtnDelete(String btn) {
		   Alert alert = wait.until(ExpectedConditions.alertIsPresent());
	
		    if (btn.equalsIgnoreCase("OK")) {
		        alert.accept();   
		    } else if (btn.equalsIgnoreCase("Cancel")) {
		        alert.dismiss();  
		    } else {
		        throw new IllegalArgumentException("Invalid button: " + btn);
		    }
	}
	
	// COMPLAINT DROPDOWN ( ALL COMPLAINTS )
	public void selectComplaintsDropdown(String complaints) {
	
	    WebElement panel = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dropdownPannelComplaints));
	    panel.click();
	
	    WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.dropdownInput));
	
	    // INPUTS SEPERATED BY COMMA
	    String[] complaintList = complaints.split(",");
	
	    for (String complaint : complaintList) {
	        input.clear(); 
	        input.sendKeys(complaint.trim());
	        input.sendKeys(Keys.ENTER);
	    }
	    input.sendKeys(Keys.TAB);
	}
	
	public void openDuration() {
	
	    WebElement duration = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationOpenBtn));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", duration);
	}
	
	
	//DURATION SETTING WITH VALUES (0-9)
	public void setDurationValueAllComplaints(String value) {
	
	    for (char digit : value.toCharArray()) {
	
	        String num = String.valueOf(digit);
	        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationValueAllComplaints(num)));
	        btn.click();
	        try {
	            Thread.sleep(200);  
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	}
	
	// DURATION TYPE
	public void setDurationTypeAllComplaints(String type) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationTypeAllComplaints(type)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }   
	}
	
	//DURATION BUTTONS
	public void setDurationBtnAllComplaints(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationBtnAllComplaints(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        } 
	}
	
	//SAVE BUTTON
	public void clickSaveBtnComplaint() {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.saveBtn));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}

//COMPLAINT SUMMARY


	//COMPLAINT SUMMARY DISPLAYED  
	public void verifyComplaintSummaryDisplayed() {
	
	 WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.ComplaintSummary));
	
	 if (!summary.isDisplayed()) {
	     throw new AssertionError("Referral summary is NOT displayed");
	 }
	
	 System.out.println("Referral summary is displayed");
	} 
	
	//COMPLAINT SUMMARY NOT DISPLAYED
	public void verifyComplaintSummaryNotDisplayed() {
	
		 boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.ComplaintSummary));
		
		 if (!isNotVisible) {
		     throw new AssertionError("Complaints summary is STILL displayed");
		 }
		
		 System.out.println("Complaints summary is NOT displayed");
	}
	 
	//COMPLAINTS SUMMARY DELETE ICON
	public void ClickComplaintSummaryDeleteIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ComplaintSummaryDeleteIcon));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
	 
	// COMPLAINT SUMMARY INFO ICON
	public void ClickComplaintSummaryInfoIcon() {
	
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.ComplaintSummaryInfoIcon));
	
	    Actions actions = new Actions(driver);
	    actions.moveToElement(element)
	           .pause(Duration.ofMillis(300))
	           .click()
	           .perform();
	}
	
	//CHECK INFO ICON INFORMATION
	public void verifyComplaintInfoDisplayed(String name) {
	
		 WebElement hoverElement = driver.findElement(clinicalRecordsLocator.ComplaintSummaryInfoIcon); 
		 Actions actions = new Actions(driver);
		 actions.moveToElement(hoverElement).perform();
		
		 WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.complaintInfoByName(name)));
		
		 if (!info.isDisplayed()) {
		     throw new AssertionError("Patient info is NOT displayed after hover");
		 }
		
		 System.out.println("Patient info displayed: " + info.getText());
	}    
 
           
// SYSTEMIC HISTORY

	// SELECT OPTIONS
	public void selectSystemicHistory(String label, String option) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.systemicHistoryOption(label, option)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}
	
	// DURATION FOR EVERY OPTION
	public void setDurationValueHistory(String value) {
	
	    for (char digit : value.toCharArray()) {
	        String num = String.valueOf(digit);
	        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationValueHistory(num)));
	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

	        try {
	        	btn.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
	        }
	    }
	}
	
	public void setDurationTypeHistory(String type) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationTypeHistory(type)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }   
	}
	 
	public void setDurationBtnHistory(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationBtnHistory(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}
	
	// ADDITIONAL INPUT
	public void enterAdditionalDetail(String label, String info) {
	    WebElement btn = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.additionalInfoInput(label)));
	    btn.sendKeys(info);  
	}
	
	public void enterOtherAllergyInput(String info) {
	    WebElement btn = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.otherAllergyInput));
	    btn.sendKeys(info);  
	}
	
	public void selectDrugAllergy(String option) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.drugDropdown));
	    element.click();    
	    WebElement DrugName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.drugNameInput));
	    DrugName.sendKeys(option);
	    DrugName.sendKeys(Keys.ENTER);
	}   


// SYSTEMIC HISTORY SUMMARY

	//SYSTEMIC HISTORY SUMMARY DISPLAYED  
	public void verifyHistorySummaryDisplayed() {
	
		WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.HistorySummary));
		
		if (!summary.isDisplayed()) {
		   throw new AssertionError("Systemic history summary is NOT displayed");
		}
		
		System.out.println("Systemic history summary is displayed");
	} 
	
	//SYSTEMIC HISTORY SUMMARY NOT DISPLAYED
	public void verifyHistorySummaryNotDisplayed() {
	
		boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.HistorySummary));
		
		if (!isNotVisible) {
		   throw new AssertionError("Systemic history summary is STILL displayed");
		}
		
		System.out.println("Systemic history summary is NOT displayed");
	}
	
	//SYSTEMIC HISTORY SUMMARY INFO ICON
	public void ClickHistorySummaryInfoIcon() {
	
	  WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.HistorySummaryInfoIcon));
	
	  Actions actions = new Actions(driver);
	  actions.moveToElement(element)
	         .pause(Duration.ofMillis(300))
	         .click()
	         .perform();
	}
	
	//CHECK INFO ICON INFORMATION IN SYSTEMIC HISTORY
	public void verifyHistoryInfoDisplayed(String name) {
	
		WebElement hoverElement = driver.findElement(clinicalRecordsLocator.HistorySummaryInfoIcon); 
		Actions actions = new Actions(driver);
		actions.moveToElement(hoverElement).perform();
		
		WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.HistoryInfoByName(name)));
		
		if (!info.isDisplayed()) {
		   throw new AssertionError("User info is NOT displayed after hover");
		}
		
		System.out.println("User info displayed: " + info.getText());
	}    
	
	//CLEAR BUTTON IN HISTORY
	public void clickClearButton() {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.clearBtnHistory));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}
	
	// MANDATORY FIELD ACTION IN HISTORY
	public void validateMandatoryAlert() {
	    WebElement msg = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.mandatoryAlertMsg));
	    System.out.println("Alert: " + msg.getText());
	
	    if (!msg.isDisplayed()) {
	        throw new AssertionError("Mandatory alert not displayed");
	    }
	}


// ANTERIOR SEGMENT

	// SELECT SEGMENT OPTIONS WITH EYE
	public void selectAntiSegment(String segment, String eye , String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectOptionAntiSegment(segment,eye,option)));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
	
	      try {
	      	element.click();
	      } catch (Exception e) {
	          ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	      }
	}
	
	//SELECT SEGMENT OPTIONS WITHOUT EYE
	public void selectAntiSegmentFullOption(String segment, String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectFullOptionAntiSegment(segment,option)));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
	
	// REMARKS FOR ANTERIOR SEGMENT
	public void enterRemarksAnteriorSegment(String eye, String remark) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.remarkInputAnteriorSegment(eye)));
		  element.sendKeys(remark);
	}

//ANTERIOR SEGMENT SUMMARY

	//ANTERIOR SEGMENT SUMMARY DISPLAYED  
	public void verifyAntiSegmentSummaryDisplayed() {
	
		WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.AntiSegmentSummary));
		
		if (!summary.isDisplayed()) {
		throw new AssertionError("Segment summary is NOT displayed");
		}
		
		System.out.println("Segment summary is displayed");
	} 
	
	//ANTERIOR SEGMENT SUMMARY NOT DISPLAYED
	public void verifyAntiSegmentSummaryNotDisplayed() {
	
		String text = driver.findElement(clinicalRecordsLocator.AntiSegmentSummary).getText();
	
	    if (text.contains("RE:") || text.contains("LE:")) {
	        throw new AssertionError("Ant. Segment data is STILL present");
	    }
	
	    System.out.println("Ant. Segment data is cleared successfully");
	}
	
	//ANTERIOR SEGMENT SUMMARY INFO ICON
	public void ClickAntiSegmentSummaryInfoIcon() {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.AntiSegmentSummaryInfoIcon));
		
		Actions actions = new Actions(driver);
		actions.moveToElement(element)
		      .pause(Duration.ofMillis(300))
		      .click()
		      .perform();
	}
	
	//CHECK INFO ICON INFORMATION IN ANTERIOR SEGMENT
	public void verifyAntiSegmentInfoDisplayed(String name) {
	
		WebElement hoverElement = driver.findElement(clinicalRecordsLocator.AntiSegmentSummaryInfoIcon); 
		Actions actions = new Actions(driver);
		actions.moveToElement(hoverElement).perform();
		
		WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.AntiSegmentInfoByName(name)));
		
		if (!info.isDisplayed()) {
		   throw new AssertionError("User info is NOT displayed after hover");
		}
		
		System.out.println("Patient info displayed: " + info.getText());
	}    
	
	
	//CLEAR BUTTON IN EXAMINATION
	public void clickClearButtonExamination() {
		  WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.clearBtnExamination));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);
	
	      try {
	      	btn.click();
	      } catch (Exception e) {
	          ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
	      }  
	}
	
	//SAVE BUTTON IN EXAMINATION
	public void clickSaveBtnExamination() {
		WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.saveBtnExamination));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}
	
	//ANTERIOR SEGMENT SUMMARY DELETE ICON
	public void ClickAntiSegmentSummaryDeleteIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.AntiSegmentSummaryDeleteIcon));
	
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}
	
	// SAVE OR UPDATE BUTTONS
	public void clickSaveOrUpdateButton() {
	    
//	    List<WebElement> saveBtn = driver.findElements(clinicalRecordsLocator.saveBtnExamination);
//	    List<WebElement> updateBtn = driver.findElements(clinicalRecordsLocator.updateBtnExamination);
//	
//	    if (!saveBtn.isEmpty() && saveBtn.get(0).isDisplayed()) {
//	        clickSaveBtnExamination();
//	        System.out.println("Clicked Save button");
//	    } 
//	    else if (!updateBtn.isEmpty() && updateBtn.get(0).isDisplayed()) {
//	        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(updateBtn.get(0)));
//	        btn.click();
//	        System.out.println("Clicked Update button");
//	    } 
//	    else {
//	        throw new RuntimeException("Neither Save nor Update button is present");
//	    }
		
		try {
		    WebElement save = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.saveBtnExamination));

		    save.click();
		    System.out.println("Clicked Save button");

		} catch (Exception e) {

		    try {
		        WebElement update = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.updateBtnExamination));

		        update.click();
		        System.out.println("Clicked Update button");

		    } catch (Exception ex) {
		        throw new RuntimeException("Neither Save nor Update button is clickable");
		    }
		}
	}


//FUNDUS 

	//SELECT FUNDUS OPTIONS WITH EYE
	public void selectFundus(String segment, String eye , String option) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectOptionFundus(segment,eye,option)));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}
	
	//SELECT FUNDUS OPTIONS WITHOUT EYE
	public void selectFundusFullOption(String segment, String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectFullOptionFundus(segment,option)));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
	
	//REMARKS FOR FUNDUS
	public void enterRemarksFundus(String eye, String remark) {
		  WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.remarkInputFundus(eye)));  
		  element.sendKeys(remark);
	}


// FUNDUS HISTORY SUMMARY

	//FUNDUS SUMMARY DISPLAYED  
	public void verifyFundusSummaryDisplayed() {
	
		WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.FundusSummary));
		
		if (!summary.isDisplayed()) {
		throw new AssertionError("Fundus summary is NOT displayed");
		}
		
		System.out.println("Fundus summary is displayed");
	} 
	
	//FUNDUS SUMMARY NOT DISPLAYED
	public void verifyFundusSummaryNotDisplayed() {
	
		String text = driver.findElement(clinicalRecordsLocator.FundusSummary).getText();
	
	  if (text.contains("RE:") || text.contains("LE:")) {
	      throw new AssertionError("Fundus data is STILL present");
	  }
	
	  System.out.println("Fundus data is cleared successfully");
	}
	
	//FUNDUS SUMMARY INFO ICON
	public void ClickFundusSummaryInfoIcon() {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.FundusSummaryInfoIcon));
		
		Actions actions = new Actions(driver);
		actions.moveToElement(element)
		      .pause(Duration.ofMillis(300))
		      .click()
		      .perform();
	}
	
	//CHECK INFO ICON INFORMATION IN FUNDUS
	public void verifyFundusInfoDisplayed(String name) {
	
		WebElement hoverElement = driver.findElement(clinicalRecordsLocator.FundusSummaryInfoIcon); 
		Actions actions = new Actions(driver);
		actions.moveToElement(hoverElement).perform();
		
		WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.FundusInfoByName(name)));
		
		if (!info.isDisplayed()) {
		   throw new AssertionError("User info is NOT displayed after hover");
		}
		
		System.out.println("User info displayed: " + info.getText());
	}    
	
	//FUNDUS SUMMARY DELETE ICON
	public void ClickFundusSummaryDeleteIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.FundusSummaryDeleteIcon));
	
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}


//DIAGNOSIS 

	//SELECT EYE AND TYPE OF DIAGNOSIS
	public void selectEyeDignosis(String diagnosis, String eye) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectOptionDiagnosis(diagnosis,eye)));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
	
	      try {
	      	element.click();
	      } catch (Exception e) {
	          ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	      }
	}
	  
	//SELECT DIAGNOSIS NAME
	public void selectDiagnosis(String diagnosis) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectFullOptionDiagnosis(diagnosis)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}    
	
	//OTHER DIAGNOSIS DROPDOWN
	public void selectDiagnosisDropdown(String diagnosis) {
	
	    WebElement input = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectDropdownDiagnosis));
	
	    input.click();
	    input.clear();
	    input.sendKeys(diagnosis);
	    
	    WebElement optionElement = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.optionOtherDiagnosisDropdown(diagnosis)));
	
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", optionElement);
	} 
	
	//REMARKS FOR FUNDUS
	public void enterRemarksDiagnosis(String eye, String remark) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.remarkInputDiagnosis(eye)));
		  element.sendKeys(remark);
	}
	
	// ALERT IN DIAGNOSIS
	public void validateAlertDiagnosis() {
		 WebElement msg = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.AlertMsgDiagosis));
		 System.out.println("Alert: " + msg.getText());
		
		 if (!msg.isDisplayed()) {
		     throw new AssertionError("Not allowed alert not displayed");
		 }
	}

//DIAGNOSIS HISTORY SUMMARY

	//DIAGNOSIS SUMMARY DISPLAYED  
	public void verifyDiagnosisSummaryDisplayed() {
	
		WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.DiagnosisSummary));
		
		if (!summary.isDisplayed()) {
		throw new AssertionError("Diagnosis summary is NOT displayed");
		}
		
		System.out.println("Diagnosis summary is displayed");
	} 
	
	//DIAGNOSIS SUMMARY NOT DISPLAYED
	public void verifyDiagnosisSummaryNotDisplayed() {
	
		String text = driver.findElement(clinicalRecordsLocator.DiagnosisSummary).getText();
	
		if (text.contains("RE:") || text.contains("LE:")) {
		   throw new AssertionError("Diagnosis data is STILL present");
		}
		
		System.out.println("Diagnosis data is cleared successfully");
	}
	
	//DIAGNOSIS SUMMARY INFO ICON
	public void ClickDiagnosisSummaryInfoIcon() {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.DiagnosisSummaryInfoIcon));
		
		Actions actions = new Actions(driver);
		actions.moveToElement(element)
		      .pause(Duration.ofMillis(300))
		      .click()
		      .perform();
	}
	
	//CHECK INFO ICON INFORMATION IN DIAGNOSIS
	public void verifyDiagnosisInfoDisplayed(String name) {
	
		WebElement hoverElement = driver.findElement(clinicalRecordsLocator.DiagnosisSummaryInfoIcon); 
		Actions actions = new Actions(driver);
		actions.moveToElement(hoverElement).perform();
		
		WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.DiagnosisInfoByName(name)));
		
		if (!info.isDisplayed()) {
		   throw new AssertionError("User info is NOT displayed after hover");
		}
		
		System.out.println("User info displayed: " + info.getText());
	}    
	
	//DIAGNOSIS SUMMARY DELETE ICON
	public void ClickDiagnosisSummaryDeleteIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DiagnosisSummaryDeleteIcon));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}
	
	//OTHER DIAGNOSIS EYE TYPE
	public void ClickOtherDiagnosisEyeType(String eye) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.otherDiagnosisEyeType(eye)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
		 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}
	
	
// ADVICE


//  REFERRAL ADVICE MODULE
    
	//HOSPITAL DROPDOWN   
	  public void selectHospitalDropdown(String option) {
	      WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.hospitalInput));
	      element.click();    
	      WebElement eventOrgName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.hosInput));
	      eventOrgName.sendKeys(option);
	      eventOrgName.sendKeys(Keys.ENTER);
	  }
	  
	//CLINIC DROPDOWN   
	public void selectclinicDropdown(String option) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.clinicInput));
	    element.click();    
	    WebElement eventOrgName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.cliInput));
	    eventOrgName.sendKeys(option);
	    eventOrgName.sendKeys(Keys.ENTER);
	}    
	  
	//REASON FOR REFERRAL DROPDOWN   
	public void selectReasonRefDropdown(String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.reasonInput));
		  element.click();    
		  WebElement reasonRefName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.reasonRefInput));
		  reasonRefName.sendKeys(option);
		  reasonRefName.sendKeys(Keys.ENTER);
	}   
	     
	//SAVE BUTTON IN REFERRAL     
	public void clickSaveRefBtn() {
		WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.saveRefBtn));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn);
		wait.until(ExpectedConditions.elementToBeClickable(saveBtn)).click();
	}  

//REFERRAL ADVICE SUMMARY
	
	//REFERRAL ADVICE SUMMARY DISPLAYED  
	public void verifyReferralSummaryDisplayed() {
		  WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.ReferralSummary));
		  if (!summary.isDisplayed()) {
		      throw new AssertionError("Referral summary is NOT displayed");
		  }
		  System.out.println("Referral summary is displayed");
	} 
	
	//REFERRAL ADVICE SUMMARY NOT DISPLAYED
	public void verifyReferralSummaryNotDisplayed() {
		  boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.ReferralSummary));
		  if (!isNotVisible) {
		      throw new AssertionError("Referral summary is STILL displayed");
		  }
		  System.out.println("Referral summary is NOT displayed");
	}
	  
	//REFERRAL ADVICE SUMMARY DELETE ICON
	public void ClickReferralSummaryDeleteIcon() {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ReferralSummaryDeleteIcon));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
	
	//REFERRAL ADVICE SUMMARY PRINT ICON
	public void ClickReferralSummaryPrintIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ReferralSummaryPrintIcon));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
	  
	//REFERRAL ADVICE SUMMARY INFO ICON
	public void ClickReferralSummaryInfoIcon() {
		 Actions actions = new Actions(driver);
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ReferralSummaryInfoIcon));
		 actions.moveToElement(element).perform();
	} 
	
	//CHECK INFO ICON INFORMATION
	public void verifyPatientInfoDisplayed(String name) {
		  WebElement hoverElement = driver.findElement(clinicalRecordsLocator.ReferralSummaryInfoIcon); 
		  Actions actions = new Actions(driver);
		  actions.moveToElement(hoverElement).perform();
		  
		  WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.patientInfoByName(name)));
		  if (!info.isDisplayed()) {
		      throw new AssertionError("User info is NOT displayed after hover");
		  }
		
		  System.out.println("User info displayed: " + info.getText());
	}    
  
  
// DRUG PRESCRIPTION (DP) ADVICE
	
	//SELECT EYE AND TYPE OF DRUG
	public void selectEyeDrug(String drug, String eye) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectOptionDrug(drug,eye)));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
	
	      try {
	      	element.click();
	      } catch (Exception e) {
	          ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	      }
	}
		  
	//SELECT DRUG NAME
	public void selectDrug(String drug) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectFullOptionDrug(drug)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}   
	
	//SELECT EYE TYPE 
	public void selectEyeTypeDP(String drug) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectEyeType));
		 Select select = new Select(element);
		 select.selectByVisibleText(drug);
	}

	//DRUG NAME DROPDOWN   
	public void selectDrugNameDP(String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.drugNameDropdown));
		  element.click();    
		  WebElement DrugName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.drugNameDropdownInput));
		  DrugName.sendKeys(option);
		  DrugName.sendKeys(Keys.ENTER);
	}  

	//SELECT FREQUENCY DROPDOWN
	public void selectFrequencyDropDP(String frequency) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectFrequency));
		 Select select = new Select(element);
		 select.selectByVisibleText(frequency);
	}

	// DURATION INPUT
	public void enterDurationDP(String duration) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.DurationInputDP));
		 element.sendKeys(duration);
	}

	//SELECT DURATION TYPE DROPDOWN
	public void selectDurationTypeDP(String type) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectDurationType));
		 Select select = new Select(element); 
		 select.selectByVisibleText(type);
	}

	//REMARKS INPUT
	public void enterRemarkDP(String remark) {
		 WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.enterRemarksDP));
		 element.sendKeys(remark);
	}
	
	//SELECT PRESCRIPTION LANGUAGE DROPDOWN
	public void selectPresLanguageDP(String language) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectPresLanguage));
		 Select select = new Select(element);
		 select.selectByVisibleText(language);
	}

	//BUTTON ACTIONS IN DP
	public void buttonActionsDP(String btn) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DPButtons(btn)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}

// DRUG PRESCRIPTION (DP) ADVICE SUMMARY
	
	//DP ADVICE SUMMARY DISPLAYED  
	public void verifyDPSummaryDisplayed() {
		  WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.DPSummary));
		  if (!summary.isDisplayed()) {
		      throw new AssertionError("DP summary is NOT displayed");
		  }
		  System.out.println("DP summary is displayed");
	} 
	
	//DP ADVICE SUMMARY NOT DISPLAYED
	public void verifyDPSummaryNotDisplayed() {
		  boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.DPSummary));
		  if (!isNotVisible) {
		      throw new AssertionError("DP summary is STILL displayed");
		  }
		  System.out.println("DP summary is NOT displayed");
	}
	  
	//DP ADVICE SUMMARY DELETE ICON
	public void ClickDPSummaryDeleteIcon() {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DPSummaryDeleteIcon));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
	
	//DP ADVICE SUMMARY PRINT ICON
	public void ClickDPSummaryPrintIcon() {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DPSummaryPrintIcon));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
	  
	//DP ADVICE SUMMARY INFO ICON
	public void ClickDPSummaryInfoIcon() {
		 Actions actions = new Actions(driver);
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.DPSummaryInfoIcon));
		 actions.moveToElement(element).perform();
	}

	//CHECK INFO ICON INFORMATION
	public void verifyPatientInfoDisplayedDP(String name) {
		  WebElement hoverElement = driver.findElement(clinicalRecordsLocator.DPSummaryInfoIcon); 
		  Actions actions = new Actions(driver);
		  actions.moveToElement(hoverElement).perform();
		  
		  WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.patientInfoByNameDP(name)));
		  if (!info.isDisplayed()) {
		      throw new AssertionError("User info is NOT displayed after hover");
		  }
		
		  System.out.println("User info displayed: " + info.getText());
	}   


// SURGERY ADVICE
	
	//SELECT LABEL WITH OPTIONS
	public void selectEyeSurgery(String label, String eye) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectEyeTypeSurgery(label,eye)));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}

	//OTHER SURGERY DROPDOWN   
	public void selectSurgeryDropdown(String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.surgeryNameDropdown));
		  element.click();    
		  WebElement SurgeryName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.surgeryNameDropdownInput));
		  SurgeryName.sendKeys(option);
		  SurgeryName.sendKeys(Keys.ENTER);
	}
	
	//REMARKS
	public void enterRemarkSurgery(String remark) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.remarkInputSurgery));
		  element.sendKeys(remark);
	}

	// SURGERY DATE
	public void enterSurgeryDate(String date) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dateInputSurgery));
		  element.clear();
		  element.sendKeys(date);
	}

	// SURGERY NOT CONFIRMED REASON DROPDOWN   
	public void selectSurgeryReasonDropdown(String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.surgeryReasonDropdown));
		  element.click();    
		  WebElement SurgeryReason = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.surgeryReasonDropdownInput));
		  SurgeryReason.sendKeys(option);
		  SurgeryReason.sendKeys(Keys.ENTER);
	}

	//BUTTON ACTIONS IN SURGERY
	public void buttonActionsSurgery(String btn) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.SurgeryButtons(btn)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
	
	//BUTTON ACTIONS IN SURGERY
	public void buttonActionsSurgeryCounselling(String btn) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.SurgeryCounsellingButtons(btn)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}

// SURGERY ADVICE SUMMARY
	
	//LINK ACTIONS IN SURGERY
	public void linkActionsSurgery(String link) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.CounsellingLink(link)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
		
	//SURGERY ADVICE SUMMARY DISPLAYED  
	public void verifySurgerySummaryDisplayed() {
		  WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.SurgerySummary));
		  if (!summary.isDisplayed()) {
		      throw new AssertionError("Surgery advice summary is NOT displayed");
		  }
		  System.out.println("Surgery advice summary is displayed");
	} 
	
	//SURGERY ADVICE SUMMARY NOT DISPLAYED
	public void verifySurgerySummaryNotDisplayed() {
		  boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.SurgerySummary));
		  if (!isNotVisible) {
		      throw new AssertionError("Surgery advice summary is STILL displayed");
		  }
		  System.out.println("Surgery advice summary is NOT displayed");
	}
	  
	//SURGERY ADVICE SUMMARY DELETE ICON
	public void ClickSurgerySummaryDeleteIcon() {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.SurgerySummaryDeleteIcon));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}

	//SURGERY ADVICE SUMMARY INFO ICON
	public void ClickSurgerySummaryInfoIcon() {
		 Actions actions = new Actions(driver);
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.SurgerySummaryInfoIcon));
		 actions.moveToElement(element).perform();
	}

	//CHECK INFO ICON INFORMATION
	public void verifyPatientInfoDisplayedSurgery(String name) {
		  WebElement hoverElement = driver.findElement(clinicalRecordsLocator.SurgerySummaryInfoIcon); 
		  Actions actions = new Actions(driver);
		  actions.moveToElement(hoverElement).perform();
		  
		  WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.patientInfoByNameSurgery(name)));
		  if (!info.isDisplayed()) {
		      throw new AssertionError("User info is NOT displayed after hover");
		  }
		
		  System.out.println("User info displayed: " + info.getText());
	}   


// REFRACTION

	
	//OPTIONS SELECTION IN REFRACTION
	public void ClickOptionsRefraction(String btn) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.refractionOption(btn)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}

	//SELECT OPTIONS WITH LABEL
	public void selectLabelOptionRefraction(String label, String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectLabelOptions(label,option)));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}

	// SELECT DROPDOWN AND OPTION WITH LABEL NAME (NG-SELECT)
	public void clickDropdownCS1(String labelName,String option) {
		WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dropdownByLabelCS1(labelName)));
		dropdown.click();      
	    WebElement optionElement = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.dropdownOptionCS1(option)));
	    optionElement.click();
	    closeOpenDropdown();
//	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ngselectDropdownCS1));
//	    element.click();
	}
	
	// ENTER DETAILS INPUT WITH LABEL NAME	
	public void enterDetailsInputCS1(String labelName, String text) {
	    WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.inputFieldByLabel(labelName)));
	    input.clear();
	    input.sendKeys(text);
	}
	
	// BUTTON ACTIONS IN REFRACTION
	public void ClickBtnRefraction(String btn) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.RefractionButtons(btn)));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}

// CURRENT SPECTACLES(1)
	
	//DURATION FIELD
	public void clickDurationRefraction() {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationFieldRefraction));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}
	
	//DURATION SETTING WITH VALUES (0-9)
	public void setDurationValueRefraction(String value) {
	
	    for (char digit : value.toCharArray()) {
	
	        String num = String.valueOf(digit);
	        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationValueRefraction(num)));
	        btn.click();
	        try {
	            Thread.sleep(200);  
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	}
	
	// DURATION TYPE
	public void setDurationTypeRefraction(String type) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationTypeRefraction(type)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }   
	}
	
	//DURATION BUTTONS
	public void setDurationBtnRefraction(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.durationBtnRefraction(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}

	// SELECT LABEL AND DROPDOWN (SELECT)
	public void clickSelectDropdownCS1(String labelName, String option) {
	    WebElement dropdown = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.dropdownBySelectLabelCS1(labelName)));

	    Select select = new Select(dropdown);
	    select.selectByVisibleText(option);
	}

	// SELECT CONTAINS TWO LABELS AND DROPDOWN (SELECT)
	public void clickSelectTwoLabelsDropdownCS1(String parentLabel, String childLabel, String value) {

	    WebElement dropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.dropdownByTwoLabels(parentLabel, childLabel)));

	    Select select = new Select(dropdown);
	    try {
	        select.selectByVisibleText(value);
	    } catch (Exception e) {
	        for (WebElement opt : select.getOptions()) {
	            if (opt.getText().trim().equalsIgnoreCase(value.trim())) {
	                opt.click();
	                break;
	            }
	        }
	    }
	}

	// ENTER DETAILS INPUT WITH TWO LABELS 	
	public void enterDetailsTwoLabelsInputCS1(String parentLabel,String childLabel,String value) {
	    WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.inputFieldTwoLabels(parentLabel,childLabel)));
	    input.click();
	    input.clear();
	    input.sendKeys(value);
	}

	// SELECT DROPDOWN AND OPTION WITH TWO LABELS NAME (NG-SELECT)
	public void clickTwoLabelsNG_select_DropdownCS1(String parentLabel,String childLabel,String value) {
		WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dropdownTwoLabelsNGSelectCS1(parentLabel,childLabel)));
		dropdown.click();      
	    WebElement optionElement = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.dropdownTwoLabelsOptionCS1(value)));
	    optionElement.click();
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ngselectDropdownTwoTablesCS1));
	    element.click();
	}

    // SELECT REFRACTION VALUES
	
	public void selectRefractionValue(String value, String eye, String column) {

		WebElement eyeSection =wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.eyeRow(eye)));
	    
		//UCNV
		if (column.equalsIgnoreCase("UCNV")) {

			WebElement field = eyeSection.findElement(clinicalRecordsLocator.ucnvDropdown());
	    	wait.until(ExpectedConditions.elementToBeClickable(field));	      
	        new Select(field).selectByVisibleText(value);
	        
	        closeOpenDropdown();
	        return;
		}
		
		// VISION
		if (column.equalsIgnoreCase("Vision")) {
		    
		    WebElement field = eyeSection.findElement(clinicalRecordsLocator.visionDropdown());
	    	wait.until(ExpectedConditions.elementToBeClickable(field));	      
	        new Select(field).selectByVisibleText(value);
	        
		    closeOpenDropdown();
		    return;
		}
		
		//DISTANCE
		if (column.equalsIgnoreCase("Distance")) {

		    WebElement dropdown;
		    if (value.matches("\\d+")) {
		        dropdown = eyeSection.findElement(clinicalRecordsLocator.distanceOneDropdown());
		    }
		    else {
		        dropdown = eyeSection.findElement(clinicalRecordsLocator.distanceTwoDropdown());
		    }
		    wait.until(ExpectedConditions.elementToBeClickable(dropdown));
		    new Select(dropdown).selectByVisibleText(value);

		    closeOpenDropdown();
		    return;
		}
		
		// INTERMIDIATE SPHERICAL
		if (column.equalsIgnoreCase("Intermediate Spherical")) {

		    WebElement dropdown = eyeSection.findElement(clinicalRecordsLocator.intermediateSphericalDropdown());

		    wait.until(ExpectedConditions.elementToBeClickable(dropdown));
		    new Select(dropdown).selectByVisibleText(value);

		    closeOpenDropdown();
		    return;
		}
		
		//LOGMAR
		if (column.equalsIgnoreCase("LogMAR")) {
		    WebElement field = eyeSection.findElement(clinicalRecordsLocator.logmarDropdown());
	    	wait.until(ExpectedConditions.elementToBeClickable(field));	      
	        new Select(field).selectByVisibleText(value);

		    closeOpenDropdown();
		    return;
		}
		
		//SNELLEN EQU
		if (column.equalsIgnoreCase("Snellen Equ")) {
		    WebElement field = eyeSection.findElement(clinicalRecordsLocator.snellenDropdown());
	    	wait.until(ExpectedConditions.elementToBeClickable(field));	      
	        new Select(field).selectByVisibleText(value);

		    closeOpenDropdown();
		    return;
		}
		
		// NEAR PD
		if (column.equalsIgnoreCase("Near PD")) {

		    WebElement input = eyeSection.findElement(clinicalRecordsLocator.nearPdInput(eye));
		    wait.until(ExpectedConditions.elementToBeClickable(input));

		    input.click();
		    input.clear();
		    input.sendKeys(value);
	      
	        closeOpenDropdown();
	        return;
		}
		
		// UCVA
		if (column.equalsIgnoreCase("UCVA")) {
	        selectUCVADrop(eyeSection,eye, value);
	        return;
	    }

		//BCVA
	    if (column.equalsIgnoreCase("BCVA")) {
	        selectBCVA(eyeSection,eye, value);
	        return;
	    }

	    // PH BCVA
	    if (column.equalsIgnoreCase("PH BCVA")) {
	        selectPHBCVA(eyeSection,eye, value);
	        return;
	    }
	    
	    // MPD
	    if (column.equalsIgnoreCase("MPD")) {
	    	WebElement mpd = eyeSection.findElement(clinicalRecordsLocator.mpdInput(eye));
	    	wait.until(ExpectedConditions.elementToBeClickable(mpd));
	        mpd.click();
	        mpd.clear();
	        mpd.sendKeys(value);

	        closeOpenDropdown();
	        return;
	    }
	    
	    // DIOPTER 90's
	    if (column.equalsIgnoreCase("Diopter Values (90's)")) {

	        // SIMPLE VALUE
	        if (!value.startsWith("+") && !value.startsWith("-")) {

	            WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.diopter90Dropdown));

	            new Select(dropdown).selectByVisibleText(value);
	            closeOpenDropdown();
	            return;
	        }

	        // SIGNED VALUE
	        handleSignedValue(eyeSection,value, "90");
	        return;
	    }

	    // DIOPTER 180's 
	    if (column.equalsIgnoreCase("Diopter Values (180's)")) {

	        // FIRST FIELD
	        if (!value.contains("+") && !value.contains("-") && !value.contains(".")) {

	            WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.diopter180Dropdown(eye)));

	            new Select(dropdown).selectByVisibleText(value);
	            closeOpenDropdown();
	            return;
	        }

	        String sign = value.startsWith("-") ? "-" : "+";
	        String number = value.replace("+", "").replace("-", "");

	        String[] parts = number.split("\\.");
	        String integer = parts[0];
	        String decimal = parts.length > 1 ? "0." + parts[1] : "";

	        // INTEGER
	        if (!integer.equals("0")) {
	            WebElement intDrop = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.diopter180Integer(eye)));
	            new Select(intDrop).selectByVisibleText(integer);
	        }

	        // DECIMAL
	        if (!decimal.isEmpty()) {
	            WebElement decDrop = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.diopter180Decimal(eye)));
	            new Select(decDrop).selectByVisibleText(decimal);
	        }

	        // SIGN
	        WebElement label = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.diopter180Sign(eye, sign)));

	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", label);
	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", label);

	        closeOpenDropdown();
	        return;
	    }

	    // REFLEX 
	    if (column.equalsIgnoreCase("Reflex") || column.equalsIgnoreCase("Type of Reflex")) {

	    	WebElement dropdown = eyeSection.findElement(clinicalRecordsLocator.reflexDropdown(eye));
	    	wait.until(ExpectedConditions.elementToBeClickable(dropdown));
	        new Select(dropdown).selectByVisibleText(value);
	        
	        closeOpenDropdown();
	        return;
	    }

	    // AXIS 
	    if (column.equalsIgnoreCase("Axis")) {

	    	WebElement axis = eyeSection.findElement(clinicalRecordsLocator.axisDropdown(eye));
	    	wait.until(ExpectedConditions.elementToBeClickable(axis));	      
	        new Select(axis).selectByVisibleText(value);
	        
	        closeOpenDropdown();
	        return;
	    }

	    // NV
	    if (column.equalsIgnoreCase("NV")) {

	    	WebElement nv = eyeSection.findElement(clinicalRecordsLocator.nvDropdown(eye));
	    	wait.until(ExpectedConditions.elementToBeClickable(nv));
	        new Select(nv).selectByVisibleText(value);
	        
	        closeOpenDropdown();
	        return;
	    }
	    
	    // V/A WITH CS 
	    if (column.equalsIgnoreCase("V/A with CS")) {
	        selectVA(eye, value);
	        return;
	    }

	    // +SPHERICAL 
	    if (column.equalsIgnoreCase("+Spherical")) {

	        String[] parts = value.split("\\.");
	        String integer = parts[0];
	        String decimal = parts.length > 1 ? "0." + parts[1] : "";

	        WebElement intDrop = eyeSection.findElement(clinicalRecordsLocator.nvSphInteger(eye));
	        wait.until(ExpectedConditions.elementToBeClickable(intDrop));
	        new Select(intDrop).selectByVisibleText(integer);

	        if (!decimal.isEmpty()) {
	            WebElement decDrop = eyeSection.findElement(clinicalRecordsLocator.nvSphDecimal(eye));
		        wait.until(ExpectedConditions.elementToBeClickable(decDrop));
	            new Select(decDrop).selectByVisibleText(decimal);
	        }

	        closeOpenDropdown();
	        return;
	    }

	    // SPHERICAL / CYLINDER
	    if (column.equalsIgnoreCase("Spherical") || column.equalsIgnoreCase("Cylinder")) {

	        // CHECK FIELD HAVE SIGN 
	        boolean hasSign = !eyeSection.findElements(
	            clinicalRecordsLocator.signBtn(eye, column, "+")
	        ).isEmpty();

	       // WITH SIGN
	        if (hasSign) {

	            String sign = value.startsWith("-") ? "-" : "+";
	            String number = value.replace("+", "").replace("-", "");

	            String[] parts = number.split("\\.");
	            String integer = parts[0];
	            String decimal = parts.length > 1 ? "0." + parts[1] : "";

	            WebElement signLabel = eyeSection.findElement(clinicalRecordsLocator.signBtn(eye, column, sign));

	            String forValue = signLabel.getAttribute("for");
	            WebElement input = driver.findElement(By.id(forValue));

	            ((JavascriptExecutor) driver).executeScript("arguments[0].removeAttribute('disabled')", input);
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", input);

	            if (!integer.equals("0")) {
	                WebElement intDrop = eyeSection.findElement(clinicalRecordsLocator.integerDropdown(eye, column));
	                wait.until(ExpectedConditions.elementToBeClickable(intDrop));
	                new Select(intDrop).selectByVisibleText(integer);
	            }

	            if (!decimal.isEmpty()) {
	                WebElement decDrop = eyeSection.findElement(clinicalRecordsLocator.decimalDropdown(eye, column));
	                wait.until(ExpectedConditions.elementToBeClickable(decDrop));
	                new Select(decDrop).selectByVisibleText(decimal);
	            }
	        }

	       // WITHOUT SIGN
	        else {

	            WebElement dropdown = eyeSection.findElement(clinicalRecordsLocator.sphericalDropdown() );

	            wait.until(ExpectedConditions.elementToBeClickable(dropdown));
	            new Select(dropdown).selectByVisibleText(value);
	        }

	        closeOpenDropdown();
	        return;
	    }
	    
	}
	
	
	public void selectUCVADrop(WebElement eyeSection, String eye, String value) {

	    boolean hasP = value.contains("P");
	    String cleanValue = value.replace("P", "").trim();

	    WebElement dropdown = eyeSection.findElement(clinicalRecordsLocator.ucvaDropdown(eye));
	    wait.until(ExpectedConditions.visibilityOf(dropdown));

	    Select select = new Select(dropdown);
	    select.selectByVisibleText(cleanValue);

	    if (hasP) {
	        WebElement pSign = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ucvaPsign()));
	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", pSign);
	    }

	    closeOpenDropdown();
	}
	
	public void selectBCVA(WebElement eyeSection, String eye, String value) {

	    boolean hasP = value.contains("P");
	    String cleanValue = value.replace("P", "").trim();

	    WebElement dropdown = eyeSection.findElement(clinicalRecordsLocator.bcvaDropdown(eye));
	    wait.until(ExpectedConditions.elementToBeClickable(dropdown));

	    Select select = new Select(dropdown);
	    select.selectByVisibleText(cleanValue);

	    ((JavascriptExecutor) driver).executeScript("arguments[0].dispatchEvent(new Event('change', { bubbles: true }))",dropdown);

	    if (hasP) {
	        WebElement pSign = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.bcvaPsign()));
	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", pSign);
	    }

	    closeOpenDropdown();
	}
	
	public void selectPHBCVA(WebElement eyeSection,String eye, String value) {

	    boolean hasP = value.contains("P");
	    String cleanValue = value.replace("P", "").trim();

	    WebElement dropdown = eyeSection.findElement(clinicalRecordsLocator.phBcvaDropdown(eye));
	    wait.until(ExpectedConditions.elementToBeClickable(dropdown));

	    Select select = new Select(dropdown);
	    select.selectByVisibleText(cleanValue);
	    ((JavascriptExecutor) driver).executeScript("arguments[0].dispatchEvent(new Event('change', { bubbles: true }))",dropdown);

	    if (hasP) {

	        WebElement pSign = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.phBcvaPsign()));
	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", pSign);
	    }

	    closeOpenDropdown();
	}
	
	public void handleSignedValue(WebElement eyeSection, String value, String type) {

	    String sign = value.startsWith("-") ? "-" : "+";
	    String number = value.replace("+", "").replace("-", "");

	    String[] parts = number.split("\\.");
	    String integer = parts[0];
	    String decimal = parts.length > 1 ? "0." + parts[1] : "";
	    
	    // SIGN CLICK
	    WebElement label = eyeSection.findElement(clinicalRecordsLocator.diopterSign(type, sign));

	    String forValue = label.getAttribute("for");
	    WebElement input = driver.findElement(By.id(forValue));

	    ((JavascriptExecutor) driver).executeScript("arguments[0].removeAttribute('disabled')", input);
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", input);
	    
	    // INTEGER → SKIP IF 0
	    if (!integer.equals("0")) {

	        WebElement intDrop = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.diopterInteger(type)));
	        new Select(intDrop).selectByVisibleText(integer);
	    }

	    // DECIMAL
	    if (!decimal.isEmpty()) {

	        WebElement decDrop = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.diopterDecimal(type)));
	        new Select(decDrop).selectByVisibleText(decimal);
	    }

	    closeOpenDropdown();
	}
	
	// V/A with CS SIGN (P) 
	public void selectVA(String eye, String value) {

	    if (value.contains("P")) {
	        clickPButton(eye);
	        value = value.replace("P", "").trim();
	    }
	    WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.vaDropdown(eye)));
	    new Select(dropdown).selectByVisibleText(value);
	    closeOpenDropdown(); 
	}
	
	//"P" LABEL CLICK INSIDE REFRACTION 
	public void clickPButton(String eye) {

	    WebElement label = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.vaPButton(eye)));
	    String forVal = label.getAttribute("for");
	    WebElement input = driver.findElement(By.id(forVal));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].removeAttribute('disabled')", input);
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", input);
	}
	
	// DROPDOWN CLOSE AND OPEN
	public void closeOpenDropdown() {

	    ((JavascriptExecutor) driver).executeScript("document.body.click();");
	    new Actions(driver).sendKeys(Keys.ESCAPE).perform();
	}
	
	// CHANGE THE EYE LABEL RE or LE
	public void moveToEyeSection(String eye) {
	    By eyeLocator = By.xpath("//span[normalize-space()='" + eye + "']");
	    WebElement eyeRow = wait.until(ExpectedConditions.visibilityOfElementLocated(eyeLocator));
	    
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", eyeRow);
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", eyeRow);

	    try {
	        Thread.sleep(500);
	    } catch (InterruptedException e) {}

	}
	
	// ENTER REMARKS	
	public void enterRemarkRefraction(String remark) {
	    WebElement remarkInput = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.inputRemarksRefraction));
	    remarkInput.click();
	    remarkInput.clear();
	    remarkInput.sendKeys(remark);
	}
	
	// ERROR MESSEGE DISPLAY
	public void verifyMandatoryError(String msg) {

	    WebElement error = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.mandatoryErrorMsg(msg)));

	    if (!error.isDisplayed()) {
	        throw new AssertionError("Error message is NOT displayed");
	    }
	}

	// BUTTON ACTIONS CURRENT SPECTACLES(1)
	public void ClickBtnCurrentSpecPart1(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BtnCurrentSpecPart1(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        } 
	}
	
	// SUMMARY DISPLAY
	public void validateCurrentSpecPartOneSummaryDisplay() {

	    WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.currentSpecPartOneSummaryDisplay));

		  if (!summary.isDisplayed()) {
		      throw new AssertionError("Summary is NOT displayed");
		  }
		  System.out.println("Summary is displayed");
	}
	
	//UNDILATED RR
	
	// DYNAMIC RR
	
	// BUTTON ACTIONS DYNAMIC RR
	public void ClickBtnDynamicRR(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BtnDynamicRR(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        } 
	}
	
	// SUMMARY DISPLAY
	public void validateUndilatedRRSummaryDisplay() {

	    WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.undilatedRRSummaryDisplay));
		  if (!summary.isDisplayed()) {
		      throw new AssertionError("Summary is NOT displayed");
		  }
		  System.out.println("Summary is displayed");
	}
	
	// SUB OPTIONS SELECTION IN REFRACTION
	public void ClickSubOptionUndilatedRR(String btn) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.subOptionUndilatedRR(btn)));
		 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
	
	// ENTER DETAILS INPUT WITH LABEL NAME UNDILATED RR
	public void enterDetailsInputUndilatedRR(String labelName, String text) {
	    WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.inputFieldByLabelUndialatedRR(labelName)));
	    input.clear();
	    input.sendKeys(text);
	}
	
	//SELECT OPTIONS WITH LABEL
//	public void selectLabelOptionDilated(String label, String option) {
//		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectLabelOptionsDilated(label,option)));
//		  element.click();
//	}
	
	// SUB RR DV
	
	// BUTTON ACTIONS SUB RR DV
	public void ClickBtnSubRR(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BtnSubRRDV(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}

	// ONE LABEL ONE INPUT
	public void enterDetailsInput(String labelName, String value) {

	    WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.OthersInput(labelName)));
	    input.clear();
	    input.sendKeys(value);  
	}
	
	// SELECT LABEL AND OPTION DROPDOWN
	public void selectLabelOptionSubRRDV(String labelName, String option) {

	    WebElement dropdown = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.dropdownBySelectLabelSubRRDV(labelName)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", dropdown);
	    wait.until(ExpectedConditions.visibilityOf(dropdown));
	    try { Thread.sleep(500); } catch (Exception e) {}
	    Select select = new Select(dropdown);
	    select.selectByVisibleText(option);
	}
	
	
	// SUB RR NV
	
	// BUTTON ACTIONS SUB RR NV
	public void ClickBtnSubRRNV(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BtnSubRRVV(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}
	
	// ADDITIONAL INFO
	
	// BUTTON ACTIONS 
	public void ClickBtnAddInfo(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BtnAddInfo(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}	
	
	// SELECT LABEL AND DROPDOWN (SELECT) IN ADD INFO
	public void clickSelectDropdownAddInfo(String labelName, String option) {
	    WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dropdownBySelectLabelAddInfo(labelName)));

	    Select select = new Select(dropdown);
	    select.selectByVisibleText(option);
	}
	
	// SELECT DROPDOWN AND OPTION WITH LABEL NAME (NG-SELECT)
	public void clickNgSelectDropdown(String labelName,String option) {
		WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.dropdownByLabelAddInfo(labelName)));
		dropdown.click();      
	    WebElement optionElement = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.dropdownOptionAddInfo()));
	    optionElement.sendKeys(option);
	    optionElement.sendKeys(Keys.ENTER);
	    closeOpenDropdown();
	}
	
	public void enterOtherInputField(String labelName,String value) {
		WebElement input = wait.until(ExpectedConditions.elementToBeClickable( clinicalRecordsLocator.enterOthersInput(labelName)));

			input.click();
			input.clear();
			input.sendKeys(value);
	}
	
	// SUMMARY DISPLAY
	public void validateAdditionalInfoSummaryDisplay() {

	    WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.additionalInfoSummaryDisplay));

		  if (!summary.isDisplayed()) {
		      throw new AssertionError("Summary is NOT displayed");
		  }
		  System.out.println("Summary is displayed");
	}
		
		
	// DILATED
	
	// BUTTON ACTIONS 
	public void ClickBtnDilated(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BtnDilated(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}
	
	// SELECT LABEL AND DROPDOWN (SELECT) IN ADD INFO
	public void selectLabelOptionDilated(String labelName, String option) {

	    WebElement dropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.selectLabelOptionsDilated(labelName)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dropdown);
	    Select select = new Select(dropdown);
	    select.selectByVisibleText(option);
	}
	
	// GLASS PRESCRIPTION
	
	// BUTTON ACTIONS 
	public void ClickBtnGlassPrescription(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BtnGlassPres(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}
	
	// SUMMARY DISPLAY
	public void validateGlassPresSummaryDisplay() {

	    WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.glassPrescriptionSummaryDisplay));
		  if (!summary.isDisplayed()) {
		      throw new AssertionError("Summary is NOT displayed");
		  }
		  System.out.println("Summary is displayed");
	}
	
	//INSIDE LABEL BTN
	public void selectRRTypeOption(String optionName) {

	    WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.selectRRType(optionName)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
	    wait.until(ExpectedConditions.elementToBeClickable(element));
	    try {
	        element.click(); 
	    } catch (Exception e) {
	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	    }
	}
	
	// LENS TYPE SELECTION
	public void selectLensTypeOption(String lensType) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.lensTypeOption(lensType)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        try {
        	element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
	}
	
	// SELECT LABEL AND DROPDOWN (SELECT) REMARKS REFRACTION GP
	public void selectLabelOptionRemarksGPRef(String labelName, String option) {
	    WebElement dropdown = wait.until(ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.dropdownBySelectLabelRemarksGPRef(labelName)));

	    Select select = new Select(dropdown);
	    select.selectByVisibleText(option);
	}
	
	// ONE LABEL ONE INPUT REMARKS REFRACTION GP
	public void enterRemarksInputGPRef(String labelName, String value) {

	    WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.OthersInputGPRefRemarks(labelName)));
	    input.clear();
	    input.sendKeys(value);  
	}

	// REFRACTION SUMMARY DISPLAY 
	public void validateRefractionSummaryDisplay() {

	    WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.refractionSummaryDisplay));

		  if (!summary.isDisplayed()) {
		      throw new AssertionError("Summary is NOT displayed");
		  }
		  System.out.println("Summary is displayed");
	}
	
	// ENTER DETAILS INPUT WITH TWO LABELS REPEAT
	public void enterDetailsTwoLabelsInputRepeat(String parentLabel,String childLabel,String value) {
	    WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.inputFieldTwoLabelsRepeat(parentLabel,childLabel)));
	    input.click();
	    input.clear();
	    input.sendKeys(value);
	}
	
	public void selectDropdownValue(String label, String option) {


	    WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectDropdownByLabel(label)));
	    Select select = new Select(dropdown);

	    if (label.equalsIgnoreCase("Tint type")) {
	        wait.until(d -> select.getOptions().size() > 1);
	    }

	    for (WebElement opt : select.getOptions()) {
	        if (opt.getText().trim().contains(option)) {
	            opt.click();
	            return;
	        }
	    }

	    throw new RuntimeException("Option not found: " + option);
	}

//GP ---> GLASS PRESCRIPTION
	
	//SELECT OPTIONS WITH LABEL GP
	public void selectLabelOptionsGP(String label, String option) {
		  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectLabelOptionGP(label,option)));
		  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

	        try {
	        	element.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	        }
	}
	
	// BUTTON ACTIONS 
	public void ClickBtnGPModule(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BtnGPModule(button)));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

        try {
        	btn.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
        }  
	}
	
// GLASS PRESCRIPTION (GP) ADVICE SUMMARY
	
		//GP ADVICE SUMMARY DISPLAYED  
		public void verifyGPSummaryDisplayed() {
			  WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.GPSummary));
			  if (!summary.isDisplayed()) {
			      throw new AssertionError("GP summary is NOT displayed");
			  }
			  System.out.println("GP summary is displayed");
		} 
		
		//GP ADVICE SUMMARY NOT DISPLAYED
		public void verifyGPSummaryNotDisplayed() {
			  boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.GPSummary));
			  if (!isNotVisible) {
			      throw new AssertionError("GP summary is STILL displayed");
			  }
			  System.out.println("GP summary is NOT displayed");
		}
		  
		//GP ADVICE SUMMARY DELETE ICON
		public void ClickGPSummaryDeleteIcon() {
			  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.GPSummaryDeleteIcon));
			  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

		        try {
		        	element.click();
		        } catch (Exception e) {
		            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
		        }
		}
		
		//GP ADVICE SUMMARY PRINT ICON
		public void ClickGPSummaryPrintIcon() {
			 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.GPSummaryPrintIcon));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);

		        try {
		        	element.click();
		        } catch (Exception e) {
		            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
		        }
		}
		  
		//GP ADVICE SUMMARY INFO ICON
		public void ClickGPSummaryInfoIcon() {
			 Actions actions = new Actions(driver);
			 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.GPSummaryInfoIcon));
			 actions.moveToElement(element).perform();
		}	
	
		//CHECK INFO ICON INFORMATION
		public void verifyPatientInfoDisplayedGP(String name) {
			  WebElement hoverElement = driver.findElement(clinicalRecordsLocator.GPSummaryInfoIcon); 
			  Actions actions = new Actions(driver);
			  actions.moveToElement(hoverElement).perform();
			  
			  WebElement info = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.patientInfoByNameDP(name)));
			  if (!info.isDisplayed()) {
			      throw new AssertionError("User info is NOT displayed after hover");
			  }
			
			  System.out.println("User info displayed: " + info.getText());
		}
		
		
		public void clickAdviceButton(String buttonName) {

		    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.gpButton));
		    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

	        try {
	            btn.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
	        
		    }
		}
		

//AUTO REFRACTION
	
		// BUTTON ACTIONS 
		public void ClickBtnAutoRefModule(String button) {
		    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.BtnAutoRefModule(button)));
		    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

	        try {
	            btn.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
	         
	        }
		}
	
	

		
		
		
		
		
		
		
		
		
		
		
}
