package pages;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import locators.clinicalRecordsLocator;




public class clinicalRecordsPage {

    WebDriver driver;
    WebDriverWait wait;

    public clinicalRecordsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
//  CLINICAL RECORDS OPTION CLICK
    public void clickClinicalRecordsOption() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.clinicalRecordsOption));
        element.click();
    }
  
//  PATIENT STATUS SEARCH CLICK
    public void clickPatientStatusSearch() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.patientStatusSearchOption));
        element.click();
    }    
    
 // REPORT VIEW ICON ACTION INSIDE CLINICAL RECORDS
    public void clickReportViewIcon() {
         WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.viewIcon));
         element.click();
    }  

//  ENTER PIN 
    public void enterPin(String value) {

        // RESET BUTTON
        if (value.equalsIgnoreCase("Reset")) {
        	JavascriptExecutor js = (JavascriptExecutor) driver;
            WebElement resetBtn = wait.until(ExpectedConditions.elementToBeClickable( clinicalRecordsLocator.pinButton("Reset")));
            js.executeScript("arguments[0].click();", resetBtn);
            System.out.println("Clicked Reset");

        } 
        // REMOVE ICON
        else if (value.equalsIgnoreCase("Delete")) {
        	JavascriptExecutor js = (JavascriptExecutor) driver;
            WebElement deleteBtn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.deletePinBtn));
            js.executeScript("arguments[0].click();", deleteBtn);
            System.out.println("Clicked Delete");
        }
        // NUMERIC VALUES
        else {
        	JavascriptExecutor js = (JavascriptExecutor) driver;
           for (char digit : value.toCharArray()) {
              WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.enterPin(String.valueOf(digit))));
              js.executeScript("arguments[0].click();", btn);
            }
        }
    }
    
//  VISION  
// VISION CHART    
    public void selectVisionChart(String option) {

        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.visionChart));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        Select select = new Select(element);
        select.selectByVisibleText(option);

        System.out.println("Selected: " + select.getFirstSelectedOption().getText());
    }
    
// UCVA DROPDOWN VISION CHART   
    public void selectUCVA(String reValue, String leValue) {

        By dropdownBtn = By.id("dropdownLabelUcva");
        By dropdownVisible = By.xpath("//div[contains(@class,'dropdown-content') and not(contains(@style,'display: none'))]");
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdownBtn));
        dropdown.click();
        WebElement re = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectRE(reValue)));
        re.click();
        if (driver.findElements(dropdownVisible).isEmpty()) {
            dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdownBtn));
            dropdown.click();
        }
        WebElement le = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectLE(leValue)));
        le.click();    
    }
    
 // UCVAph DROPDOWN VISION CHART   
    public void selectUCVAph(String reValue, String leValue) {
        By dropdownBtn = By.id("dropdownLabelUcvaph");
        By dropdownVisible = By.xpath("//div[@id='customDropdownUcvaph']//div[contains(@class,'dropdown-content') and not(contains(@style,'display: none'))]");
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdownBtn));
        dropdown.click();
        WebElement re = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectREph(reValue)));
        re.click();
        if (driver.findElements(dropdownVisible).isEmpty()) {
            dropdown = wait.until(ExpectedConditions.elementToBeClickable(dropdownBtn));
            dropdown.click();
        }
        WebElement le = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.selectLEph(leValue)));
        le.click();
    }
 
//    METHODS DROPDOWN IN VISION
    public void selectMethod(String option) {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.methodInput));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", dropdown);
        
        Select select = new Select(dropdown);
        select.selectByVisibleText(option);
    }
  
// SAVE BUTTON IN VISION     
    public void clickSaveBtn() {
    	System.out.println("SAVE BTN STRAT IN VISION");
    	 WebElement saveBtn = wait.until(
    		        ExpectedConditions.presenceOfElementLocated(clinicalRecordsLocator.saveVisBtn));
    		    wait.until(driver -> saveBtn.isEnabled());

    		    ((JavascriptExecutor) driver)
    		        .executeScript("arguments[0].scrollIntoView(true);", saveBtn);

    		    saveBtn.click();
    		    System.out.println("SAVE BTN CLICKED IN VISION");
    }


//    REFERRAL ADVICE MODULE
    
//    HOSPITAL DROPDOWN   
    public void selectHospitalDropdown(String option) {

        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.hospitalInput));
        element.click();    
        WebElement eventOrgName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.hosInput));
        eventOrgName.sendKeys(option);
        eventOrgName.sendKeys(Keys.ENTER);

    }
    
//  CLINIC DROPDOWN   
  public void selectclinicDropdown(String option) {
      WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.clinicInput));
      element.click();    
      WebElement eventOrgName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.cliInput));
      eventOrgName.sendKeys(option);
      eventOrgName.sendKeys(Keys.ENTER);

  }    
    
//REASON FOR REFERRAL DROPDOWN   
public void selectReasonRefDropdown(String option) {
    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.reasonInput));
    element.click();    
    WebElement eventOrgName = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.reasonRefInput));
    eventOrgName.sendKeys(option);
    eventOrgName.sendKeys(Keys.ENTER);

}   
       
//SAVE BUTTON IN REFERRAL     
public void clickSaveRefBtn() {

	WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.saveRefBtn));
	
	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", saveBtn);

	wait.until(ExpectedConditions.elementToBeClickable(saveBtn)).click();
}  
    
  
// REFERRAL ADVICE SUMMARY DISPLAYED  
public void verifyReferralSummaryDisplayed() {

    WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(clinicalRecordsLocator.ReferralSummary));

    if (!summary.isDisplayed()) {
        throw new AssertionError("Referral summary is NOT displayed");
    }

    System.out.println("Referral summary is displayed");
} 
 
// REFERRAL ADVICE SUMMARY NOT DISPLAYED
public void verifyReferralSummaryNotDisplayed() {

    boolean isNotVisible = wait.until(
        ExpectedConditions.invisibilityOfElementLocated(clinicalRecordsLocator.ReferralSummary)
    );

    if (!isNotVisible) {
        throw new AssertionError("Referral summary is STILL displayed");
    }

    System.out.println("Referral summary is NOT displayed");
}
    
// REFERRAL ADVICE SUMMARY DELETE ICON
public void ClickReferralSummaryDeleteIcon() {
    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ReferralSummaryDeleteIcon));
    element.click();
}

//REFERRAL ADVICE SUMMARY PRINT ICON
public void ClickReferralSummaryPrintIcon() {
	 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ReferralSummaryPrintIcon));
	 element.click();
}
    
//REFERRAL ADVICE SUMMARY INFO ICON
public void ClickReferralSummaryInfoIcon() {
	Actions actions = new Actions(driver);
	WebElement element = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.ReferralSummaryInfoIcon));
	actions.moveToElement(element).perform();
} 
// CHECK INFO ICON INFORMATION
public void verifyPatientInfoDisplayed(String name) {

    // Step 1: Hover on the element (button / row / icon)
    WebElement hoverElement = driver.findElement(clinicalRecordsLocator.ReferralSummaryInfoIcon); 
    Actions actions = new Actions(driver);
    actions.moveToElement(hoverElement).perform();

    // Step 2: Wait for tooltip/info to appear
    WebElement info = wait.until(
        ExpectedConditions.visibilityOfElementLocated(
            clinicalRecordsLocator.patientInfoByName(name)
        )
    );

    if (!info.isDisplayed()) {
        throw new AssertionError("Patient info is NOT displayed after hover");
    }

    System.out.println("Patient info displayed: " + info.getText());
}    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


}
