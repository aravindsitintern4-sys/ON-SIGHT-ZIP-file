package pages;


import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import locators.hospitalMasterLocator;

public class hospitalMasterPage {

    WebDriver driver;
    WebDriverWait wait; 

    public hospitalMasterPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    	
// HOSPITAL MASTER
    public void clickHospitalMasterOption() {

        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(hospitalMasterLocator.hospitalMasterOption));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        try {
            element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver)
                .executeScript("arguments[0].click();", element);
        }
    }

 // CREATE NEW USER
    public void clickNewBtn() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(hospitalMasterLocator.newBtn));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

        try {
            element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver)
                .executeScript("arguments[0].click();", element);
        }
    }
    
// HOSPITAL NAME
    public void enterHospitalName(String hospital) {
	     WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(hospitalMasterLocator.hospitalNameInput));
	     element.sendKeys(hospital);
    }

 // HOSPITAL SHORT NAME
    public void enterHospitalShortName(String hospital) {
	     WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(hospitalMasterLocator.hospitalShortNameInput));
	     element.sendKeys(hospital);
    }    
    
// HOSPITAL TYPE
public void selectHospitalType(String type) {
     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(hospitalMasterLocator.hospitalTypeInput));
     
     Select select = new Select(element);
     select.selectByVisibleText(type);
}    
    
// ADDRESS LINE
public void enterAddress(String address) {
     WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(hospitalMasterLocator.addressInput));
     element.sendKeys(address);
}    
    
// TALUK
public void selectTaluk(String taluk) {
  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(hospitalMasterLocator.talukInput));
  
  Select select = new Select(element);
  select.selectByVisibleText(taluk);
}    
    
//DISTRICT
public void selectDistrict(String district) {
WebElement element = wait.until(ExpectedConditions.elementToBeClickable(hospitalMasterLocator.districtInput));

Select select = new Select(element);
select.selectByVisibleText(district);
}    
    
//STATE
public void selectState(String state) {
WebElement element = wait.until(ExpectedConditions.elementToBeClickable(hospitalMasterLocator.stateInput));

Select select = new Select(element);
select.selectByVisibleText(state);
}    
    
//COUNTRY
public void selectCountry(String country) {
WebElement element = wait.until(ExpectedConditions.elementToBeClickable(hospitalMasterLocator.countryInput));

Select select = new Select(element);
select.selectByVisibleText(country);
}    
    
//TELEPHONE NUMBER
public void enterTelephone(String telephone) {
  WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(hospitalMasterLocator.telephoneInput));
  element.clear();
  element.sendKeys(telephone);
}     
    
// EMAIL 
public void enterEmail(String email) {
WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(hospitalMasterLocator.emailInput));
element.clear();
element.sendKeys(email);
}    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
