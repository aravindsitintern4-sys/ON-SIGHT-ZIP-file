package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import locators.dashboardStationsLocator;

public class dashboardStationsPage {

    WebDriver driver;
    WebDriverWait wait;

    public dashboardStationsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
    
// STATION OVERVIEW ----> DASHBOARD PAGE
    
    public void clickWaitingBadge() {
        WebElement badge = wait.until(ExpectedConditions.elementToBeClickable(dashboardStationsLocator.waitingBadge));
        badge.click();
    }

    // TOTAL OP VALIDATION
    public void validateTotalOP() {

        wait.until(d -> !driver.findElement(dashboardStationsLocator.totalOP).getText().trim().isEmpty());

        int total = textParseValidation(driver.findElement(dashboardStationsLocator.totalOP));
        int waiting = textParseValidation(driver.findElement(dashboardStationsLocator.waitingTotal));
        int completed = textParseValidation(driver.findElement(dashboardStationsLocator.completedTotal));

        System.out.println("Station Overview Summary");
        System.out.println("Total OP     : " + total);
        System.out.println("Waiting      : " + waiting);
        System.out.println("Completed    : " + completed);
        System.out.println("Expected Sum : " + (waiting + completed));

        Assert.assertEquals(total, waiting + completed, "Total OP mismatch!");
    }

    // STATION NAME VALIDATION
    public void validateStationNames() {

        List<WebElement> stations = driver.findElements(dashboardStationsLocator.stationNames);

        System.out.println("\n Station List");

        Assert.assertTrue(stations.size() > 0, "No stations found!");

        for (WebElement ele : stations) {
            System.out.println("Station: " + ele.getText().trim());
            Assert.assertTrue(ele.isDisplayed(), "Station not visible: " + ele.getText());
        }
    }

    //WAITING SUM VALIDATION
    public void validateWaitingSum() {

        List<WebElement> waitingList = driver.findElements(dashboardStationsLocator.waitingValues);

        int sum = 0;

        System.out.println("\n Waiting Count Per Station");

        for (int i = 0; i < waitingList.size(); i++) {

            int value = textParseValidation(waitingList.get(i));
            sum += value;

            String stationName = driver.findElements(dashboardStationsLocator.stationNames).get(i).getText().trim();
            System.out.println(stationName + " -> Waiting: " + value);
        }

        int waitingTotal = textParseValidation(driver.findElement(dashboardStationsLocator.waitingTotal));

        System.out.println("Calculated Waiting Total: " + sum);
        System.out.println("UI Waiting Total       : " + waitingTotal);

        Assert.assertEquals(sum, waitingTotal, "Waiting total mismatch!");
    }

    //PROGRESS BAR VALIDATION (>0)
    public void validateProgressBars() {

        List<WebElement> waitingList = driver.findElements(dashboardStationsLocator.waitingValues);
        List<WebElement> bars = driver.findElements(dashboardStationsLocator.progressBars);

        System.out.println("\n Progress Bar Validation (>0)");

        for (int i = 0; i < waitingList.size(); i++) {

            int value = textParseValidation(waitingList.get(i));
            String stationName = driver.findElements(dashboardStationsLocator.stationNames).get(i).getText().trim();

            if (value > 0) {
                System.out.println(stationName + " -> Waiting: " + value + " → Progress Bar DISPLAYED");
                Assert.assertTrue(bars.get(i).isDisplayed(),"Progress bar missing for value > 0 at row " + i);
            }
        }
    }

    //ZERO VALUE PROGRESS VALIDATION
    public void validateZeroProgressBars() {

        int size = driver.findElements(dashboardStationsLocator.waitingValues).size();

        System.out.println("\n Zero Waiting Progress Validation");

        for (int i = 1; i <= size; i++) {

            int value = textParseValidation(driver.findElement(dashboardStationsLocator.waitingValueByIndex(i)));

            String stationName = driver.findElement(dashboardStationsLocator.stationNameByIndex(i)).getText().trim();

            WebElement bar = driver.findElement(dashboardStationsLocator.progressBarByIndex(i));

            String style = bar.getAttribute("style");

            if (value == 0) {
                System.out.println(stationName + " -> Waiting: 0 → Progress Bar EMPTY (" + style + ")");
                Assert.assertTrue(style.contains("0%"),"Progress bar not empty at row " + i);
            }
        }
    }

    private int textParseValidation(WebElement element) {

        String text = element.getText().trim();

        if (text.isEmpty()) {
            text = element.getAttribute("textContent").trim();
        }

        if (text.isEmpty()) {
            throw new RuntimeException("Empty value found for element: " + element);
        }

        return Integer.parseInt(text.replaceAll("[^0-9]", ""));
    }




//SURGERY CONFIRMED ----> DASHBOARD PAGE
    
    public void clickSurgeryAdviced() {
    	 WebElement surgeryConfirmed = wait.until(ExpectedConditions.elementToBeClickable(dashboardStationsLocator.surgeryConfirmed));
    	 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", surgeryConfirmed);

	        try {
	        	surgeryConfirmed.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", surgeryConfirmed);
	        }
    }  
	
    // BUTTON ACTIONS 
	public void ClickBtnOnboarding(String button) {
	    WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(dashboardStationsLocator.BtnOnboarding(button)));

	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", btn);

	        try {
	            btn.click();
	        } catch (Exception e) {
	            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
	        }
	 }

 		
 		
 		
 		
 		
 		
 		
 		
}
