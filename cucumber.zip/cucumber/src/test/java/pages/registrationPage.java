package pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import locators.registrationLocator;

public class registrationPage {

    WebDriver driver;
    WebDriverWait wait;

    public registrationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void clickRegOption() {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(registrationLocator.regOption));
        element.click();
    }
    
//    FIRST NAME
    public void enterFirstName(String fname) {
        WebElement firstName = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.firstNameInput));
        firstName.clear();
        firstName.sendKeys(fname);       
    }
    
//  LAST NAME
    public void enterAge(String age) {
	      WebElement lastName = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.ageInput));
	      lastName.sendKeys(age);       
    }
  
//	AGE
	public void enterLastName(String age) {
	    WebElement subjectElement = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.lastNameInput));
	    subjectElement.sendKeys(age);       
	}

//	GENDER
	public void selectGender(String gender) {
	    WebElement genderDropdown = wait.until(ExpectedConditions.elementToBeClickable(registrationLocator.genderInput));

	    Select select = new Select(genderDropdown);
	    select.selectByVisibleText(gender);
	}
	
// TRANS GENDER ---> YES
	public void clickYes() {
	    WebElement yes = wait.until(ExpectedConditions.elementToBeClickable(registrationLocator.yesBtn));
	    yes.click();
	}
	
//	TRANS GENDER -----> NO
	public void clickNo() {
	    WebElement no = wait.until(ExpectedConditions.elementToBeClickable(registrationLocator.noBtn));
	    no.click();
	}
	
//	  OPEN DROPDWON ---> GENDER - WITHOUT SELECT VALUES
	public void clickGenderDropdown(){
		 WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(registrationLocator.genderInput));
		 dropdown.click();
	}
    
//	NEXT OF KIN
	public void selectKin(String kin) {
	    WebElement subjectElement = wait.until(ExpectedConditions.elementToBeClickable(registrationLocator.kinInput));   
	    
	    Select select = new Select(subjectElement);
	    select.selectByVisibleText(kin);
	}
	
//	OPEN DROPDOWN ----> NEXT OF KIN - WITHOUT SELECT VALUES
	public void clickKinDropdown() {
	    WebElement subjectElement = wait.until(ExpectedConditions.elementToBeClickable(registrationLocator.kinInput));   
	    subjectElement.click();
	}
	
//	KIN NAME
	public void enterKinName(String kinName) {
	    WebElement subjectElement = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.kinNameInput));
	    subjectElement.sendKeys(kinName);
	}	
	
//	DOOR / STREET
	public void enterDoorStreet(String doorStreet) {
	    WebElement subjectElement = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.doorStreetInput));
	    subjectElement.sendKeys(doorStreet);
	}
	
//	LOCALITY
	public void enterLocality(String locality) {
	    WebElement subjectElement = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.localityInput));
	    subjectElement.sendKeys(locality);
	}
	
//	AREA
	public void clickAreaBtn() {
	    WebElement areaBtn = wait.until(ExpectedConditions.elementToBeClickable(registrationLocator.areaBtn));
	    areaBtn.click();
	}
	
	public void selectArea(String area) {
	    WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(registrationLocator.areaInput));
	    dropdown.click();
	    dropdown.sendKeys(area);
	    dropdown.sendKeys(Keys.ENTER);

//	    Select select = new Select(dropdown);
//	    select.selectByVisibleText(area);
	}
	
//	PINCODE
	public void enterPincode(String pincode) {
	    WebElement subjectElement = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.pincodeInput));
	    subjectElement.sendKeys(pincode);
	}
	
//	TALUK
	public void selectTaluk(String taluk) {
	    WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(registrationLocator.talukInput));
	    dropdown.click();
	    dropdown.sendKeys(taluk);
	    dropdown.sendKeys(Keys.ENTER);
	}
	
//	MOBILE NUMBER
	public void enterMobile(String mobile) {
	    WebElement subjectElement = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.mobileNumInput));
	    subjectElement.sendKeys(mobile);       
	}	
	
//	AADHAAR NUMBER
	public void enterAadhaar(String aadhaar) {
	    WebElement subjectElement = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.aadhaarNumInput));
	    subjectElement.sendKeys(aadhaar);       
	}	
	
//	SUBMIT BUTTON
    public void clickSubmit() {
    	WebElement submitBtn = driver.findElement(registrationLocator.submitBtn);
    	submitBtn.click();
    }

//	CLEAR BUTTON
    public void clickClear() {
    	WebElement clearBtn = driver.findElement(registrationLocator.ClearBtn);
    	clearBtn.click();	
    }

//	CANCEL BUTTON
    public void clickCancel() {
    	WebElement cancelBtn = driver.findElement(registrationLocator.CancelBtn);
    	cancelBtn.click();
    }

//	CLOSE ICON BUTTON
    public void clickCloseIcon() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	    WebElement closeBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.closeIconBtn));

	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("arguments[0].click();", closeBtn);

	    System.out.println("Close icon clicked using JS");
    }   
    
//  COPY AND STORE THE OID AND PIN AFTER REGISTER  
    public static String generatedOID;
    public static String generatedPIN;

    public void captureOIDAndPIN() {
    	try {
            System.out.println("Capture OID and PIN method started");

            generatedOID = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.CopyOID)).getText().trim();

            generatedPIN = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.CopyPIN)).getText().trim();

            System.out.println("Captured OID : " + generatedOID);
            System.out.println("Captured PIN : " + generatedPIN);

        } catch (Exception e) {
            System.out.println("Unable to capture OID and PIN");
            e.printStackTrace();
        }
    }
    
}
