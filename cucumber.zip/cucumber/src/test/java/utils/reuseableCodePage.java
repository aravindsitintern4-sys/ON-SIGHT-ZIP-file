package utils;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import org.openqa.selenium.io.FileHandler;



public class reuseableCodePage {
	
	    WebDriver driver;
	    WebDriverWait wait;

	    public reuseableCodePage(WebDriver driver) {
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
	    }

	    // CLEAR BUTTON
	    public void clickClearButton() {
		     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.clearBtnCommon));
		     element.click();
	    }	
	    	
	    // CANCEL BUTTON
	    public void clickCancelButton() {
		     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.cancelBtn));
		     element.click();
	    }
	    
	    // CLOSE ICON
	    public void clickCloseButton() {
	        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.closeBtn));
	        element.click();
	    }
    
	    // CLOSE BUTTON
	    public void clickCloseButtonOrg() {
	        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.closeBtnOrg));
	        element.click();
	    }
    
	    // SUBMIT BUTTON
	    public void clickSubmitButton() {
	        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.submitBtn));
	        element.click();
	    }
    
	    //EDIT BUTTON
	    public void clickEditBtn() {
	        WebElement editBtn = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.editBtnEnable));
	        editBtn.click();
	    }
    
	  // BUTTON CLICK ACTION COMMON
	    public void clickButton(String btn) {
		     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.Button(btn)));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
			 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	    }
    
	    // SAVE BUTTON
	    public void clickSaveBtn() {
	        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.saveBtn));
	        element.click();
	    }
    
	   //UPDATE BUTTON
	    public void clickUpdateBtn() {
	      WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.updateBtn));
	      element.click();
	    }
    
	    // LABEL CLICK ACTION
	    public void clickLabelButton(String button) {
	        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.buttonClick(button)));
	        element.click();
	    }
    
	    // BUTTON CLICK ACTION
	    public void clickButtonOrg(String button) {
	
	        By locator = reuseableCodeLocator.buttonOrgClick(button.trim());
	        WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", element);
	        boolean isEnabled = element.isEnabled();
	
	        if (!isEnabled) {
	            throw new RuntimeException(button + " button is disabled - mandatory fields not completed");
	        }
	        try {
	            wait.until(ExpectedConditions.elementToBeClickable(locator)).click();
	        } catch (Exception e) {
	            try {
	                element = wait.until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(locator)));
	                element.click();
	            } catch (Exception ex) {
	                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	            }
	        }
	    }
        
	    //DELETE BUTTON
	    public void clickDeleteBtn() {
	    	WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.deleteBtnEnable));
	    	element.click();
	    }
    
	    //DELETE CONFIRAMTION OK BUTTON
	    public void clickOKBtn() {
	    	WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.confirmOkBtn));
	    	element.click();
	    }
    
	    //DELETE CONFIRMATION CANCEL BUTTON
	    public void clickCancelBtn() {
	    	WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.confirmCancelBtn));
	    	element.click();
	    }
    
	    // FLEX BUTTON CLICK
	    public void clickFlexButton(String button, String eye) {
	        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.flexBtn(button, eye)));
	        element.click();
	    }
    
	  // SEARCH ICON NEAR INPUT BOX
	   public void clickSearchIcon() {
		  WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.searchIconBtn));
	      try {
		    btn.click();
		    System.out.println("Clicked Search Icon button");
		} catch (Exception e) {
		    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", btn);
		    System.out.println("Clicked Search Icon button using JavaScript");
		}
	  }

 // EDIT BUTTON WORKFLOW 

	 // SEARCH BAR
	   public void enterIdInSearchBar(String data) {
		     WebElement searchBarInput = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.searchBar) );
		//     searchBarInput.click();
		//	     searchBarInput.clear();
		     searchBarInput.sendKeys(data);
	   }
	
	 //CHECKBOX
	 public void clickCheckbox() {
	 	 WebElement checkbox = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.clickCheckboxTable));
	     checkbox.click();
	 }


	 //CLEAR SEARCH Box
	 public void clickClearSearch() {
	     WebElement searchBar = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.searchBar));
	     searchBar.clear();
	 }
		
	 //RESET PASSWORD BUTTON
	 public void clickResetPasswordBtn() {
	     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.resetPasswordBtnEnable));
	     element.click();
	 }	    
	    
	 // LOGOUT ICON
	 public void clickLogout() {
	     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.logoutIcon));
	     element.click();
	 }	 
	 
	 // HOME ICON
	 public void clickHome() {
	     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.homeIcon));
	     element.click();
	 }
	    	    

	//  USER NAME AND PASSWORD AFTER RESET PASSWORD IN USER MASTER
	 public void enterUserNameId(String user) {
		 wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.resetpasswordPageDisplay));
		 
	     WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.username));
	     element.clear();
	     element.sendKeys(user);
	 }
	
	 public void enterUserPassword(String pass) {
	     WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.password));
	     element.clear();
	     element.sendKeys(pass);
	 }	
	 
	 public void clickSigninBtn() {
	     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.signinBtn));
	     element.click();
	 }
 
	 public void clickSaveBtnResetPass() {
	     WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.saveBtnResetPass));
	     element.click();
	 }
	 
	//REPORTS INSIDE OPTIONS (OP , SURGERY , CAMP SUMMARY)
	 public void clickOption(String option) {
	
		    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.reportOption(option)));
		    element.click();
	 }
	
	//   PAGINATION ACTIONS
	 
	public void clickNext() {
		  driver.findElement(reuseableCodeLocator.nextBtn).click();
		  waitForPageChange();
	}
	
	public void clickPrevious() {
		  driver.findElement(reuseableCodeLocator.previousBtn).click();
		  waitForPageChange();
	}

	public void clickPage(String page) {
		  driver.findElement(reuseableCodeLocator.pageBtn(page)).click();
		  wait.until(ExpectedConditions.textToBePresentInElementLocated(reuseableCodeLocator.activePage, page));
	}
	
	public boolean isPreviousDisabled() {
		return driver.findElement(reuseableCodeLocator.previousBtn).getAttribute("disabled") != null;
	}	    
		    
	public void waitForPageChange() {
	    wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.activePage));
	}	    
		
	public void verifyActivePage(String expectedPage) {
	    WebElement active = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.activePage));
	
	    String actualPage = active.getText().trim();
	
	    System.out.println("Expected: " + expectedPage);
	    System.out.println("Actual: " + actualPage);
	
	    Assert.assertEquals(actualPage, expectedPage, "Page mismatch!");
	}

	// EXPORT EXCEL BUTTON
	public void clickExport() {
	
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.exportBtn));
	
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	
	    try {
	        wait.until(ExpectedConditions.elementToBeClickable(element)).click();
	    } catch (Exception e) {
	        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	    }
	}
	
	
//ACTION FOR FILE DOWNLOAD
	
//EXPORTED FILE DOWNLOAD 
	public boolean isFileDownloaded() {
	
		String path = System.getProperty("user.home") + "\\Downloads";
		File dir = new File(path);
		
		int timeout = 20;
		
		for (int i = 0; i < timeout; i++) {
		
		    File[] files = dir.listFiles();
		
		    if (files != null && files.length > 0) {
		
		        for (File file : files) {
		
		            System.out.println("Found file: " + file.getName());
		
		           // IGNORE TEMPORARY CHROME DOWNLOAD FILE IN RIGHT CORNER
		            if (!file.getName().endsWith(".crdownload")) {
		                return true;
		            }
		        }
		    }
		
		    try {
		        Thread.sleep(1000);
		    } catch (Exception e) {}
		}
		
		return false;
	}



// SCREENSHOTS
	public void takeScreenshot(String fileName) {
	
	    try {
	        Thread.sleep(4000); 
	
	        TakesScreenshot ts = (TakesScreenshot) driver;
	        File src = ts.getScreenshotAs(OutputType.FILE);
	
	        String path = System.getProperty("user.dir") + "\\screenshots\\";
	        File dir = new File(path);
	
	        if (!dir.exists()) {
	            dir.mkdirs();
	        }
	
	        File dest = new File(path + fileName + ".png");
	        FileHandler.copy(src, dest);
	
	        System.out.println("Screenshot saved at: " + dest.getAbsolutePath());
	
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}


	//ENTER OID
	public void enterOid(String oid) {
	    WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.oidInput));
	
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("arguments[0].scrollIntoView(true);", element);
	    js.executeScript("arguments[0].click();", element);
	    js.executeScript("arguments[0].value='" + oid + "';" +"arguments[0].dispatchEvent(new Event('input'));",element);
	    System.out.println("OID entered successfully");
	}
	
	// POPUP DISPLAY COMMON
	public void popupDisplay(String popupNAme) {
		WebElement popup = wait.until( ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.popupCommon(popupNAme)));
		
		Assert.assertTrue(popup.isDisplayed());
		System.out.println("Popup is displayed");
	}
	
	// ERROR MESSEGE VALIDATION COMMON
	public void errorMsgValidation(String errorMsg) {
	
	    WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.errorMsgInput(errorMsg)));
	    String actualMsg = element.getText().trim();
	    if (!actualMsg.contains(errorMsg)) {
	        throw new AssertionError("Expected: " + errorMsg + " but found: " + actualMsg);
	    }
	    System.out.println("Error message displayed: " + actualMsg);
	}

  	    
	//SELECT PATIENT WAITING (ASSIGNED/UNASSIGNED)	    	   
	public void clickClinicalOption() {
	
		WebElement patientCard = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.patientCard));

	    boolean isAssigned = !patientCard.findElements(reuseableCodeLocator.assignedBadge).isEmpty();

	    WebElement patientInfoEl = patientCard.findElement(reuseableCodeLocator.patientInfo);
	
	    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", patientInfoEl);
	
	    if (isAssigned) {
	        clickYes();
	//        clickCancelAssigned();
	    }
	}
	
	
	//CONFIRMATION BUTTON (CONTINUE,CANCEL)
	public void clickYes() {
	    WebElement yesButton = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.yesBtn));
	    yesButton.click();
	}
	
	public void clickCancelAssigned() {
	    WebElement cancelButton = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.cancelBtn));
	    cancelButton.click();
	}

	//Enter PIN 
	//public void enterPin(String pin) {
	//	JavascriptExecutor js = (JavascriptExecutor) driver;
	//    for (char digit : pin.toCharArray()) {
	//        WebElement btn = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.enterPin(String.valueOf(digit))));
	//        js.executeScript("arguments[0].click();", btn);
	//    }
	//}  
	
	
	
	// VISION MODULE
	
	// VISION BUTTON
	public void clickBtnVision(String button) {
		System.out.println(button+" BTN STRAT IN VISION");
		 WebElement visionBtn = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.btnVision(button)));
		 visionBtn.click();
		 System.out.println(button+" BTN CLICKED IN VISION");
	}
	
	// WINDOW BUTTON ACTIONS
	public void clickBtnWindow(String button) {
		System.out.println(button+" BTN STRAT");
		 WebElement windowBtn = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.windowBtn(button)));
		 windowBtn.click();
		System.out.println(button+" BTN CLICKED");
	}


// REFERRAL ADVICE MODULE
	
	//REFERRAL ADVICE BUTTON
	public void clickBtnReferralAdvice(String button) {
		System.out.println(button+" BTN STRAT IN REFERRAL ADVICE");
		 WebElement Btn = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.btnRefAdvice(button)));
		 Btn.click();
		System.out.println(button+" BTN CLICKED IN REFERRAL ADVICE");
	}
	
	// REMARKS
	public void enterRemark(String data) {
	    WebElement remark = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.remarkInput));
	    remark.clear();
	    remark.sendKeys(data);
	}
	
	// CHECK BOX
	public void checkboxClick() {
	    WebElement checkbox = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.checkboxLoc));
	    checkbox.click();
	}
	
	
	public void validateNoItemsFoundMessage() {
	
	    WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.noItemsFoundMsg));
	    String actual = message.getText().trim();
	
	    if (!actual.equalsIgnoreCase("No items found")) {
	        throw new AssertionError("Expected 'No items found' but found: " + actual);
	    }
	    System.out.println("'No items found' message is displayed");
	}
	
	//ALERT ERROR MESSEGE DISPLAY
	public void validateToastMessage(String expectedMsg) {
	
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	
	    WebElement toast = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.toastMsg));
	
	    String actualMsg = toast.getText().trim();
	    System.out.println("Toast message: " + actualMsg);
	
	    if (!actualMsg.equalsIgnoreCase(expectedMsg)) {
	        throw new AssertionError("Expected: " + expectedMsg + " but found: " + actualMsg);
	    }
	
	    System.out.println("Toast message validated: " + actualMsg);
	}



	public void clickSaveAndValidateOldPassword() {
	
	    WebElement saveBtn = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.saveLocator));
	    saveBtn.click();
	
	    wait.until(ExpectedConditions.stalenessOf(saveBtn));
	
	    WebElement error = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.oldPassworderrorMsg));
	
	    System.out.println("Error displayed: " + error.getText());
	}
	
	
	// PRINT PREVIEW --> PRINT , CLOSE BUTTON
	public void clickPrintPreviewBtn(String button) {
	    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.printPreview(button)));
	    element.click();
	}
		
	//SUMMARY DISPLAYED  
	public void verifySummaryDisplayed(String locator) {
	
		 WebElement summary = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.Summary(locator)));
		
		 if (!summary.isDisplayed()) {
		     throw new AssertionError("Referral summary is NOT displayed");
		 }
		
		 System.out.println("Referral summary is displayed");
	} 
	
	//SUMMARY NOT DISPLAYED
	public void verifySummaryNotDisplayed(String locator) {
	
		 boolean isNotVisible = wait.until(ExpectedConditions.invisibilityOfElementLocated(reuseableCodeLocator.Summary(locator)));
		
		 if (!isNotVisible) {
		     throw new AssertionError("Referral summary is STILL displayed");
		 }
		
		 System.out.println("Referral summary is NOT displayed");
	}
	 
	//SUMMARY DELETE ICON
	public void ClickSummaryDeleteIcon(String locator) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.SummaryDeleteIcon(locator)));
		 element.click();
	}
	
	//SUMMARY PRINT ICON
	public void ClickSummaryPrintIcon(String locator) {
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.SummaryPrintIcon(locator)));
		 element.click();
	}
	 
	//SUMMARY INFO ICON
	public void ClickSummaryInfoIcon(String locator) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.SummaryInfoIcon(locator)));
		element.click();
	}    
	
	// CHECK BOX LOOKS LIKE BUTTON
	public void ClickCheckboxBtn(String name) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(reuseableCodeLocator.getCheckbox(name)));
		element.click();
	} 
	
	//COMMON SYATEM ALERT MESSAGE BUTTON CLICK ACTION
	public void ClickSystemAlertBtn(String button) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    Alert alert = wait.until(ExpectedConditions.alertIsPresent());
	
	    String alertText = alert.getText().toLowerCase();
	
	    if (alertText.contains(button)) {
	        alert.accept(); 
	    } else {
	        alert.dismiss(); 
	    }
	}
	
	//COMMON RED INDICATION ALERT
	public void alertAppear(String alert) {
	    String actual = driver.findElement(reuseableCodeLocator.alertMsg(alert)).getText();
	
	    if (!actual.contains(alert)) {
	        throw new AssertionError("Alert not matched");
	    }
	}

	// BUTTON DISABLE FOR COMMON BUTTONS
	public void buttonDisableCommon(String button) {

	    By buttonLocator = By.xpath("//button[normalize-space()='" + button + "' and @disabled]");
	    WebElement buttonElement = wait.until(ExpectedConditions.presenceOfElementLocated(buttonLocator));

	    Assert.assertTrue(buttonElement.isDisplayed(),button + " button is enabled");
	}

	// COUNSELLING LINK CLICK (COUNSELLING : WILLING)
	public void counsellingClick(String sectionName) {

		By counsellingLocator = By.xpath(
	            "//span[normalize-space()='" + sectionName + "']" +
	            "/ancestor::div[contains(@class,'adv-cont-shad')]" +
	            "//span[contains(@class,'coun-cont') and normalize-space()='Counselling']");

	    WebElement element = wait.until( ExpectedConditions.visibilityOfElementLocated(counsellingLocator));

	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("arguments[0].click();", element);
	}

	// DELETE ICON
	public void deleteIconClick(String sectionName) {

		By trashLocator = By.xpath(
		        "//span[normalize-space()='" + sectionName + "']" +
		        "/ancestor::div[contains(@class,'adv-cont-shad')]" +
		        "//i[contains(@class,'fa-trash')]");
		
	    WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(trashLocator));

	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("arguments[0].click();", element);
	}

	// RED ALERT INDICATION VALIDATION	
	public void verify_validation_message(String expectedMessage) {

	    By validationMsg = By.xpath("//div[normalize-space()='" + expectedMessage + "']");
	    WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(validationMsg));

	    Assert.assertEquals(message.getText().trim(), expectedMessage);
	}
	
	// TOOLTIP FOR INFO ICON
	public void tooltip_information(String tooltip) {

		WebElement element = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'drug-hide1')]//div[contains(text(),'" + tooltip + "')]")));

		String actualTooltip = element.getText();
		System.out.println("Tooltip : " + actualTooltip);

		Assert.assertTrue(
		        actualTooltip.contains(tooltip),"Expected tooltip text '" + tooltip + "' is not displayed");
	}  
}
