package utils;

import org.openqa.selenium.By;

public class reuseableCodeLocator {

	
	public static By saveButton = By.xpath("//button[@class='btn btn-secondry' and normalize-space()='Save']");
	public static By cancelButtonORE = By.xpath("button[@class='btn btn-danger']");
	public static By updateBtn = By.xpath("//button[normalize-space()='Update']");
    public static By deleteBtn =By.xpath("//button[text()='Delete' and @disabled]");
//    public static By saveBtn = By.xpath("//button[@type='submit' and normalize-space()='Save']");
    public static By saveBtn = By.xpath("//button[normalize-space()='Save']");
    public static By clearBtnCommon = By.xpath("//button[normalize-space()='Clear']");
    public static By cancelBtn = By.xpath("//button[normalize-space()='Cancel']");
//	public static By closeBtn = By.xpath("//button[text()='✕']");
	public static By closeBtn = By.xpath("//ngb-modal-window//button[normalize-space()='✕']");
	public static By submitBtn = By.xpath("//button[normalize-space()='Submit']");
	public static By closeBtnOrg = By.xpath("//button[normalize-space()='Close']");
    public static By Button(String btn) {
		 return By.xpath("//button[normalize-space()='"+btn+"']");
	 }
 
	public static By editBtn = By.xpath("//button[text()='Edit' and @disabled]");
	public static By saveBtnDisable = By.xpath("//button[text()='Save' and @disabled]");
	public static By editBtnEnable = By.xpath("//button[@class='tab-button button-radius m-green m-r-10' and normalize-space()='Edit']");
	public static By deleteBtnEnable = By.xpath("//button[@class='tab-button button-radius m-red m-r-10' and normalize-space()='Delete']");
	public static By resetPasswordBtnEnable = By.xpath("//button[@class='tab-button button-radius m-green m-r-10' and normalize-space()='Reset-Password']");
	
	public static By newBtnDisable = By.xpath("//button[text()='New' and @disabled]");

	public static By popup = By.xpath("//div[@role='dialog']//span[text()='User Master']");
	 
	public static By searchBar = By.xpath("//input[@type='text' and @placeholder='Search...']");
	public static By clickCheckboxTable =By.xpath("//input[@type='checkbox')]");
	
	public static By confirmOkBtn = By.xpath("//button[normalize-space()='OK']");
	public static By confirmCancelBtn = By.xpath("//button[normalize-space()='Cancel']"); 
	
	public static By resetPasswordBtn = By.xpath("//button[normalize-space()='Reset-Password']"); 
	
	public static By logoutIcon = By.cssSelector("img[title='Logout']");
	public static By homeIcon = By.xpath("//img[@title='Home']"); 
	 
    public static By oldPassworderrorMsg = By.xpath("//*[normalize-space()='Old password is incorrect']");
    public static By newPassworderrorMsg = By.xpath("//*[normalize-space()='Password does not meet all requirements']");
    public static By confirmPassworderrorMsg = By.xpath("//*[normalize-space()='Passwords do not match']");

    public static By oldPassReqMsg = By.xpath("//*[normalize-space()='Old password is required']");
    public static By newPassReqMsg = By.xpath("//*[normalize-space()='New password is required']");
    public static By confirmPassReqMsg = By.xpath("//*[normalize-space()='Please confirm your password']"); 
	
    public static By username = By.xpath("//app-login//input[@name='username']");
    public static By password = By.xpath("//app-login//input[@name='password']"); 
    public static By signinBtn = By.xpath("//app-login//button[@type='submit']");
    public static By saveBtnResetPass = By.xpath("//app-resetpassword//button[@type='submit']");

    public static By searchButton = By.cssSelector("button.search-style");
    
    public static By searchIconBtn = By.xpath("//div[contains(@class,'modal-content')]//button[contains(@class,'search-style')]");
    
    public static By invalidTelephoneAlert = By.xpath("//*[normalize-space()='Enter a valid telephone number (10 digits or STD-XXXXXXX)']"); 
	 
    public static By invalidMailAlert = By.xpath("//*[normalize-space()='Please enter a valid email address']"); 
	 
    public static By noItemsFoundMsg = By.xpath("//ng-dropdown-panel//div[contains(@class,'ng-option-disabled') and contains(.,'No items found')]");
    
    public static By noDataMessage = By.xpath("//*[contains(text(),'No data') or contains(text(),'no data found')]");
    
    public static By oidInput = By.xpath("//div[contains(@class,'modal-content')]//input[@placeholder='Enter OID']");
    
    public static By patientSearch = By.xpath("//div[contains(@class,'modal-content')]//div[contains(@class,'list-item')]");
    

    
    
 // PAGINATION 

    public static By previousBtn = By.xpath("//button[normalize-space()='Previous']");
    public static By nextBtn = By.xpath("//button[normalize-space()='Next']");

    public static By activePage = By.xpath("//nav//button[contains(@class,'text-white') and not(contains(text(),'Previous')) and not(contains(text(),'Next'))]");

    public static By exportBtn = By.xpath("//button[normalize-space()='Export Excel']");
    
    public static By pageBtn(String page) {
        return By.xpath("//nav//button[normalize-space()='" + page + "']");
    }
    
    public static By reportOption(String option) {
        return By.xpath("//div[contains(@class,'cursor-pointer') and normalize-space()='" + option + "']");
    }
    
    public static By editPopupText(String popupText) {
        return By.xpath("//div[@role='dialog']//*[normalize-space()='" + popupText + "']");
    }
    
    public static By successMessage(String text) {
        return By.xpath("//div[contains(text(),'" + text + "')]");
    }
    
    public static By pageName(String pageName) {
        return By.xpath("//div[contains(@class,'grid')]//*[normalize-space()='" + pageName + "']");
    }
    
    public static By campId(String campId) {
    	return By.xpath("//span[contains(text(),'Camp ID')]/following-sibling::span");
    }
       
    public static By popupCommon(String popupName) {
    	return By.xpath("//div[contains(@class,'modal') or contains(@class,'popup') or contains(@class,'container')]//*[normalize-space()='" + popupName + "']");
    }
    
    public static By errorMsgInput(String errorMsg) {
    	return By.xpath(
    	        "//*[self::span or self::div][contains(@class,'red') or contains(@class,'error') or contains(@class,'text-red')]"
    	        + "[contains(normalize-space(),'" + errorMsg + "')]");
    }
    
// CLinical records Dashboard page actions 
    
    public static By patientCard = By.xpath("(//div[contains(@class,'list-item')])[1]");
    public static By SelectWaitingPatientAssigned = By.xpath("//*[@class='list-item Created assigned-patient ng-star-inserted']");
    public static By SelectWaitingPatient = By.xpath("//*[@class='list-item Created ng-star-inserted']");
      
// YES BTN
    public static By yesBtn = By.xpath("//button[@class='btn btn-outline-secondary' and normalize-space()='Yes, Continue']");
    
 

    public static By noData(String data) {
    	return By.xpath("//div[contains(text(),'" + data + "')]");      
    }
    
    public static By buttonClick(String button) {
    	return By.xpath("//span[contains(text(),'"+button+"')]");      
    }
    
    public static By flexBtn(String button, String eye) {
        return By.xpath("//span[normalize-space()='" + eye + ":']/following-sibling::div//label[normalize-space()='" + button + "']");
    }
    
//    public static By buttonOrgClick(String button) {
//    	return By.xpath("//button[normalize-space()='" + button.trim() + "']");
//    }
 
    
    public static By buttonOrgClick(String button) {
        return By.xpath(
            "//*[self::button or self::a or self::span or self::div or self::input]" +
            "[contains(normalize-space(),'" + button.trim() + "') " +
            "or contains(@value,'" + button.trim() + "') " +
            "or contains(@aria-label,'" + button.trim() + "') " +
            "or contains(@class,'btn')]" 
        );
    }
    
    
//  VISION BUTTON  
    public static By btnVision(String button) {
        return By.xpath("//app-onsight-vision//button[normalize-space()='" + button + "']");
    }   
    
//  WINDOW BUTTON  
    public static By windowBtn(String buttonName) {
        return By.xpath("(//ngb-modal-window)[last()]//div[contains(@class,'modal-footer')]//button[normalize-space()='" + buttonName + "']");
    }
    
// REFERRAL ADVICE MODULE
    public static By btnRefAdvice(String button) {
    	return By.xpath("//app-referral-control//button[normalize-space()='" + button + "']");
    }
     
    public static By clinicErrorMsg = By.xpath("//ng-select[@formcontrolname='clinic']/following::span[contains(@class,'red-fnt')][1]");
    
    public static By remarkInput = By.xpath("//textarea[@formcontrolname='remarks']");
    
    public static By checkboxLoc = By.xpath("//input[@type='checkbox']");
    
    public static By requiredRefMsg() {
        return By.xpath("//app-referral-control//form//span[contains(@class,'red-fnt')]");
    }
    
//    public static By toastMsg = By.xpath("//div[@role='alert']");
    public static By toastMsg = By.xpath(
    	    "//div[@role='alert'] | //app-toast//span"
    	);
    
    
// PRINT PREVIEW CLOSE BUTTON  
    public static By printPreview(String button) {
    	return By.xpath("//app-print-preview-modal//button[normalize-space()='" + button + "']");   
    }
   
    public static By Summary(String locator) {
    	return By.xpath(locator);
    }
    
    public static By SummaryDeleteIcon(String locator) {
        return By.xpath(locator + "//span[contains(@class,'sur-adv-del')]");
    }
    
    public static By SummaryPrintIcon(String locator) {
        return By.xpath(locator + "//i[@class='bi bi-printer']");
    }
    
    public static By SummaryInfoIcon(String locator) {
        return By.xpath(locator + "//i[@class='fa fa-info']");
    } 
  
// CHECK BOX LOOKS BUTTON initially in INVESTIGATION
    public static By getCheckbox(String name) {
        return By.xpath("//app-checkbox-control//label[normalize-space()='" + name + "']");
    }
    
// COMMON RED INDICATION ALERT MESSEGE    
    public static By alertMsg(String alert) {
    	return By.xpath("//*[contains(text(),'"+alert+"')]");
    }
 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
