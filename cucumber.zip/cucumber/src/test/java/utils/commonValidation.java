package utils;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import locators.hospitalMasterLocator;
import locators.outReachMasterLocator;



public class commonValidation {

    reuseableCodePage common;
    WebDriverWait wait;

    public commonValidation() {
        common = new reuseableCodePage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }



// NO DATA FOUND
    @Then("no data found messege should be displayed")
    public void verifyNoDataMessage() {

        WebElement noDataMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.noDataMessage));

        String actualMsg = noDataMsg.getText().trim();
        System.out.println("Message: " + actualMsg);

        if (!actualMsg.toLowerCase().contains("no data")) {
            throw new AssertionError("Expected 'No data found' but got: " + actualMsg);
        }
    }
 
//  EMPTY DATAS FOUND 
    @Then("{string} found messege should be displayed")
    public void verifyMessageDisplayed(String data) {

        WebElement noDataMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.noData(data)));

        String actualMsg = noDataMsg.getText().trim();
        System.out.println("Message: " + actualMsg);

        if (!actualMsg.equalsIgnoreCase(data)) {
            throw new AssertionError("Expected '" + data + "' but got: '" + actualMsg + "'");
        }
    }
    
 // EDIT AND DELETE BUTTONS ARE DISABLE CONDITION
    @Then("edit and delete buttons should be disable initially")
    public void edit_delete_button_disable() {
        WebElement editButton = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.editBtn));
        WebElement deleteButton = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.deleteBtn));
               
        Assert.assertNotNull(editButton.getAttribute("disabled"));
        Assert.assertNotNull(deleteButton.getAttribute("disabled"));

        System.out.println("Edit and Delete and Reset Password buttons are disabled initially");
    }
    
    
// EDIT AND DELETE AND RESET PASSWORD BUTTONS ARE DISABLE CONDITION
    @Then("edit and delete and reset password buttons should be disable initially")
    public void edit_delete_reset_password_button_disable() {
        WebElement editButton = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.editBtn));
        WebElement deleteButton = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.deleteBtn));
        WebElement resetPasswordButton = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.resetPasswordBtn));
        
        Assert.assertNotNull(editButton.getAttribute("disabled"));
        Assert.assertNotNull(deleteButton.getAttribute("disabled"));
        Assert.assertNotNull(resetPasswordButton.getAttribute("disabled"));

        System.out.println("Edit and Delete and Reset Password buttons are disabled initially");
    }

// EDIT AND DELETE AND RESET PASSWORD BUTTON ENABLE
    @Then("edit and delete and reset password buttons should be enabled and new button should be disabled")
    public void validate_buttons_enabled() {

        WebElement editBtn = DriverFactory.getDriver().findElement(reuseableCodeLocator.editBtnEnable);
        WebElement deleteBtn = DriverFactory.getDriver().findElement(reuseableCodeLocator.deleteBtnEnable);
        WebElement resetPasswordBtn = DriverFactory.getDriver().findElement(reuseableCodeLocator.resetPasswordBtnEnable);

        if (!editBtn.isEnabled() || !deleteBtn.isEnabled() || !resetPasswordBtn.isEnabled()) {
            throw new AssertionError("Buttons are not enabled properly");
        }

        // NEW BUTTON DISABLE
        WebElement newBtn = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.newBtnDisable));

        Assert.assertNotNull(newBtn.getAttribute("disabled"));
    }
    
    
 // EDIT AND DELETE BUTTONS ARE ENABLE NEW BUTTON DISABLE
    @Then("edit and delete buttons should be enabled and new button should be disabled")
    public void validate_edit_delete_buttons_enabled_in_event() {
        WebElement editBtn = DriverFactory.getDriver().findElement(outReachMasterLocator.editBtnEnable);
        WebElement deleteBtn = DriverFactory.getDriver().findElement(outReachMasterLocator.deleteBtnEnable);

        if (!editBtn.isEnabled() || !deleteBtn.isEnabled()) {
            throw new AssertionError("Edit or Delete button is not enabled");
        }
        // NEW BUTTON DISABLE   
        WebElement newButtonDisable = wait.until(ExpectedConditions.presenceOfElementLocated(outReachMasterLocator.newBtnDisable));
        Assert.assertNotNull(newButtonDisable.getAttribute("disabled"));
    }
    
//    SAVE BUTTON DISABLE
    @Then("save button should be disable")
    public void save_button_disable() {
        WebElement saveButton = wait.until(ExpectedConditions.presenceOfElementLocated(reuseableCodeLocator.saveBtnDisable));
        Assert.assertNotNull(saveButton.getAttribute("disabled"));
        System.out.println("Save button is disabled initially");
    }
        
//    PAGE LOAD
    @Given("user management page")
    public void user_on_management_main_page() {

        DriverFactory.getDriver().navigate().refresh();

        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//table//tbody//tr")));
    }
    

//   EDIT POPUP EXSISTING DETAILS VISIBILITY
    @Then("{string} existing details should be displayed")
    public void verifyEditPopup(String popupText) {

        WebElement popup = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.editPopupText(popupText)));

        if (!popup.isDisplayed()) {
            throw new AssertionError(popupText + " popup is not displayed");
        }

        System.out.println("Popup displayed with text: " + popupText);
    }
    
//  SUCCESS MESSEGE
  @Then("password successfully messege is appear")
  public void verifySuccessMessage(String expectedMessage) {

	    WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.successMessage(expectedMessage)));

	    String actualMessage = message.getText().trim();
	    System.out.println("Displayed Message: " + actualMessage);

	    Assert.assertTrue(
	        actualMessage.contains(expectedMessage),
	        "Expected message not displayed. Actual: " + actualMessage);
	}
  
//RESET PASSWORD

//OLD PASSWORD INCORRECT VALIDATION
@Then("alert messege for old password should be displayed")
public void alert_messege_old_password_should_displayed() {
	validateAlert(reuseableCodeLocator.oldPassworderrorMsg, "Old password is incorrect");
}

//NEW PASSWORD DOES NOT MATCH VALIDATION
@Then("alert messege for new password should be displayed")
public void alert_messege_newPassword_should_displayed() {
	validateAlert(reuseableCodeLocator.newPassworderrorMsg, "Password does not meet all requirements");
}

//CONFIRM  PASSWORD DOES NOT MATCH VALIDATION
@Then("alert messege for confirm password should be displayed")
public void alert_messege_confirm_Password_should_displayed() {
	validateAlert(reuseableCodeLocator.confirmPassworderrorMsg, "Passwords do not match");
}

public void validateAlert(By locator, String expectedMessage) {

    WebDriver driver = DriverFactory.getDriver();

    if (driver == null) {
        throw new RuntimeException("Driver is null - browser already closed");
    }

    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    WebElement errorMsg = wait.until(ExpectedConditions.refreshed(
            ExpectedConditions.visibilityOfElementLocated(locator)));

    String actualMessage = errorMsg.getText().trim();

    if (!actualMessage.equals(expectedMessage)) {
        throw new AssertionError("Expected: " + expectedMessage + " | Actual: " + actualMessage);
    }

    System.out.println(expectedMessage + " alert is displayed");
}
//ALERT VALIDATION (RED REQUIRE)
//public void validateAlert(By locator, String fieldName) {
//	WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
//	
//	if (!errorMsg.isDisplayed()) {
//	   throw new AssertionError(fieldName);
//	}
//	
//	System.out.println(fieldName + " alert is displayed");
//}

//EMPTY FIELD VALIDATION
public void validateRequiredAlert(By locator, String fieldName) {
	 WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	
	 if (!errorMsg.isDisplayed()) {
	     throw new AssertionError(fieldName + " is required");
	 }
	
	 System.out.println(fieldName + " required alert is displayed");
}


// REQUIRED METHOD
public void validateIncorrectPassword(By locator, String messege) {

	 WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

	 if (!errorMsg.isDisplayed()) {
	     throw new AssertionError(messege);
	 }

	 System.out.println(messege + "is displayed");
	}


// RESET PASSWORD
// OLD PASSWORD EMPTY FIELD
@Then("old password Required alert should be appear")
public void validate_old_password_empty_field() {
	validateRequiredAlert(reuseableCodeLocator.oldPassReqMsg, "Old password");
}  
  
//NEW PASSWORD EMPTY FIELD
@Then("new password Required alert should be appear")
public void validate_new_password_empty_field() {
	validateRequiredAlert(reuseableCodeLocator.newPassReqMsg, "New password");
} 
  
//CONFIRM PASSWORD EMPTY FIELD
@Then("confirm password Required alert should be appear")
public void validate_confirm_password_empty_field() {
	validatePleaseRequiredAlert(reuseableCodeLocator.confirmPassReqMsg, "confirm your password");
}  
  
//EMPTY FIELD VALIDATION
public void validatePleaseRequiredAlert(By locator, String messegs) {
    WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

    if (!errorMsg.isDisplayed()) {
        throw new AssertionError("Please " +messegs);
    }

    System.out.println(messegs + "is displayed");
}  
  
//TELEPHONE NUMBER FIELD VALIDATION
@Then("validation for Telephone No field")
public void validate_tele_phone_number_length() {

   WebDriver driver = DriverFactory.getDriver();
    WebElement field = driver.findElement(hospitalMasterLocator.telephoneInput);
    String value = field.getAttribute("value");
    if (!value.matches("[3-9]\\d{9}")) {

        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.invalidTelephoneAlert));
        String actualText = errorMsg.getText().trim();
        
        if (!actualText.equals("Enter a valid telephone number (10 digits or STD-XXXXXXX)")) {
            throw new AssertionError("Expected 'Enter a valid telephone number (10 digits or STD-XXXXXXX)' but got: " + actualText);
        }
        System.out.println("Correct error message displayed: " + actualText);
    }
}  


//EMAIL FIELD VALIDATION
@Then("validation for Email field")
public void validate_email_field() {

	 WebDriver driver = DriverFactory.getDriver();
	 WebElement field = driver.findElement(hospitalMasterLocator.emailInput);
	 String value = field.getAttribute("value");
	
	 if (!value.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.com$")) {
	
	     WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.invalidMailAlert));
	     
	     String actualText = errorMsg.getText().trim();
	
	     String expectedText = "Please enter a valid email address";
	
	     if (!actualText.equals(expectedText)) {
	         throw new AssertionError("Expected '" + expectedText + "' but got: " + actualText);
	     }
	
	     System.out.println("Correct error message displayed: " + actualText);
	 }
}
    
//  REPORTS 

//EDIT POPUP EXSISTING DETAILS VISIBILITY
@Then("I navigated to {string} page")
public void verifyPageNavigation(String pageName) {

    WebElement page = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.pageName(pageName)));

    String actualText = page.getText().trim();
    System.out.println("Navigated to page: " + actualText);

    if (!actualText.equalsIgnoreCase(pageName)) {
        throw new AssertionError("Expected page: " + pageName + " but found: " + actualText);
    }
}
    
     
//  CAMPID DETAILS VISIBILITY 
@Then("selected data {string} details should be displayed")
public void validate_selected_data_details(String campid) {

    WebDriver driver = DriverFactory.getDriver();
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

    WebElement block = wait.until(ExpectedConditions.visibilityOfElementLocated(reuseableCodeLocator.campId(campid)));

    String fullText = block.getText();
    System.out.println("Displayed: " + fullText);

    if (!fullText.contains(campid)) {
        throw new AssertionError("Camp ID mismatch");
    }

    if (!fullText.contains(",")) {
        throw new AssertionError("Place not displayed correctly");
    }
}






































    
}



