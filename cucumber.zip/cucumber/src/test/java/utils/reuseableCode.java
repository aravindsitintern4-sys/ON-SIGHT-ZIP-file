package utils;

import io.cucumber.java.en.*;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;



public class reuseableCode {

    reuseableCodePage reuseableCode;
    WebDriverWait wait;

    public reuseableCode() {
    	reuseableCode = new reuseableCodePage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(30));
    }
    
    
// CLEAR BUTTON
    @And("user clicks clear button")
    public void user_clicks_clear_button() {
	    	reuseableCode.clickClearButton();
    }
// CANCEL BUTTTON
    @And("user clicks cancel button")
    public void user_clicks_cancel_button() {
	    	reuseableCode.clickCancelButton();
    }
// CLOSE ICON
    @And("user clicks close icon")
    public void user_clicks_close_icon() {
		reuseableCode.clickCloseButton();
    }
    
// CLOSE BUTTON  
  @And("user clicks close button common")
  public void user_clicks_close_button() {
	    	reuseableCode.clickCloseButtonOrg();
  }
  
// SUBMIT
    @And("user clicks submit button")
    public void user_clicks_submit_button() {
	    	reuseableCode.clickSubmitButton();
    }

// ADD BUTTON
  @And("I click {string} button")
  public void user_clicks_add_button(String btn) {
	    	reuseableCode.clickButton(btn);
  }
    
// SEARCH ICON
  @And("user clicks on Search icon")
  public void user_clicks_search_icon() {
	  reuseableCode.clickSearchIcon();
  }
  

// SEARCH BOX
	@And("user enters id in search bar {string}")
	public void user_enters_id_to_search(String data) {
		reuseableCode.enterIdInSearchBar(data);
	}
	
    @Then("details for id {string} should be displayed")
    public void validate_details_displayed_id_searchbox(String data) {

        WebElement row = wait.until(ExpectedConditions.visibilityOfElementLocated(getRowByData(data)));

        if (!row.isDisplayed()) {
            throw new AssertionError("No data found: " + data);
        }
    }

    public static By getRowByData(String data) {
        return By.xpath("//table//tbody//tr[.//td[contains(normalize-space(),'" + data + "')]]");
    }

// CLEAR SEARCH 
    @And("user clears search box")
    public void user_clears_search_box() {
    	reuseableCode.clickClearSearch();
    }


//  CHECKBOX 
    @When("user selects checkbox for data {string} in table")
    public void select_checkbox(String data) {

        WebElement row = wait.until(ExpectedConditions.visibilityOfElementLocated(getRowByData(data)));

        WebElement checkbox = wait.until(ExpectedConditions.elementToBeClickable(row.findElement(By.xpath(".//input[@type='checkbox']"))));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }
    }

    @Then("selected checkbox data should be displayed {string}")
    public void validate_checkbox_selected_datas(String data) {

        WebElement row = DriverFactory.getDriver().findElement(getRowByData(data));
        WebElement checkbox = row.findElement(By.xpath(".//input[@type='checkbox']"));

        if (!checkbox.isSelected()) {
            throw new AssertionError("Checkbox not selected for id: " + data);
        }
    }

    // EDIT BUTTON
    @And("user clicks edit button")
    public void user_clicks_edit_button() {
    	reuseableCode.clickEditBtn();
    }

    //  UPDATE BUTTON
    @And("user clicks update button")
    public void user_clicks_update_button_common() {
    	reuseableCode.clickUpdateBtn();
    }
    
    //  SAVE BUTTON
    @And("user clicks save button")
    public void user_clicks_save_button_common() {
    	reuseableCode.clickSaveBtn();
    }

// DELETE BUTTON 
    @And("user clicks on delete button")
    public void user_clicks_delete_button() {
    	reuseableCode.clickDeleteBtn();
    }

    @And("user clicks on Confirmation ok")
    public void user_clicks_confirmation_ok_button() {
    	reuseableCode.clickOKBtn();
    }

    @And("user clicks on Confirmation Cancel")
    public void user_clicks_confirmation_cancel_button() {
    	reuseableCode.clickCancelBtn();
    }

// RESET PASSWORD  BUTTON
    @And("user clicks on reset password button")
    public void user_clicks_reset_password_button() {
    	reuseableCode.clickResetPasswordBtn();
    }
    
 // LOGOUT BUTTON
    @And("user clicks on Logout")
    public void user_clicks_logout() {
    	reuseableCode.clickLogout();
    }
    
  // HOME BUTTON
    @And("user clicks on home")
    public void user_clicks_home() {
    	reuseableCode.clickHome();
    }
  
//  AFTER RESET PASSWORD USER MASTER
    //  USER NAME 
    @And("user enters username {string}")
    public void user_enters_username(String name) {
    	reuseableCode.enterUserNameId(name);
    }  
    //USER PASSWORD
    @And("user enters password {string}")
    public void user_enters_userPassword(String pass) {
    	reuseableCode.enterUserPassword(pass);
    }
    // SIGN IN BUTTON 
    @And("clicks on signin button")
    public void user_clicks_signin_button() {
        reuseableCode.clickSigninBtn();
    }
    //  SAVE BUTTON IN RESET PASSWORD
    @And("user clicks save button in reset")
    public void user_clicks_save_button_in_reset_password() {
    	reuseableCode.clickSaveBtnResetPass();
    }
    
//  REPORTS
    // BUTTON CLICK ACTION
    @And("user clicks on {string} option")
    public void user_clicks_on_option(String option) {
        reuseableCode.clickOption(option);
    }   
    
//  PAGINATION
    
    @And("user clicks on Next button")
    public void click_next() {
        reuseableCode.clickNext();
    }

    @And("user clicks on Previous button")
    public void click_previous() {
        reuseableCode.clickPrevious();
    }

    @And("user clicks on page {string}")
    public void click_page(String page) {
        reuseableCode.clickPage(page);
    }

    @Then("page {string} should be active")
    public void verify_active_page(String page) {
        reuseableCode.verifyActivePage(page);
    }

    @Then("Previous button should be disabled")
    public void verify_previous_disabled() {
        Assert.assertTrue(reuseableCode.isPreviousDisabled());
    }
    
// EXPORT EXCEL BUTTON   
    @And("user clicks on Export button")
    public void click_export() {
        reuseableCode.clickExport();
    }
    
//SCREENSHOT    
    @Then("screenshot should be captured {string}")
    public void take_screenshot(String fileName) {
    	reuseableCode.takeScreenshot(fileName);
    }
    
//FILE DOWNLOAD  
//    @Then("file should be downloaded successfully")
//    public void verify_file_download() {
//    	Assert.assertTrue(reuseableCode.isFileDownloaded(), "File not downloaded!");
//    }
    @Then("file {string} should be downloaded successfully")
    public void verify_file_download(String fileName) {

        Assert.assertTrue(
            reuseableCode.isFileDownloaded(fileName),
            fileName + " not downloaded!"
        );
    }

    
//  INSIDE CLINICAL RECORDS MODULE
    
//  ENTER OID 
    @And("user enters OID {string} common")
    public void user_enters_OID_common(String oid) {
    	reuseableCode.enterOid(oid);
    }  
// POPUP DISPLAY   
	@Then("popup {string} should be displayed")
	public void popup_displayed(String popupNAme) {
		reuseableCode.popupDisplay(popupNAme);
	}
	
// ERROR MESSEGE OR ALERT MESSEGE COMMON
	@Then("error message {string} should be displayed")
	public void error_messege(String errorMsg) {
		reuseableCode.errorMsgValidation(errorMsg);
	}
    
// FILTERED OPTION CLICK
  @And("user clicks filtered option")
  public void user_clicks_filtered_option() {
    	reuseableCode.clickClinicalOption();
  }   
  

    
// LABEL ACTIONS LIKE VISION , INVESTIGATION,COMPLAINETS ...  CLICK
@And("user clicks {string} label option")
public void user_clicks_label_option(String button) {
	   reuseableCode.clickLabelButton(button);
}
    
//FLEX BUTTON
@And("user clicks {string} flex button for {string}")
public void user_clicks_flex_button(String button, String eye) {
    reuseableCode.clickFlexButton(button, eye);
}   
    
//  BUTTON CLICK ACTION
@And("user clicks {string} button")
public void user_clicks_button(String button) {
	   reuseableCode.clickButtonOrg(button);
}
    
   
// VISION BUTTONS
@And("user clicks {string} button in vision")
public void user_clicks_button_vision(String button) {
	reuseableCode.clickBtnVision(button);
} 

//WINDOW BUTTONS
@And("user clicks {string} button in window")
public void user_clicks_button_window(String button) {
	reuseableCode.clickBtnWindow(button);
}
        
//REASON FOR REFERRAL BUTTONS
@And("user clicks {string} button in referral advice")
public void user_clicks_button_reason_for_referral_advice(String button) {
	reuseableCode.clickBtnReferralAdvice(button);
}    
    
// REMARKS 
@And("user enters remarks {string}")
public void user_enters_remarks(String remark) {
	reuseableCode.enterRemark(remark);
}

//CHECK BOX
@And("user clicks checkbox")
public void user_clicks_checkbox() {
	reuseableCode.checkboxClick();
}

// NO ITEMS FOUND IN DROPDOWN
@Then("no items found message should be displayed in dropdown")
public void no_items_found_message_should_be_displayed_in_dropdown() {
	reuseableCode.validateNoItemsFoundMessage();
}

// ALERT ERROR MESSEGE DISPLAY
@Then("{string} toast should be displayed")
public void error_toast_should_be_displayed(String expectedMsg) {
	reuseableCode.validateToastMessage(expectedMsg);
} 

// WAIT TIME
@And("user waits for {string} seconds")
public void user_waits_for_seconds(String seconds) throws InterruptedException {
    int time = Integer.parseInt(seconds);
    Thread.sleep(time * 1000);
}

// RESET PASSWORD IN USER MASTER
@And("user clicks save button and validates old password error")
public void user_clicks_save_and_validates_old_password() {
	reuseableCode.clickSaveAndValidateOldPassword();
}

// PRINT PREVIEW 
@And("user clicks {string} button in preview")
public void user_clicks_button_in_Preview(String button) {
	reuseableCode.clickPrintPreviewBtn(button);
}

// CHECK BOX LOOKS LIKE BUTTON IN INVESTIGATION
@And("I click {string} checkbox")
public void click_checkbox_button(String button) {
	reuseableCode.ClickCheckboxBtn(button);
}
    
//COMMON SYATEM ALERT MESSAGE BUTTON CLICK ACTION
@And("get alert msg and click {string} for alert from system")
public void click_System_alert_action_buttons(String button) {
	reuseableCode.ClickSystemAlertBtn(button);
}

//COMMON INVALID ALERT FOR RED INDICATION
@And("{string} alert indicating should appear")
public void invalid_alert_appear(String alert) {
	reuseableCode.alertAppear(alert);
}

//STATION OVERVIEW
@And("I click patient station overview section in dashboard")
public void station_overview_in_dashboard() {
	reuseableCode.clickWaitingBadge();
}

//SURGERY ADVISED
@And("I click patient surgery confirmed section in dashboard")
public void surgery_advised_in_dashboard() {
	reuseableCode.clickSurgeryAdviced();
}
    
    
    
    
    
}
