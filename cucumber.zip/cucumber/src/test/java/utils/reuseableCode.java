package utils;

import io.cucumber.java.en.*;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;



public class reuseableCode {

    reuseableCodePage reuseableCode;
    WebDriverWait wait;

    public reuseableCode() {
    	reuseableCode = new reuseableCodePage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(30));
    }
 
// BUTTON CLICK COMMON
    @And("I click {string} button")
    public void click_button(String btn) {
	    	reuseableCode.clickButton(btn);
    }
    
// CLEAR BUTTON
//    @And("I click clear button")
//    public void click_clear_button() {
//	    	reuseableCode.clickClearButton();
//    }
// CANCEL BUTTTON
//    @And("I click cancel button")
//    public void click_cancel_button() {
//	    	reuseableCode.clickCancelButton();
//    }
// CLOSE ICON
    @And("I click close icon")
    public void click_close_icon() {
		reuseableCode.clickCloseButton();
    }
    
// CLOSE BUTTON  
//    @And("I click close button common")
//    public void click_close_button() {
//	    	reuseableCode.clickCloseButtonOrg();
//    }
  
// SUBMIT
//    @And("I click submi button")
//    public void click_submit_button() {
//	    	reuseableCode.clickSubmitButton();
//    }
    
// SEARCH ICON
    @And("I click on Search icon")
    public void click_search_icon() {
	    reuseableCode.clickSearchIcon();
    }
  

// SEARCH BOX
	@And("I enter id in search bar {string}")
	public void enter_id_to_search(String data) {
		reuseableCode.enterIdInSearchBar(data);
	}
	
    @Then("details for id {string} should be displayed")
    public void validate_details_displayed_id_searchbox(String data) {

        WebElement row = wait.until(ExpectedConditions.visibilityOfElementLocated(getRowByData(data)));

        if (!row.isDisplayed()) {
            throw new AssertionError("No data found: " + data);
        }
    }

    public static By getRowByData(String data) {
        return By.xpath("//table//tbody//tr[.//td[contains(normalize-space(),'" + data + "')]]");
    }

// CLEAR SEARCH 
    @And("I clear search box")
    public void clear_search_box() {
    	reuseableCode.clickClearSearch();
    }


//  CHECKBOX 
    @When("I select checkbox for data {string} in table")
    public void select_checkbox(String data) {

        WebElement row = wait.until(ExpectedConditions.visibilityOfElementLocated(getRowByData(data)));

        WebElement checkbox = wait.until(ExpectedConditions.elementToBeClickable(row.findElement(By.xpath(".//input[@type='checkbox']"))));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }
    }

    @Then("selected checkbox data should be displayed {string}")
    public void validate_checkbox_selected_datas(String data) {

        WebElement row = DriverFactory.getDriver().findElement(getRowByData(data));
        WebElement checkbox = row.findElement(By.xpath(".//input[@type='checkbox']"));

        if (!checkbox.isSelected()) {
            throw new AssertionError("Checkbox not selected for id: " + data);
        }
    }

    // EDIT BUTTON
    @And("I click edit button")
    public void click_edit_button() {
    	reuseableCode.clickEditBtn();
    }

    //  UPDATE BUTTON
    @And("I click update button")
    public void click_update_button_common() {
    	reuseableCode.clickUpdateBtn();
    }
    
    //  SAVE BUTTON
    @And("user clicks save button")
    public void click_save_button_common() {
    	reuseableCode.clickSaveBtn();
    }

// DELETE BUTTON 
    @And("I click on delete button")
    public void click_delete_button() {
    	reuseableCode.clickDeleteBtn();
    }

    @And("I click on Confirmation ok")
    public void click_confirmation_ok_button() {
    	reuseableCode.clickOKBtn();
    }

    @And("I click on Confirmation Cancel")
    public void click_confirmation_cancel_button() {
    	reuseableCode.clickCancelBtn();
    }

// RESET PASSWORD  BUTTON
    @And("I click on reset password button")
    public void click_reset_password_button() {
    	reuseableCode.clickResetPasswordBtn();
    }
    
 // LOGOUT BUTTON
    @And("I click on Logout")
    public void click_logout_icon() {
    	reuseableCode.clickLogout();
    }
    
  // HOME BUTTON
    @And("I click on home")
    public void click_home_icon() {
    	reuseableCode.clickHome();
    }
  
//  AFTER RESET PASSWORD USER MASTER
    //  USER NAME 
    @And("I enter username {string}")
    public void enter_username(String name) {
    	reuseableCode.enterUserNameId(name);
    }  
    //USER PASSWORD
    @And("I enter password {string}")
    public void enter_userPassword(String pass) {
    	reuseableCode.enterUserPassword(pass);
    }
    // SIGN IN BUTTON 
    @And("I click on signin button")
    public void click_signin_button() {
        reuseableCode.clickSigninBtn();
    }
    //  SAVE BUTTON IN RESET PASSWORD
    @And("I click save button in reset")
    public void click_save_button_in_reset_password() {
    	reuseableCode.clickSaveBtnResetPass();
    }
    
//  REPORTS
    // BUTTON CLICK ACTION
    @And("I click on {string} option")
    public void click_on_option(String option) {
        reuseableCode.clickOption(option);
    }   
    
//  PAGINATION
    
    @And("I click on Next button")
    public void click_next() {
        reuseableCode.clickNext();
    }

    @And("I click on Previous button")
    public void click_previous() {
        reuseableCode.clickPrevious();
    }

    @And("I click on page {string}")
    public void click_page(String page) {
        reuseableCode.clickPage(page);
    }

    @Then("page {string} should be active")
    public void verify_active_page(String page) {
        reuseableCode.verifyActivePage(page);
    }

    @Then("Previous button should be disabled")
    public void verify_previous_disabled() {
        Assert.assertTrue(reuseableCode.isPreviousDisabled());
    }
    
// EXPORT EXCEL BUTTON   
    @And("I click on Export button")
    public void click_export() {
        reuseableCode.clickExport();
    }
    
//SCREENSHOT    
    @Then("screenshot should be captured {string}")
    public void take_screenshot(String fileName) {
    	reuseableCode.takeScreenshot(fileName);
    }
    
//FILE DOWNLOAD  
    @Then("file should be downloaded successfully")
    public void verify_file_download() {
    	Assert.assertTrue(reuseableCode.isFileDownloaded(), "File not downloaded!");
    }
   

    
//  INSIDE CLINICAL RECORDS MODULE
    
//  ENTER OID 
    @And("I enter OID {string} common")
    public void enter_OID_common(String oid) {
    	reuseableCode.enterOid(oid);
    }  
// POPUP DISPLAY   
	@Then("popup {string} should be displayed")
	public void popup_displayed(String popupNAme) {
		reuseableCode.popupDisplay(popupNAme);
	}
	
// ERROR MESSEGE OR ALERT MESSEGE COMMON
	@Then("error message {string} should be displayed")
	public void error_messege(String errorMsg) {
		reuseableCode.errorMsgValidation(errorMsg);
	}
    
// FILTERED OPTION CLICK
    @And("I click filtered option")
    public void click_filtered_option() {
    	 reuseableCode.clickClinicalOption();
    }   
  

    
// LABEL ACTIONS LIKE VISION , INVESTIGATION,COMPLAINETS ...  CLICK
	 @And("I click {string} label option")
	 public void click_label_option_common(String button) {
		   reuseableCode.clickLabelButton(button);
	 }
    
//FLEX BUTTON
	@And("I click {string} flex button for {string}")
	public void click_flex_button(String button, String eye) {
	    reuseableCode.clickFlexButton(button, eye);
	}   
    
//  BUTTON CLICK ACTION
	@And("I click {string} button common")
	public void click_button_common(String button) {
		   reuseableCode.clickButtonOrg(button);
	}
    
   
// VISION BUTTONS
	@And("I click {string} button in vision")
	public void click_button_vision(String button) {
		reuseableCode.clickBtnVision(button);
	} 

//WINDOW BUTTONS
	@And("I click {string} button in window")
	public void click_button_window(String button) {
		reuseableCode.clickBtnWindow(button);
	}
        
//REASON FOR REFERRAL BUTTONS
	@And("I click {string} button in referral advice")
	public void click_button_reason_for_referral_advice(String button) {
		reuseableCode.clickBtnReferralAdvice(button);
	}    
    
// REMARKS 
	@And("I enter remarks {string}")
	public void enter_remarks(String remark) {
		reuseableCode.enterRemark(remark);
	}

//CHECK BOX
	@And("I click checkbox")
	public void click_checkbox() {
		reuseableCode.checkboxClick();
	}

// NO ITEMS FOUND IN DROPDOWN
	@Then("no items found message should be displayed in dropdown")
	public void no_items_found_message_should_be_displayed_in_dropdown() {
		reuseableCode.validateNoItemsFoundMessage();
	}

// ALERT ERROR MESSEGE DISPLAY
	@Then("{string} toast should be displayed")
	public void error_toast_should_be_displayed(String expectedMsg) {
		reuseableCode.validateToastMessage(expectedMsg);
	} 

// WAIT TIME
	@And("I wait for {string} seconds")
	public void wait_for_seconds(String seconds) throws InterruptedException {
	    int time = Integer.parseInt(seconds);
	    Thread.sleep(time * 1000);
	}

// RESET PASSWORD IN USER MASTER
	@And("I click save button and validates old password error")
	public void click_save_and_validates_old_password() {
		reuseableCode.clickSaveAndValidateOldPassword();
	}

// PRINT PREVIEW 
	@And("I click {string} button in preview")
	public void click_button_in_Preview(String button) {
		reuseableCode.clickPrintPreviewBtn(button);
	}

// CHECK BOX LOOKS LIKE BUTTON IN INVESTIGATION
	@And("I click {string} checkbox")
	public void click_checkbox_button(String button) {
		reuseableCode.ClickCheckboxBtn(button);
	}
    
//COMMON SYATEM ALERT MESSAGE BUTTON CLICK ACTION
	@And("get alert msg and click {string} for alert from system")
	public void click_System_alert_action_buttons(String button) {
		reuseableCode.ClickSystemAlertBtn(button);
	}

//COMMON INVALID ALERT FOR RED INDICATION
	@And("{string} alert indicating should appear")
	public void invalid_alert_appear(String alert) {
		reuseableCode.alertAppear(alert);
	}

//BUTTON DISABLE
	@Then("{string} button should be disable")
	public void button_disabled(String button) {
		reuseableCode.buttonDisableCommon(button);
	}

//	COUNSELLING LINK CLICK
	@And("I click {string} text")
	public void click_text(String text) {
		reuseableCode.counsellingCick(text);
	}
	
// TRASH ICON 
	@And("I click trash icon in {string}")           
	public void click_trash_delete_icon(String section) {
		reuseableCode.deleteIconClick(section);
	}
	
//	VALIDATION MESSAGE
	@Then("I should see {string} validation message")
	public void validation_messege(String section) {
		reuseableCode.verify_validation_message(section);
	}
	
}
