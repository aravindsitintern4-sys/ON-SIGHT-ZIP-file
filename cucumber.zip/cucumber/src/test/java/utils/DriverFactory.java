package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import java.util.HashMap;
import java.io.File;

public class DriverFactory {

	private static ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    public static void initDriver() {

        if (driver.get() == null) {
        	
            // DOWNLOAD PATH  "\\downloads" ---> APPEND WITH PROJECT DIR
            String downloadPath = System.getProperty("user.dir") + "\\downloads";

            // FOLDER CREATE NOT IN FILE EXPLORER DOWNLOADS IT IN MY PROJECT (CHECKS EXSISTING FOLDER IN PROJECT CONTAINS DOWNLOADS
            File dir = new File(downloadPath);
            if (!dir.exists()) {
                dir.mkdirs();
            }

// CHROME PREFERANCES 
           // CONFIGRATION MAP FOR CHROME BEHAVIOUR           
            HashMap<String, Object> prefs = new HashMap<>();
            
            // SAVE ALL THE FILES IN THIS PROJECT FOLDER
            prefs.put("download.default_directory", downloadPath);
            
            // SOMETIMES CONFIRM "SAVE AS" POPUP APPEARS THIS CODE FOR SKIP THAT PROCESS
            prefs.put("download.prompt_for_download", false);
            
            // SAVE THE DOWNLOADED FILES IN SAME FOLDER
            prefs.put("download.directory_upgrade", true);
            
            // ALLOW DOWNLOADS WITHOUT BLOCKING (DON'T BLOCK DOWNLOAD)
            prefs.put("safebrowsing.enabled", true);

            // CHROME OPENS WITH MY CUSTOM SETTINGS
            ChromeOptions options = new ChromeOptions();
            // ACCESS WITH CUSTOM RULES
            options.setExperimentalOption("prefs", prefs);

// BROWSER LAUNCH
            driver.set(new ChromeDriver(options));

            getDriver().manage().window().maximize();
//          getDriver().manage().window();
        }
    }

    public static WebDriver getDriver() {
        return driver.get();
    }

    public static void quitDriver() {
        if (driver.get() != null) {
            driver.get().quit();
            driver.remove(); 
        }
    }
}