package locators;

import org.openqa.selenium.By;

public class editLocator {

	public static By editBtn = By.xpath("//button[@tabindex='31']");
	public static By oidInput = By.xpath("//input[@placeholder='Enter OID']");
	public static By searchIconBtn = By.xpath("//button[@class='search-style btn']");
	public static By updateBtn = By.xpath("//button[@class='bg-[#1c94fc] text-white px-6 py-2 rounded hover:opacity-90' and normalize-space()='Update']");
	public static By cancelBtn = By.xpath("//button[contains(text(),'Cancel')]"); 
	public static By updateRegBtn = By.xpath("//button[@tabindex='26' and normalize-space()='Update']");
	


}
