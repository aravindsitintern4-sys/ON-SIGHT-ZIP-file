package locators;


import org.openqa.selenium.By;

public class clinicalRecordsLocator {

	public static By clinicalRecordsOption = By.cssSelector("a[href='#/patient/2']");
    public static By patientStatusSearchOption = By.cssSelector("div.user-name img");
    public static By viewIcon = By.xpath("//app-patient-waiting-list//div[@class='print-view']//span[@class='view-icon']");
    
    public static By stationDropdown = By.xpath("//select[contains(@class,'form-select')]");
    
    public static By visionChart = By.cssSelector("select.on-vis");
    
    public static By dropdownBtn = By.id("dropdownLabelUcvaph");
    
    public static By dropdownVisible = By.xpath("//div[@id='customDropdownUcvaph']//div[contains(@class,'dropdown-content') and not(contains(@style,'display: none'))]");
  
    public static By dropdownBtnUcva = By.id("dropdownLabelUcva");
    
    public static By dropdownVisibleUcva = By.xpath("//div[contains(@class,'dropdown-content') and not(contains(@style,'display: none'))]");
    
    public static By ucvaDropdown = By.xpath("//span[normalize-space()='UCVA:']/following::div[contains(@class,'dropdown-btn')][1]");
    
    public static By ucvaPhDropdown = By.id("dropdownLabelUcvaph");
    
    public static By methodInput =  By.xpath("(//app-onsight-vision//select)[2]");
    
    public static By saveVisBtn  = By.xpath("//app-onsight-vision//button[normalize-space()='Save']");
    
    public static By saveRefBtn = By.xpath("//app-referral-control//button[normalize-space()='Save']");
   
    public static By saveBtn = By.xpath("//button[@type='submit' and normalize-space()='Save']");
    
//  ENTER PIN
	public static By enterPin(String digit) {
	    return By.xpath("//ngb-modal-window//div[@class='pin-buttons']//button[normalize-space()='" + digit + "']");
	}
	
	public static By pinButton(String value) {
	    return By.xpath("//ngb-modal-window//div[contains(@class,'pin-buttons')]//button[normalize-space()='" + value + "']");
    }
	  
    public static By deletePinBtn = By.xpath("//ngb-modal-window//div[contains(@class,'pin-buttons')]//button[i[contains(@class,'fa-delete-left')]]");
    
  
//    UCVA DROPDOWN IN VISION CHART IN VISION
    public static By selectRE(String value) {
        return By.xpath("//div[@id='customDropdownUcva']//div[@class='column'][1]//div[normalize-space()='" + value + "']");
    }

    public static By selectLE(String value) {
        return By.xpath("//div[@id='customDropdownUcva']//div[@class='column'][2]//div[normalize-space()='" + value + "']");
    }
    
//  UCVAph DROPDOWN IN VISION CHART IN VISION
    public static By selectREph(String value) {
        return By.xpath("//div[@id='customDropdownUcvaph']//div[contains(@class,'dropdown-content')]//div[@class='column'][1]//div[normalize-space()='" + value + "']");
    }
    
    public static By selectLEph(String value) {
        return By.xpath("//div[@id='customDropdownUcvaph']//div[contains(@class,'dropdown-content')]//div[@class='column'][2]//div[normalize-space()='" + value + "']");
    }
    

// INVESTIGATION  
 
    //IOP
    public static By IOPREInput = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='IOP']]//input[@placeholder='mm of Hg'])[1]");
    public static By IOPLEInput = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='IOP']]//input[@placeholder='mm of Hg'])[last()]");
    
    public static By IOPREdropdown = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='IOP']]//select)[1]");
    public static By IOPLEdropdown = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='IOP']]//select)[2]");
    
    // DUCT
    
    public static By Duct_RE_Lower = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Duct']]//select)[1]");
    public static By Duct_RE_Upper = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Duct']]//select)[2]");

    public static By Duct_LE_Lower = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Duct']]//select)[3]");;
	public static By Duct_LE_Upper = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Duct']]//select)[4]");
    
	// ROPLAS
	
	public static By Roplas_RE = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Roplas']]//select)[1]");
	public static By Roplas_LE = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Roplas']]//select)[2]");
    
	// BLOOD SUGAR
	
	public static By BloodSugar_Type = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Blood Sugar']]//select)[1]");
	public static By BloodSugar_Value = By.xpath("//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Blood Sugar']]//input[@placeholder='mg%']");
	public static By BloodSugar_Location = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Blood Sugar']]//select)[2]");
	public static By BloodSugar_Date = By.xpath("//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Blood Sugar']]//input[@type='date']");

	// BLOOD PRESSURE
	
	public static By BP_Systolic = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Blood Pressure']]//input[@placeholder='mm Hg'])[1]");
	public static By BP_Diastolic = By.xpath("(//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='Blood Pressure']]//input[@placeholder='mm Hg'])[2]");
	
	
    public static By SaveIcon(String name) {
    	return By.xpath("//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='"+name+"']]//i[@title='Save']");
    }
    
    public static By DeleteIcon(String name) {
    	return By.xpath("//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='"+name+"']]//i[@title='Delete']");
    }
    
    public static By EditIcon(String name) {
    	return By.xpath("//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='"+name+"']]//i[@title='Edit']");
    }
    
    public static By RepeatIcon(String name) {
    	return By.xpath("//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='"+name+"']]//i[@title='Repeat']");
    }
  
    public static By PlusIcon(String name) {
        return By.xpath("//div[contains(@class,'table-dynamic-data')][.//div[normalize-space()='"+name+"']]//i[contains(@class,'fa-plus-circle')]");
    }
    
    public static By IOP_SummaryText(String name) {
        return By.xpath("//app-summary-details-display//div[.//div[normalize-space()='"+name+"']]//span");
    }
    
// COMPLAINTS 
    
    public static By eyeForComplaint(String complaint, String eye) {
        return By.xpath("//*[contains(text(),'" + complaint + "')]/following::label[normalize-space()='" + eye + "'][1]");
    }
      
    public static By selectComplaints(String complaints) {
        return By.xpath("//label[normalize-space()='"+complaints+"']");
    }
    
    public static By selectDurationValueComplaints(String value) {
        return By.xpath("//app-complaint-control-v2//button[normalize-space()='"+value+"']");
    }
   
    public static By selectDurationTypeComplaints(String type) {
        return By.xpath("//app-complaint-control-v2//button[normalize-space()='"+type+"']");
    }
    
    public static By durationOpen (String complaint) {
    	return By.xpath("//div[contains(@class,'popular-button')][.//label[normalize-space()='"+complaint+"']]//div[contains(text(),'Duration')]");
    }
    
    public static By durationPanel() {
        return By.xpath("//div[contains(@class,'duration-wid-controlone') and contains(@style,'display: block')]");
    }
    
    public static By durationValue(String value) {
        return By.xpath("//div[contains(@class,'duration-wid-controlone') and contains(@style,'display: block')]//div[contains(@class,'numbers')]//button[normalize-space()='"+value+"']");
    } 
    
    public static By durationType(String type) {
        return By.xpath("//div[contains(@class,'duration-wid-controlone') and contains(@style,'display: block')]//div[contains(@class,'numbers')]//button[normalize-space()='"+type+"']");
    }
    
    public static By durationBtn(String button) {
        return By.xpath("//div[contains(@class,'duration-wid-controlone') and contains(@style,'display: block')]//button[normalize-space()='"+button+"']");
    }
    
    public static By invalidDurationMsg =By.xpath("//div[contains(text(),'Invalid Duration')]");
    
    public static By complaintTextArea = By.xpath("//textarea[contains(@class,'textarea-compliant-wb')]");
    
    public static By deleteConfirmBtn(String btn) {
    		return By.xpath("//button[contains(text(),'"+btn+"')]");
    }
    
    public static By dropdownPannelComplaints = By.xpath("//ng-select[@placeholder='All Complaints']");
	public static By dropdownInput = By.xpath("//ng-select[contains(@class,'ng-select-opened')]//input");
    
	public static By durationOpenBtn = By.xpath("//div[contains(@class,'duration-con-comp')]//div[contains(@class,'selected')]");
    
	public static By durationValueAllComplaints(String value) {
	    return By.xpath("(//duration-control-v2//div[contains(@class,'numbers') and contains(@class,'ng-star-inserted')])[last()]//button[normalize-space()='" + value + "']");
	}

	public static By durationTypeAllComplaints(String type) {
	    return By.xpath("(//duration-control-v2//div[contains(@class,'numbers')])[last()]//button[normalize-space(.)='" + type + "']");
	}

	public static By durationBtnAllComplaints(String button) {
	    return By.xpath("(//duration-control-v2//div[contains(@class,'numbers')])[last()]//button[normalize-space(.)='" + button + "']");
	}
   
// COMPLAINT SUMMARY
//	app-complaint-ocular-history-summary
    
	public static By ComplaintSummary =By.xpath("//app-complaint-ocular-history-summary");
    
	public static By ComplaintSummaryDeleteIcon = By.cssSelector("app-complaint-ocular-history-summary span.sur-adv-del i[class*='fa-trash']");

	public static By ComplaintSummaryInfoIcon = By.xpath("//div[@id='complaints-section']//span[contains(@class,'info-btn')]");
    
	public static By complaintInfoByName(String name) {
        return By.xpath("//app-complaint-ocular-history-summary//div[contains(text(),'" + name + "')]");
    }
    
	
// SYSTEMIC HISTORY
	public static By systemicHistoryOption(String label, String option) {
	    return By.xpath("//div[contains(@class,'history_label')]//span[contains(normalize-space(),'" + label + "')]/ancestor::div[contains(@class,'history_label')]//label[normalize-space()='" + option + "']");
	}
    
	public static By durationValueHistory(String value) {
	    return By.xpath("(//systemic-duration-control//div[contains(@class,'numbers') and contains(@class,'ng-star-inserted')])[last()]//button[normalize-space()='" + value + "']");
	}

	public static By durationTypeHistory(String type) {
	    return By.xpath("(//systemic-duration-control//div[contains(@class,'numbers')])[last()]//button[normalize-space(.)='" + type + "']");
	}

	public static By durationBtnHistory(String button) {
	    return By.xpath("(//systemic-duration-control//div[contains(@class,'numbers')])[last()]//button[normalize-space(.)='" + button + "']");
	}
	
	public static By additionalInfoInput(String label) {
	    return By.xpath("//div[contains(@class,'history_label')]//span[contains(normalize-space(),'" + label + "')]/ancestor::div[contains(@class,'history_label')]//input[@formcontrolname='remarks']");
	}
    
	public static By otherAllergyInput = By.xpath("//input[@placeholder='Enter the Other Allergies']");
    
	public static By drugDropdown = By.xpath("//ng-select[@formcontrolname='historyOthers']");
    public static By drugNameInput = By.xpath("//ng-select[@formcontrolname='historyOthers']//input[@role='combobox' and @type='text']");
    
// SYSTEMIC HISTORY SUMMARY
// 	app-complaint-ocular-history-summary
     
    public static By HistorySummary =By.xpath("//app-systemic-history-summary");
     
 	public static By HistorySummaryInfoIcon = By.xpath("//div[@id='complaints-section']//span[contains(@class,'info-btn')]");
 	
 	public static By HistoryInfoByName(String name) {
         return By.xpath("//app-systemic-history-summary//div[contains(text(),'" + name + "')]");
     }
     
 	public static By clearBtnHistory = By.xpath("//ngb-modal-window//div[contains(@class,'btn_wid_rr')]//button[normalize-space()='Clear']");

 	public static By mandatoryAlertMsg = By.xpath("//div[contains(text(),'Mandatory')]");
     
 
// ANTERIOR SEGMENT
 	
 	public static By selectFullOptionAntiSegment(String segment, String option) {
        return By.xpath("//app-onsight-anterier-control//*[contains(text(),'" + segment + "')]/following::label[normalize-space()='" + option + "'][1]");
    }
 	
 	public static By selectOptionAntiSegment(String segment, String eye, String option) {
 	    return By.xpath(
 	           "//app-onsight-anterier-control" +
 	        	        "//div[contains(@class,'ant-check') and .//span[normalize-space()='" + segment + "']]" +
 	        	        "//div[contains(@class,'items-center') and .//label[normalize-space()='" + option + "']]" +
 	        	        "//label[normalize-space()='" + eye + "']");
 	}
 	
 	public static By remarkInputAnteriorSegment(String eye) {
 	    return By.xpath("//app-onsight-anterier-control//input[@placeholder='Enter " + eye + " Remarks(Max 200 chars)']");
 	}
 	
 	public static By updateBtnExamination = By.xpath("//button[normalize-space()='Update']");
 	
// ANTERIOR SEGMENT SUMMARY

     
    public static By AntiSegmentSummary = By.xpath(
    	    "//span[normalize-space()='Ant. Segment']"
    		);
     
 	public static By AntiSegmentSummaryInfoIcon = By.xpath(
 		    "//span[normalize-space()='Examination & Findings']" +
 		    	    "/following-sibling::div//span[contains(@class,'info-btn')]"
 		    	);
 	
 	public static By AntiSegmentInfoByName(String name) {
         return By.xpath("//div[contains(text(),'" + name + "')]");
     } 
     
 	public static By AntiSegmentSummaryDeleteIcon = By.xpath(
 		    "//span[normalize-space()='Ant. Segment']" +
 		    	    "/ancestor::div[contains(@class,'anterior-summary')]" +
 		    	    "//span[i[contains(@class,'fa-trash')]]"
 		    	);
 	
 	public static By clearBtnExamination = By.xpath("//app-onsight-anterier-fundus-diagnosis-control//button[normalize-space()='Clear']");
 	
 	public static By saveBtnExamination =  By.xpath("//app-onsight-anterier-fundus-diagnosis-control//button[normalize-space()='Save']");
    
    
    
// FUNDUS
 	
 	public static By selectFullOptionFundus(String segment, String option) {
        return By.xpath("//app-onsight-fundus-control//*[contains(text(),'" + segment + "')]/following::label[normalize-space()='" + option + "'][1]");
    }
 	
 	public static By selectOptionFundus(String segment, String eye, String option) {
 	    return By.xpath(
 	           "//app-onsight-fundus-control" +
 	        	        "//div[contains(@class,'ant-check') and .//span[normalize-space()='" + segment + "']]" +
 	        	        "//div[contains(@class,'items-center') and .//label[normalize-space()='" + option + "']]" +
 	        	        "//label[normalize-space()='" + eye + "']"
 	        	    );
 	}
 	
 	public static By remarkInputFundus(String eye) {
 	    return By.xpath("//app-onsight-fundus-control//input[contains(@placeholder,'" + eye + "') and contains(@placeholder,'Remarks')]");
 	}

// FUNDUS SUMMARY
    
    public static By FundusSummary = By.xpath(
    	    "//span[normalize-space()='Fundus']"
    		);
     
 	public static By FundusSummaryInfoIcon = By.xpath(
 		    "//span[normalize-space()='Examination & Findings']" +
 		    	    "/following-sibling::div//span[contains(@class,'info-btn')]"
 		    	);
 	
 	public static By FundusInfoByName(String name) {
         return By.xpath("//div[contains(text(),'" + name + "')]");
     } 
     
 	public static By FundusSummaryDeleteIcon = By.xpath(
 			"//span[normalize-space()='Fundus']" +
 			"/ancestor::div[@id='fundus-section']" +
 			"//i[contains(@class,'fa-trash')]");
    

// DIAGNOSIS
 	
 	public static By selectOptionDiagnosis(String diagnosis, String eye) {
        return By.xpath("//app-diagnosis-control//*[contains(text(),'" + diagnosis + "')]/following::label[normalize-space()='" + eye + "'][1]");
    }
 	
    public static By selectFullOptionDiagnosis(String diagnosis) {
        return By.xpath("//app-diagnosis-control//label[normalize-space()='"+diagnosis+"']");
    }
 	
 	public static By remarkInputDiagnosis(String eye) {
 	    return By.xpath("//app-diagnosis-control//input[@placeholder='Enter " + eye + " Remarks(Max 200 chars)']");
 	}
 	
 	
 	public static By selectDropdownDiagnosis = By.xpath("//app-dropdown-search[@formcontrolname='diagName']//input[@role='combobox']");
 	
 	public static By AlertMsgDiagosis = By.xpath("//app-diagnosis-control//span[contains(text(),' is not allowed for ')]");
 	
 	public static By optionOtherDiagnosisDropdown(String diagnosis) {
 		return By.xpath("//ng-dropdown-panel//div[@role='option']//span[contains(text(),'" + diagnosis + "')]");
 	}
 	
 	public static By otherDiagnosisEyeType(String eye) {
 		return By.xpath("//app-set-of-radio//label[normalize-space()='"+eye+"']");
 	}
 	
// DIAGNOSIS SUMMARY
    
    public static By DiagnosisSummary = By.xpath("//span[normalize-space()='Diagnosis']");
     
 	public static By DiagnosisSummaryInfoIcon = By.xpath(
 		    "//span[normalize-space()='Examination & Findings']" +
 		    	    "/following-sibling::div//span[contains(@class,'info-btn')]");
 	
 	public static By DiagnosisInfoByName(String name) {
         return By.xpath("//div[contains(text(),'" + name + "')]");
     } 
     
 	public static By DiagnosisSummaryDeleteIcon = By.xpath(
 			"//span[normalize-space()='Diagnosis']" +
 			"/ancestor::div[contains(@class,'relative')]" +
 			"//app-diagnosis-summary" +
 			"//i[contains(@class,'fa-trash')]"
 		);    
    
    
//ADVICE 
 	
 	
// REFERRAL ADVICE MODULE
    public static By hospitalInput = By.xpath("//ng-select[@formcontrolname='hospital' and @bindlabel='referralCenterName']");
    public static By hosInput = By.xpath("//ng-select[@formcontrolname='hospital' and @bindlabel='referralCenterName']//input[@role='combobox' and @type='text']");
    
    public static By clinicInput = By.xpath("//ng-select[@bindlabel='clinicName']");
    public static By cliInput = By.xpath("//ng-select[@bindlabel='clinicName']//input[@role='combobox' and @type='text']");
    
    public static By reasonInput = By.xpath("//ng-select[@bindlabel='reasonText']");
    public static By reasonRefInput = By.xpath("//ng-select[@bindlabel='reasonText']//input[@role='combobox' and @type='text']");
    
    public static By buttonByText(String btnName) {
        return By.xpath("//app-referral-control//button[normalize-space()='" + btnName + "' and @disabled]");
    }
    
    public static By hospitalNameerrorMsg =By.xpath("//span[contains(@class,'red-fnt') and contains(normalize-space(),'Please select Hospital')]");
    public static By clinicNameerrorMsg =By.xpath("//span[contains(@class,'red-fnt') and contains(normalize-space(),'Please select Clinic')]");
    public static By reasonForReferrorMsg =By.xpath("//span[contains(@class,'red-fnt') and contains(normalize-space(),'Please select at least one Referral Reason')]");
    
// REFERRAL ADVICE SUMMARY 
    public static By ReferralSummary =By.xpath("//app-referral-summary");
    
    public static By ReferralSummaryDeleteIcon = By.cssSelector("app-referral-summary span.sur-adv-del i.fa-trash");

    public static By ReferralSummaryPrintIcon = By.xpath("//app-referral-summary//i[@class='bi bi-printer']");

    public static By ReferralSummaryInfoIcon = By.xpath("//app-referral-summary//i[@class='fa fa-info']");
    public static By patientInfoByName(String name) {
        return By.xpath("//app-referral-summary//div[contains(@class,'drug-hide1') and contains(text(),'" + name + "')]");
    } 	
    

// DRUG PRESCRIPTION ADVICE
    
    public static By selectOptionDrug(String drug, String eye) {
        return By.xpath("//*[contains(text(),'" + drug + "')]/parent::div//button[normalize-space()='" + eye + "']");
    }
 	
    public static By selectFullOptionDrug(String diagnosis) {              
        return By.xpath("//app-drug-control//label[normalize-space()='"+diagnosis+"']");
    }   
    
    public static By selectEyeType = By.xpath("//app-drug-control//select[option[contains(text(),'Select Eye')]]");
    
    public static By drugNameDropdown = By.xpath("//ng-select[@bindlabel='label']");
    
    public static By drugNameDropdownInput = By.xpath("//ng-select[@bindlabel='label']//input[@role='combobox' and @type='text']");
    
    public static By selectFrequency = By.xpath("//app-drug-control//select[option[contains(text(),'Frequency')]]");
    
    public static By DurationInputDP = By.xpath("//app-drug-control//input[@placeholder='Duration']");
    
    public static By selectDurationType = By.xpath("//ngb-modal-window//select[option[text()='Days']]");
    
    public static By enterRemarksDP = By.xpath("//app-drug-control//input[@placeholder='Enter the Remarks']");
    
    public static By deleteIcon(String drugName) {
        return By.xpath("//div[contains(@class,'row')][.//span[contains(.,'" + drugName + "')]]//i[contains(@class,'fa-trash')]");
    }
    
    public static By selectPresLanguage = By.xpath("//div[contains(@class,'lang-selector')]//select");
    
    public static By DPButtons(String btn) {
        return By.xpath("//app-drug-control//button[normalize-space()='"+btn+"']");
    }
    
// DP ADVICE SUMMARY 
    public static By DPSummary =By.xpath("//app-drug-summary");
    
    public static By DPSummaryDeleteIcon = By.cssSelector("app-drug-summary span.sur-adv-del i.fa-trash");

    public static By DPSummaryPrintIcon = By.xpath("//app-drug-summary//i[@class='bi bi-printer']");

    public static By DPSummaryInfoIcon = By.xpath("//app-drug-summary//i[@class='fa fa-info']");    
    
    public static By patientInfoByNameDP(String name) {
        return By.xpath("//app-drug-summary//div[contains(@class,'drug-hide1') and contains(text(),'" + name + "')]");
    } 
    
    
// SURGERY ADVICE
    
    public static By selectEyeTypeSurgery(String label, String eye) {
        return By.xpath("//app-onsight-surgeryadvice//*[contains(text(),'" + label + "')]/following::label[normalize-space()='" + eye + "'][1]");
    }
    
    public static By surgeryNameDropdown = By.xpath("//app-onsight-surgeryadvice//ng-select[@bindlabel='values']");
    public static By surgeryNameDropdownInput = By.xpath("//app-onsight-surgeryadvice//ng-select[@bindlabel='values']//input[@role='combobox' and @type='text']");
    
    public static By remarkInputSurgery = By.xpath("//app-onsight-surgeryadvice//textarea[@id='remarks']");
    
    public static By dateInputSurgery = By.xpath("//app-onsight-surgeryadvice//input[@id='sx_date']");
    
    public static By surgeryReasonDropdown = By.xpath("//app-onsight-surgeryadvice//ng-select[@placeholder='Select reason']");
    public static By surgeryReasonDropdownInput = By.xpath("//app-onsight-surgeryadvice//ng-select[@placeholder='Select reason']//input[@role='combobox' and @type='text']");
    
    public static By SurgeryButtons(String btn) {
        return By.xpath("//app-onsight-surgeryadvice//button[normalize-space()='"+btn+"']");
    }
    
    public static By SurgeryCounsellingButtons(String btn) {
        return By.xpath("//app-onsight-surgeryadvice//div[contains(@class,'col-sm-5')]//button[normalize-space()='"+btn+"']");
    }
    
 // SURGERY ADVICE SUMMARY
    
    public static By CounsellingLink(String link) {
        return By.xpath("//app-onsight-surgeryadvice-summary//span[normalize-space()='"+link+"']");
    }
    
    public static By SurgerySummary =By.xpath("//app-onsight-surgeryadvice-summary");
    
    public static By SurgerySummaryDeleteIcon = By.cssSelector("app-onsight-surgeryadvice-summary span.sur-adv-del i.fa-trash");

    public static By SurgerySummaryInfoIcon = By.xpath("//app-onsight-surgeryadvice-summary//i[@class='fa fa-info']");    
    
    public static By patientInfoByNameSurgery(String name) {
        return By.xpath("//app-onsight-surgeryadvice-summary//div[contains(@class,'drug-hide1') and contains(text(),'" + name + "')]");
    } 
    
//REFRACTION   
    
    public static By refractionOption(String btn) {
    	 return By.xpath("//div[contains(@class,'ref-navbar')]//label[contains(.,'" + btn + "')]");
    }
    
    public static By selectLabelOptions(String label, String option) {
        return By.xpath("//app-refraction-control//*[contains(text(),'" + label + "')]/following::label[normalize-space()='" + option + "'][1]");
    }
    
    public static By dropdownByLabelCS1(String labelName) {
        return By.xpath("//app-refraction-control//label[normalize-space()='" + labelName + "']/following::ng-select[1]");
    }
    
    public static By ngselectDropdownCS1 = By.xpath("//app-refraction-control//ng-select[@bindlabel='value']");
    
    public static By dropdownOptionCS1(String option) {
        return  By.xpath("//ng-dropdown-panel//span[normalize-space()='" + option + "']");
    }
      
    public static By inputFieldByLabel(String labelName) {
        return By.xpath(
            "//label[normalize-space()='" + labelName + "']" +
            "/ancestor::div[contains(@class,'fl-lft-du')]" +
            "//app-text-box-control//input[@type='text']");
    }
    
    public static By RefractionButtons(String btn) {
        return  By.xpath("//app-refraction-control//button[normalize-space()='" + btn + "']");
    }

    public static By durationValueRefraction(String value) {
	    return By.xpath("(//app-refraction-control//div[contains(@class,'numbers') and contains(@class,'ng-star-inserted')])[last()]//button[normalize-space()='" + value + "']");
	}

	public static By durationTypeRefraction(String type) {
	    return By.xpath("(//app-refraction-control//div[contains(@class,'numbers')])[last()]//button[normalize-space(.)='" + type + "']");
	}

	public static By durationBtnRefraction(String button) {
	    return By.xpath("(//app-refraction-control//div[contains(@class,'numbers')])[last()]//button[normalize-space(.)='" + button + "']");
	}
	
	public static By durationFieldRefraction = By.xpath("//app-refraction-control//duration-control[@id='usageDuration']");
    
	public static By dropdownBySelectLabelCS1(String labelName) {
	    return By.xpath("//label[normalize-space()='" + labelName + "']/following::select[1]");
	}

//	public static By dropdownByTwoLabels(String parentLabel, String childLabel) {
//	    return By.xpath(
//	    		"//div[contains(@class,'wid_100')]" +
//		        "[.//div[normalize-space()='" + parentLabel + "']]" +
//		        "//div[contains(normalize-space(),'" + childLabel + "')]" +
//		        "/following::select[1]");
//	}
	public static By dropdownByTwoLabels(String parentLabel, String childLabel) {
	    return By.xpath(
	        "//div[contains(@class,'wid_100')]" +
	        "[.//div[contains(normalize-space(),'" + parentLabel.replace(":", "").trim() + "')]]" +
	        "//div[contains(normalize-space(),'" + childLabel.replace(":", "").trim() + "')]" +
	        "/following-sibling::div//select");
	}
	
	 
	public static By inputFieldTwoLabels(String parentLabel, String childLabel) {
		return By.xpath(
		        "//*[self::div or self::label][normalize-space()='" + parentLabel + "']" +
		                "/ancestor::*[contains(@class,'col') or contains(@class,'wid') or self::div][1]" +
		                "//*[self::div or self::label][normalize-space()='" + childLabel + "']" +
		                "/following::input[@type='text'][1]");
	}
	
	public static By inputFieldTwoLabelsRepeat(String parentLabel, String childLabel) {
	    return By.xpath(
	        "//div[contains(@class,'wid_100')]" +
	        "[.//div[contains(normalize-space(),'" + parentLabel.replace(":", "").trim() + "')]]" +
	        "//div[contains(normalize-space(),'" + childLabel.replace(":", "").trim() + "')]" +
	        "/following::input[1]");
	}
	
	
	
    
	public static By dropdownTwoLabelsNGSelectCS1(String parentLabel, String childLabel) {
	    return By.xpath(
	        "//app-refraction-control" +
	        "//div[contains(@class,'wid_100')][.//div[normalize-space()='" + parentLabel + "']]" +
	        "//div[contains(normalize-space(),'" + childLabel + "')]" +
	        "/following::ng-select[1]");
	}
	
	public static By ngselectDropdownTwoTablesCS1 = By.xpath("//app-refraction-control//ng-select[@bindlabel='value']");
    
	public static By dropdownTwoLabelsOptionCS1(String option) {
        return  By.xpath("//ng-dropdown-panel//span[normalize-space()='" + option + "']");
    }
	
// REFRACTION VALUES ----> CURRENT SPECTACLES(1)
	 private static int getColumnIndex(String fieldName) {
	     switch (fieldName.toLowerCase()) {
	         case "spherical": return 1;
	         case "cylinder": return 2;
	         case "axis": return 3;
	         case "v/a with cs": return 4;
	         case "+spherical": return 5;
	         case "nv": return 6;
	         default:
	             throw new IllegalArgumentException("Invalid field: " + fieldName);
	     }
	 }
	
	 // Input Box (RE / LE based)
	 public static By inputBox(String eye, String fieldName) {
	     int colIndex = getColumnIndex(fieldName);
	     return By.xpath(
	         "//span[normalize-space()='" + eye + "']" +
	         "/ancestor::div[contains(@class,'vert-center')]" +
	         "//div[contains(@class,'col-sm-2')][" + colIndex + "]//input");
	 }
	 
	// COMMON BASE
	public static String base(String eye) {
	  return "//span[text()='" + eye + "']/ancestor::div[contains(@class,'row')]";
	}
	
//	//ROW 
	public static By eyeRow(String eye) {
	 return By.xpath("//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]");
	}	

	
	// SIGN (+ / -) 
	public static By signBtn(String eye, String column, String sign) {
	    return By.xpath(
	        "//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]" +
	        "//app-radio[contains(@formcontrolname,'" + column.toLowerCase() + "Sign')]" +
	        "//label[normalize-space()='" + sign + "']");
	}
	
	// INTEGER 
	public static By integerDropdown(String eye, String column) {
	 return By.xpath(
	     "//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]" +
	     "//select[contains(@id,'" + getColumnId(column) + "Integer')]");
	}
	
	// DECIMAL
	public static By decimalDropdown(String eye, String column) {
	 return By.xpath(
	     "//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]" +
	     "//select[contains(@id,'" + getColumnId(column) + "Decimals')]");
	}
	
	// AXIS
	public static By axisDropdown(String eye) {
	 return By.xpath(
	     "//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]" +
	     "//select[contains(@id,'axisOne')]");
	}
	
	// VA WITH CS 
	public static By vaDropdown(String eye) {
	 return By.xpath(
	     "//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]" +
	     "//select[@id='vaWithPG']");
	}
	public static By vaPButton(String eye) {
	    return By.xpath(
	        "//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]" +
	        "//input[@id='vaWithPGSign']/following-sibling::label");
	}
	
	//NV 
	public static By nvDropdown(String eye) {
	 return By.xpath(
	     "//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]" +
	     "//select[@id='nv']");
	}
	
	//COLUMN ID MAP 
	public static String getColumnId(String column) {
	 switch (column.toLowerCase()) {
	     case "spherical": return "spherical";
	     case "cylinder": return "cylinder";
	     default: return column.toLowerCase();
	 }
	}
		
	// +SPHERICAL 
	public static By nvSphInteger(String eye) {
	 return By.xpath(
	     "//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]" +
	     "//select[contains(@id,'sphericalNvInteger')]");
	}
	
	public static By nvSphDecimal(String eye) {
	 return By.xpath(
	     "//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]" +
	     "//select[contains(@id,'sphericalNvDecimals')]");
	}	
		
	public static By activateEye(String eye) {	
	      return By.xpath("//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]");	
	}	
		
	public static By inputRemarksRefraction = By.xpath("//app-refraction-control//textarea[@formcontrolname='remarks']");
	
	public static By inputRemarksCurrentspec = By.xpath("//app-current-spectacles//textarea[@formcontrolname='remarks']");
	
	public static By mandatoryErrorMsg(String msg) {
//		return By.xpath("//span[contains(@class,'red') and normalize-space()='"+msg+"']");
		return By.xpath("//span[normalize-space()='" + msg + "' and (contains(@class,'red') or contains(@class,'error_msg_rr'))]");
	}
	
	public static By BtnCurrentSpecPart1(String btn) {
        return  By.xpath("//app-current-spectacles//button[normalize-space()='" + btn + "']");
    }
	
	public static By currentSpecPartOneSummaryDisplay = By.xpath("//app-current-spectacles-summary");
	
	public static By BtnDynamicRR(String btn) {
        return  By.xpath("//app-dynamic-rr//button[normalize-space()='" + btn + "']");
    }
	
	public static By undilatedRRSummaryDisplay = By.xpath("//app-dynamic-rr-summary");
	
	public static By subOptionUndilatedRR(String btn) {
	        return By.xpath("//app-subjective-control//label[normalize-space()='" + btn + "']");
	    }
	
	public static By inputFieldByLabelUndialatedRR(String labelName) {
		    return By.xpath(
		        "//app-subjective-control//label[normalize-space()='" + labelName + "']" +
		        "/following::input[@type='text'][1]");
		}
	
	// DIOPTER 90
	public static By diopter90Dropdown = By.xpath("//select[@id='diopterDegree90']");

	public static By diopter90Sign(String sign) {
	    return By.xpath("//input[@id='diopterDegree90Sign" + sign + "']/following-sibling::label");
	}

	public static By diopter90Integer = By.xpath("//select[@id='diopterDegree90Integer']");

	public static By diopter90Decimal = By.xpath("//select[@id='diopterDegree90Decimal']");


	//  DIOPTER 180 
	public static By diopter180Dropdown(String eye) {
	    return By.xpath("//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]//select[@id='diopterDegree180']");
	}

	public static By diopter180Sign(String eye, String sign) {
	    return By.xpath("//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]//label[@for='diopterDegree180Sign" + sign + "']");
	}

	public static By diopter180Integer(String eye) {
	    return By.xpath("//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]//select[@id='diopterDegree180Integer']");
	}

	public static By diopter180Decimal(String eye) {
	    return By.xpath("//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]//select[@id='diopterDegree180Decimal']");
	}


	//  REFLEX 
	public static By reflexDropdown(String eye) {
	    return By.xpath("//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')]//select[@id='typeOfReflex']");
	}

	// SIGN
	public static By diopterSign(String type, String sign) {
	    return By.xpath("//input[@id='diopterDegree" + type + "Sign" + sign + "']/following-sibling::label");
	}
	
	// INTEGER
	public static By diopterInteger(String type) {
	    return By.xpath("//select[@id='diopterDegree" + type + "Integer']");
	}
	
	// DECIMAL
	public static By diopterDecimal(String type) {
	  return By.xpath("//select[@id='diopterDegree" + type + "Decimal']");
	}

	public static By BtnSubRRDV(String btn) {
        return  By.xpath("//app-sub-rr-dv//button[normalize-space()='" + btn + "']");
    }

    public static By ucvaDropdown(String eye) {
        return By.xpath("//app-dropdown-basic[@formcontrolname='ucvaWithPG']//select[@id='ucva']");
    }

    public static By bcvaDropdown(String eye) {
        return By.xpath("//app-dropdown-basic[@formcontrolname='bcvaWithPG']//select[@id='bcva']");
    }

    public static By phBcvaDropdown(String eye) {
        return By.xpath("//app-dropdown-basic[@formcontrolname='phBcvaWithPG']//select[@id='phBcva']");
    }
	    
    public static By ucvaPsign() {
        return By.xpath("//input[@id='ucvaSign']/following-sibling::label[@for='ucvaSign']");
    }
    
    public static By bcvaPsign() {
        return By.xpath("//input[@id='bcvaSign']/following-sibling::label[@for='bcvaSign']");
    }

    public static By phBcvaPsign() {
        return By.xpath("//input[@id='phBcvaSign']/following-sibling::label[@for='phBcvaSign']");
    }
	

	public static By mpdInput(String eye) {
		return By.xpath("//span[normalize-space()='" + eye + "']/ancestor::div[contains(@class,'row')][1]//numeric-input-control//input");
	}
	
	public static By OthersInput(String labelName) {
	    return By.xpath("//label[normalize-space()='" + labelName + "']/following-sibling::input[@type='text']");
	}
	
	public static By BtnSubRRVV(String btn) {
        return  By.xpath("//app-sub-rr-nv//button[normalize-space()='" + btn + "']");
    }
	
	public static By commonOption(String value) {
	    return By.xpath("//div[contains(@class,'cdk-overlay')]//div[normalize-space()='" + value + "']");
	}
	
	public static By ucnvDropdown() {
	    return By.xpath("//app-dropdown-basic[@formcontrolname='ucnv']//select");
	}
	
	public static By sphericalDropdown() {
	    return By.xpath("//app-dropdown-basic[@formcontrolname='spherical']//select");
	}
	
	public static By visionDropdown() {
	    return By.xpath("//app-dropdown-basic[@formcontrolname='vision']//select");
	}
	
	public static By distanceOneDropdown() {
	    return By.xpath("//app-dropdown-basic[@formcontrolname='distanceOne']//select");
	}
	
	public static By distanceTwoDropdown() {
	    return By.xpath("//app-dropdown-basic[@formcontrolname='distanceTwo']//select");
	}
	
	public static By intermediateSphericalDropdown() {
	    return By.xpath("//app-dropdown-basic[@formcontrolname='intermediateSpherical']//select");
	}
	
	public static By logmarDropdown() {
	    return By.xpath("//app-dropdown-basic[@formcontrolname='intermediateVision']//select");
	}
	
	public static By snellenDropdown() {
	    return By.xpath("//app-dropdown-basic[@formcontrolname='intermediateSnellenEqu']//select");
	}
	
	public static By nearPdInput(String eye) {
	    return By.xpath(
	        "//span[text()='" + eye + "']/ancestor::div[contains(@class,'vert-center1')]" +
	        "//numeric-input-control[@formcontrolname='nearPd']//input");
	}
	
	public static By simpleSphericalDropdown(String eye) {
	    return By.xpath("//span[text()='" + eye + "']/ancestor::div[contains(@class,'vert-center1')]//select[@id='intermediateSpherical']");
	}
	
	public static By BtnAddInfo(String btn) {
        return  By.xpath("//app-ref-additional-info//button[normalize-space()='" + btn + "']");
    }
		
	public static By dropdownBySelectLabelAddInfo(String labelName) {
	    return By.xpath("//div[normalize-space()='" + labelName + "']/following::select[1]");
	}
	
	public static By dropdownByLabelAddInfo(String labelName) {
	    return By.xpath(
	        "//div[contains(@class,'wid_100')]" +
	        "[.//div[starts-with(normalize-space(),'" + labelName + "')]]" +
	        "//ng-select");
	}

	public static By dropdownOptionAddInfo() {
	    return By.xpath(
	    		"//div[contains(@class,'wid_100')]" + 
	    		        "//ng-select//input[@role='combobox']" );
	}
    
	public static By enterOthersInput(String labelName) {
	    return By.xpath(
	        "//div[contains(@class,'wid_100')]" +
	        "[.//div[starts-with(normalize-space(),'" + labelName + "')]]" +
	        "//input[@placeholder='Enter Others']");
	}
	
	public static By additionalInfoSummaryDisplay = By.xpath("//app-ref-additional-info-summary");
	
	public static By BtnDilated(String btn) {
        return  By.xpath("//app-dynamic-rr//button[normalize-space()='" + btn + "']");
    }
	
	public static By selectLabelOptionsDilated(String labelName) {
	    return By.xpath(
	        "//div[.//label[contains(normalize-space(),'" + labelName + "')]]//select");
	}
	
	public static By selectLabelOptionsDilated(String label, String option) {
        return By.xpath("//app-dynamic-rr//*[contains(text(),'" + label + "')]/following::label[normalize-space()='" + option + "'][1]");
    }
	
	public static By BtnGlassPres(String btn) {
        return  By.xpath("//app-ref-glass-prescription//button[normalize-space()='" + btn + "']");
    }
	
	public static By glassPrescriptionSummaryDisplay = By.xpath("//app-ref-glass-prescription-summary");
	
	public static By selectRRType(String optionName) {
	    return By.xpath(
	        "//app-radio//label[normalize-space()='" + optionName + "']");
	}
	
	public static By dropdownBySelectLabelSubRRDV(String labelName) {
	    return By.xpath("//app-sub-rr-dv//label[contains(normalize-space(),'" + labelName + "')]/following::select[1]");
	}
	
	public static By lensTypeOption(String lensType) {
	    return By.xpath("//span[contains(@class,'fa-lenstype-" + lensType + "')]/ancestor::label");
	}
	
	public static By dropdownBySelectLabelRemarksGPRef(String labelName) {
	    return By.xpath("//div[normalize-space()='" + labelName + "']/following::select[1]");
	}
	
	public static By OthersInputGPRefRemarks(String labelName) {
	    return By.xpath(
	        "//div[contains(@class,'wid_100')]" +
	        "[.//div[contains(normalize-space(),'" + labelName.replace(":", "").trim() + "')]]" +
	        "//input[@placeholder='Enter Others']");
	}
	
	public static By refractionSummaryDisplay = By.xpath("//app-refraction-summary");
	
	public static By selectDropdownByLabel(String label) {

	    if (label.equalsIgnoreCase("Tint colour")) {
	        return By.xpath("//app-dropdown-control[@id='tintColourId']//select");
	    } 
	    else if (label.equalsIgnoreCase("Tint type")) {
	        return By.xpath("//app-dropdown-control[@id='tintTypeId']//select");
	    }

	    throw new IllegalArgumentException("Invalid label: " + label);
	}
	
// GP ---> GLASS PRESRIPTION
	public static By selectLabelOptionGP(String label, String option) {
        return By.xpath("//app-glassprescription-control//*[contains(text(),'" + label + "')]/following::label[normalize-space()='" + option + "'][1]");
    }
	
	public static By BtnGPModule(String btn) {
        return  By.xpath("//app-glassprescription-control//button[normalize-space()='" + btn + "']");
    }
	
	public static By gpButton = By.xpath("//span[normalize-space()='Advice']/ancestor::div[contains(@class,'header')]//button[normalize-space()='GP']");

	
// CHANGE LOCATION FOR GP
	
// GP ADVICE SUMMARY 
    public static By GPSummary =By.xpath("//app-glassprescription-summary");
    
    public static By GPSummaryDeleteIcon = By.cssSelector("app-glassprescription-summary span.sur-adv-del i.fa-trash");

    public static By GPSummaryPrintIcon = By.xpath("//app-glassprescription-summary//i[@class='bi bi-printer']");

    public static By GPSummaryInfoIcon = By.xpath("//app-glassprescription-summary//i[@class='fa fa-info']");    
    
    public static By patientInfoByNameGP(String name) {
        return By.xpath("//app-glassprescription-summary//div[contains(@class,'drug-hide1') and contains(text(),'" + name + "')]");
    } 	
	
	
// AUTO REFRACTION
    
    public static By BtnAutoRefModule(String btn) {
        return  By.xpath("//app-auto-refraction-control//button[normalize-space()='" + btn + "']");
    }	
	
	

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
