package locators;


import org.openqa.selenium.By;

public class clinicalRecordsLocator {

	public static By clinicalRecordsOption = By.cssSelector("a[href='/patient/2']");
    public static By patientStatusSearchOption = By.cssSelector("div.user-name img");
    public static By viewIcon = By.xpath("//app-patient-waiting-list//div[@class='print-view']//span[@class='view-icon']");
    
    public static By visionChart = By.cssSelector("select.on-vis");
    
  
    public static By ucvaDropdown = By.xpath("//span[normalize-space()='UCVA:']/following::div[contains(@class,'dropdown-btn')][1]");
    
    public static By ucvaPhDropdown = By.id("dropdownLabelUcvaph");
    
    public static By methodInput =  By.xpath("(//app-onsight-vision//select)[2]");
    
    public static By saveVisBtn  = By.xpath("//app-onsight-vision//button[normalize-space()='Save']");
    
    public static By saveRefBtn = By.xpath("//app-referral-control//button[normalize-space()='Save']");
   
    
//  ENTER PIN
  public static By enterPin(String digit) {
      return By.xpath("//ngb-modal-window//div[@class='pin-buttons']//button[normalize-space()='" + digit + "']");
  }

  public static By pinButton(String value) {
      return By.xpath("//ngb-modal-window//div[contains(@class,'pin-buttons')]//button[normalize-space()='" + value + "']");
  }
  
  public static By deletePinBtn = By.xpath("//ngb-modal-window//div[contains(@class,'pin-buttons')]//button[i[contains(@class,'fa-delete-left')]]");
  
  
  
//    UCVA DROPDOWN IN VISION CHART IN VISION
    public static By selectRE(String value) {
        return By.xpath("//div[@id='customDropdownUcva']//div[@class='column'][1]//div[normalize-space()='" + value + "']");
    }

    public static By selectLE(String value) {
        return By.xpath("//div[@id='customDropdownUcva']//div[@class='column'][2]//div[normalize-space()='" + value + "']");
    }
    
//  UCVAph DROPDOWN IN VISION CHART IN VISION
    public static By selectREph(String value) {
        return By.xpath("//div[@id='customDropdownUcvaph']//div[contains(@class,'dropdown-content')]//div[@class='column'][1]//div[normalize-space()='" + value + "']");
    }
    
    public static By selectLEph(String value) {
        return By.xpath("//div[@id='customDropdownUcvaph']//div[contains(@class,'dropdown-content')]//div[@class='column'][2]//div[normalize-space()='" + value + "']");
    }
    

// REFERRAL ADVICE MODULE
    public static By hospitalInput = By.xpath("//ng-select[@formcontrolname='hospital' and @bindlabel='referralCenterName']");
    public static By hosInput = By.xpath("//ng-select[@formcontrolname='hospital' and @bindlabel='referralCenterName']//input[@role='combobox' and @type='text']");
    
    public static By clinicInput = By.xpath("//ng-select[@bindlabel='clinicName']");
    public static By cliInput = By.xpath("//ng-select[@bindlabel='clinicName']//input[@role='combobox' and @type='text']");
    
    public static By reasonInput = By.xpath("//ng-select[@bindlabel='reasonText']");
    public static By reasonRefInput = By.xpath("//ng-select[@bindlabel='reasonText']//input[@role='combobox' and @type='text']");
    
    public static By buttonByText(String btnName) {
        return By.xpath("//app-referral-control//button[normalize-space()='" + btnName + "' and @disabled]");
    }
    
    public static By hospitalNameerrorMsg =By.xpath("//span[contains(@class,'red-fnt') and contains(normalize-space(),'Please select Hospital')]");
    public static By clinicNameerrorMsg =By.xpath("//span[contains(@class,'red-fnt') and contains(normalize-space(),'Please select Clinic')]");
    public static By reasonForReferrorMsg =By.xpath("//span[contains(@class,'red-fnt') and contains(normalize-space(),'Please select at least one Referral Reason')]");
    
    
    public static By ReferralSummary =By.xpath("//app-referral-summary");
    
    public static By ReferralSummaryDeleteIcon = By.cssSelector("app-referral-summary span.sur-adv-del i.fa-trash");

    public static By ReferralSummaryPrintIcon = By.xpath("//app-referral-summary//i[@class='bi bi-printer']");

    public static By ReferralSummaryInfoIcon = By.xpath("//app-referral-summary//i[@class='fa fa-info']");
    public static By patientInfoByName(String name) {
        return By.xpath("//app-referral-summary//div[contains(@class,'drug-hide1') and contains(text(),'" + name + "')]");
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
