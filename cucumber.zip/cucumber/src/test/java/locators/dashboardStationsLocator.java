package locators;


import org.openqa.selenium.By;


public class dashboardStationsLocator {

// STATION OVERVIEW ----> DASHBOARD PAGE
	
	public static By waitingBadge = By.xpath("//span[contains(text(),'Waiting')]");
    
    public static By pageTitle = By.xpath("//h1[text()='Station Overview']");

    // SUMMARY CARDS
    public static By totalOP = By.xpath("//p[text()='Total OP']/following-sibling::h2");
    public static By waitingTotal = By.xpath("//p[text()='Waiting']/following-sibling::h2");
    public static By completedTotal = By.xpath("//p[text()='Completed']/following-sibling::h2");

    // TABLE
    public static By tableRows = By.xpath("//tbody/tr");

    public static By stationNames = By.xpath("//tbody/tr/td[1]");
    public static By waitingValues = By.xpath("//tbody/tr/td[2]//span");
    public static By completedValues = By.xpath("//tbody/tr/td[3]");

    // PROGRESS BAR (COLOUR)
    public static By progressBars = By.xpath("//tbody/tr/td[2]//div[contains(@class,'bg-orange-400')]");
    
    public static By waitingValueByIndex(int i) {
        return By.xpath("(//tbody/tr/td[2]//span)[" + i + "]");
    }

    public static By stationNameByIndex(int i) {
        return By.xpath("(//tbody/tr/td[1])[" + i + "]");
    }

    public static By progressBarByIndex(int i) {
        return By.xpath("(//tbody/tr/td[2]//div[contains(@class,'bg-orange-400')])[" + i + "]");
    }


    
// SURERY ADVISED ----> DASHBOARD PAGE   
    
    public static By surgeryConfirmed = By.cssSelector("a[href='#/patient-onboarding']");
	
    public static By BtnOnboarding(String btn) {
        return By.xpath("//app-patient-onboarding//button[normalize-space()='" + btn + "']");
    }
	
	
	
	
	
	
}
