package locators;


import org.openqa.selenium.By;


public class hospitalMasterLocator {

	public static By hospitalMasterOption = By.cssSelector("a[href='/master/facility']");

	public static By newBtn = By.xpath("//button[normalize-space()='New']");
	
	public static By popup = By.xpath("//div[@role='dialog']//span[text()='Hospital Master']");
	
	public static By hospitalNameInput = By.xpath("//input[@placeholder='Hospital Name' and @name='facilityName']");
	public static By hospitalNameerrorMsg = By.xpath("//*[normalize-space()='Hospital Name is required.']");
	 
	public static By hospitalShortNameInput = By.xpath("//input[@placeholder='Hospital Short Name' and @name='facilityShortName']");
	public static By hospitalShortNameerrorMsg = By.xpath("//*[normalize-space()='Hospital Short Name is required.']");
	
	public static By hospitalTypeInput = By.xpath("//select[@name='facilityType']");
	public static By hospitalTypeerrorMsg = By.xpath("//*[normalize-space()='Hospital Type is required.']");
	
	public static By addressInput = By.xpath("//input[@name='address1']");
	public static By addresserrorMsg = By.xpath("//*[normalize-space()='Address is required.']");
	
	public static By talukInput = By.xpath("//select[@name='taluk']");
	public static By talukerrorMsg = By.xpath("//*[normalize-space()='City / Taluk is required.']");
	
	public static By districtInput = By.xpath("//select[@name='district']");
	public static By districterrorMsg = By.xpath("//*[normalize-space()='District is required.']");
	
	public static By stateInput = By.xpath("//select[@name='state']");
	public static By stateerrorMsg = By.xpath("//*[normalize-space()='State is required.']");
	
	public static By countryInput = By.xpath("//select[@name='country']");
	
	public static By telephoneInput = By.xpath("//input[@name='telephoneNumber']");
	
	public static By emailInput = By.xpath("//input[@name='emailID']");
	public static By emailerrorMsg = By.xpath("//*[normalize-space()='Email is required.']");
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
