package locators;

import org.openqa.selenium.By;

public class outReachMasterLocator {

	public static By masterOption = By.cssSelector("a[href='#/master']"); 
	public static By outReachMasterOption = By.cssSelector("a[href='/master/event']");
	public static By newBtn = By.xpath("//button[text()='New']");
	
	public static By popup = By.xpath("//div[@role='dialog']//span[text()='Outreach Event Master']");
	public static By editBtnEnable = By.xpath("//button[@class='tab-button button-radius m-green m-r-10' and normalize-space()='Edit']");
	public static By deleteBtnEnable = By.xpath("//button[@class='tab-button button-radius m-red m-r-10' and normalize-space()='Delete']");
	public static By editBtn = By.xpath("//button[text()='Edit' and @disabled]");
	public static By newBtnDisable = By.xpath("//button[text()='New' and @disabled]");
    public static By deleteBtn =By.xpath("//button[text()='Delete' and @disabled]");
    public static By saveBtn = By.xpath("//button[@type='submit' and normalize-space()='Save']");
    public static By clearBtn = By.xpath("//button[@type='reset' and normalize-space()='Clear']");
    public static By cancelBtn = By.xpath("//button[@type='button' and normalize-space()='Cancel']");
	public static By hospitalName = By.xpath("//select[@name='facility']");
	public static By hospitalNameerrorMsg = By.xpath("//*[normalize-space()='Hospital Name is required']");
	
	public static By clickActive = By.xpath("//input[@type='checkbox' and @name='isActive']");
	
//    public static By eventOrgName = By.xpath("//ng-select[@bindlabel='firstName' and @placeholder='Select Event Organizer Name']");	
	public static By eventOrgName = By.xpath("//ng-select[@bindlabel='firstName']//div[contains(@class,'ng-select-container')]");
	public static By eventOrgNameInput = By.xpath("//input[@role='combobox' and @type='text']");
	public static By orgNameerrorMsg = By.xpath("//*[normalize-space()='Event Organizer Name is required']");
	
	public static By placeName = By.xpath("//input[@name='place']");
	public static By placeerrorMsg = By.xpath("//*[normalize-space()='Place is required']");
	
	public static By cityName = By.xpath("//app-dropdown-search-select[@name='taluk']//input");
	public static By cityerrorMsg = By.xpath("//*[normalize-space()='City / Taluk is required']");
	
	public static By districtName =  By.xpath("//app-dropdown-search-select[@name='district']//input");
	public static By districterrorMsg = By.xpath("//*[normalize-space()='District is required']");
	
	public static By distanceInput = By.xpath("//select[@name='distanceFromHQ']");
	public static By distanceerrorMsg = By.xpath("//*[normalize-space()='Distance From HQ is required']");
	
//	CHANGE THIS 
	public static By languageInput = By.xpath("//select[@name='distanceFromHQ']");
	public static By languageerrorMsg = By.xpath("//*[normalize-space()='Distance From HQ is required']");
	
	public static By eventTypeInput = By.xpath("//select[@name='eventType']");
	public static By eventTypeerrorMsg = By.xpath("//*[normalize-space()='Event Type is required']");
	
	public static By eventLocationInput = By.xpath("//select[@name='location']");
	public static By eventLocationerrorMsg = By.xpath("//*[normalize-space()='Event Location is required']");
	
	public static By projectInput = By.xpath("//select[@name='eventForm.projectName']");
	
	public static By localPartnerName = By.xpath("//input[@name='localPartner']");
	
	public static By expectedOPInput = By.xpath("//input[@name='expectedOP']");
	public static By expectedOPerrorMsg = By.xpath("//*[normalize-space()='Expected OP is required']");
	
	public static By expectedIPInput = By.xpath("//input[@name='expectedIP']");
	public static By expectedIPerrorMsg = By.xpath("//*[normalize-space()='Expected IP is required']");
	
	public static By expectedSpecRefInput = By.xpath("//input[@name='expectedSpecialityReferral']");
	public static By expectedSpecReferrorMsg = By.xpath("//*[normalize-space()='Expected Speciality is required']");
	
	public static By expectedGPInput = By.xpath("//input[@name='expectedGP']");
	public static By expectedGPerrorMsg = By.xpath("//*[normalize-space()='Expected GP is required']");
		
	public static By campIdInput = By.xpath("//input[@name='ihmsCampId']");
	
//	 CALENDER
	// EVENT START DATE    
	public static By startDateCalendar = By.xpath("//label[contains(text(),'Event Start Date')]//following::span[contains(@class,'dp-master')][1]");
	public static By startDateInput = By.xpath("//label[contains(text(),'Event Start Date')]//following::input[@placeholder='DD/MM/YYYY'][1]");
	// Date picker day (dynamic)
	public static By selectStartDate(String date) {
	    return By.xpath("//ngb-datepicker//div[contains(@class,'ngb-dp-day') and normalize-space()='" + date + "']");
	}
	// MONTH AND YEAR
	public static By monthInput = By.xpath("//select[@aria-label='Select month']");
	public static By yearInput = By.xpath("//select[@aria-label='Select year']");
	public static By startDateerrorMsg = By.xpath("//*[normalize-space()='Stard Date is required']");
// EVENT END DATE    
	// EVENT START DATE    
	public static By endDateCalendar = By.xpath("//label[contains(text(),'Event End Date')]//following::span[contains(@class,'dp-master')][1]");
	public static By endDateInput = By.xpath("//label[contains(text(),'Event End Date')]//following::input[@placeholder='DD/MM/YYYY'][1]");
	// Date picker day (dynamic)
	public static By selectEndDate(String date) {
	    return By.xpath("//ngb-datepicker//div[contains(@class,'ngb-dp-day') and normalize-space()='" + date + "']");
	}
	public static By endMonthInput = By.xpath("(//select[@aria-label='Select month'])[2]");
	public static By endYearInput = By.xpath("(//select[@aria-label='Select year'])[2]");
	public static By endDateerrorMsg = By.xpath("//*[normalize-space()='End Date is required']");

	public static By noDataFoundMsgEvent =By.xpath("//*[contains(text(),'No items found')]");
	
	
//	EDIT WORKFLOW
	public static By searchBar = By.xpath("//input[@type='text' and @placeholder='Search...']");
	public static By clickCheckboxTable =By.xpath("//input[@type='checkbox')]");
	public static By updateBtn = By.xpath("//button[@type='submit' and normalize-space()='Update']");
	public static By confirmOkBtn = By.xpath("//button[normalize-space()='OK']");
	public static By confirmCancelBtn = By.xpath("//button[normalize-space()='Cancel']");
	
	
	
	
	
	
	
	
}
