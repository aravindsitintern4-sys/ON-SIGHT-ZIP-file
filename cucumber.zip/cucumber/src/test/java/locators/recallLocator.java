package locators;

import org.openqa.selenium.By;

public class recallLocator {

	public static By recallBtn = By.xpath("//button[@tabindex='29']");
	public static By oidInput = By.xpath("//input[@placeholder='Enter OID']");
	public static By submitBtn = By.xpath("//button[@class='bg-[#38BA7E] text-white px-6 py-2 rounded hover:opacity-90' and normalize-space()='Submit']");
	public static By cancelBtn = By.xpath("//button[contains(text(),'Cancel')]");
	public static By invalidOidAlert = By.xpath("//*[contains(text(),'No data available for the given UID!')]");
	public static By okBtn = By.xpath("//button[normalize-space()='Ok']");
	public static By requiredAlert = By.xpath("//*[contains(@class,'text-red-500') and contains(text(),'OID is required')]"); 
	public static By closeBtn = By.cssSelector("button.confirm-cls");
	
}
