package locators;


import org.openqa.selenium.By;

public class reportsLocator {

	public static By reportsOption = By.cssSelector("a[href='#/reports']");
	public static By campId = By.xpath("//ng-select[@placeholder='Select Camp']");
	public static By campIdInput = By.xpath("//ng-select[contains(@class,'ng-select-opened')]//input");

	
	// REPORTS -----> CAMP SUMMARY	
    public static By BtnCampSummary(String btn) {
        return  By.xpath("//app-camp-summary-report//button[normalize-space()='" + btn + "']");
    }
	
    public static By fromDateInputCampSummary = By.xpath("//app-camp-summary-report//span[normalize-space()='From:']/following::input[@type='date'][1]");
    
    public static By toDateInputCampSummary = By.xpath("//app-camp-summary-report//span[normalize-space()='To:']/following::input[@type='date'][1]");
    
    public static By campSummaryDropdown = By.xpath("//app-camp-summary-report//ng-select[@placeholder='Select Camp' and @bindlabel='place']");
    
    public static By campSummaryDropdownInput = By.xpath("//app-camp-summary-report//input[@role='combobox' and @type='text']");
    
    public static By noItemsFoundMsgDropdown = By.xpath("//ng-dropdown-panel//div[contains(@class,'ng-option') and contains(.,'No items')]");

    public static By selectAllLabel = By.xpath("//ng-dropdown-panel//label[normalize-space()='Select All']");

    public static By selectAllCheckbox = By.xpath("//ng-dropdown-panel//input[@type='checkbox']");

    public static By allOptions = By.xpath("//ng-dropdown-panel//div[@role='option']");

    public static By selectedOptions = By.xpath("//ng-dropdown-panel//div[contains(@class,'ng-option-selected')]");
	
 // Dropdown
    public static By campDropdown = By.xpath("//ng-select[@placeholder='Select Camp']");

    // Input
    public static By campInput = By.xpath("//ng-select//input[@role='combobox']");

    // All options
    public static By campOption(String value) {
        return By.xpath(
            "//div[@role='option' and not(.//input)]" +
            "[.//strong[normalize-space()='ID: " + value + "'] " +
            "or .//span[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'" 
            + value.toLowerCase() + "')]]"
        );
    }
    
    public static By clearAllSelection = By.xpath("//ng-select//span[contains(@class,'ng-clear-wrapper')]");
    
    public static By reportTable =By.xpath("//div[@class='table-wrap']//table[contains(@class,'report-table')]");

    

}
