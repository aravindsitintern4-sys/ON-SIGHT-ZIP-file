package locators;


import org.openqa.selenium.By;

public class reportsLocator {

	public static By reportsOption = By.cssSelector("a[href='/reports']");
	public static By campId = By.xpath("//ng-select[@placeholder='Select Camp']");
	public static By campIdInput = By.xpath("//ng-select[contains(@class,'ng-select-opened')]//input");


}
