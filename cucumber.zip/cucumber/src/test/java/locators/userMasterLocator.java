package locators;

import org.openqa.selenium.By;

public class userMasterLocator {

	public static By userMasterOption = By.cssSelector("a[href='#/master/user']");

	public static By newBtn = By.xpath("//button[normalize-space()='New']");
	
	public static By popup = By.xpath("//div[@role='dialog']//span[text()='User Master']");
	
	public static By editBtnEnable = By.xpath("//button[@class='tab-button button-radius m-green m-r-10' and normalize-space()='Edit']");
	public static By deleteBtnEnable = By.xpath("//button[@class='tab-button button-radius m-red m-r-10' and normalize-space()='Delete']");
	public static By resetPasswordBtnEnable =By.xpath("//button[@class='tab-button button-radius m-green m-r-10' and normalize-space()='Reset-Password']");
	
	public static By editBtn = By.xpath("//button[text()='Edit' and @disabled]");
	public static By newBtnDisable = By.xpath("//button[text()='New' and @disabled]");
    public static By deleteBtn =By.xpath("//button[text()='Delete' and @disabled]");
	public static By resetPasswordBtn =By.xpath("//button[text()='Reset-Password' and @disabled]");
	public static By clearBtn = By.xpath("//button[@type='reset' and normalize-space()='Clear']");
    public static By cancelBtn = By.xpath("//button[@type='button' and normalize-space()='Cancel']");
	public static By saveBtn = By.xpath("//button[@type='submit' and normalize-space()='Save']");
   
    public static By aliasInput = By.cssSelector("select.form-select");
    public static By aliaserrorMsg = By.xpath("//*[normalize-space()='Alias is required']");
	
    public static By firstNameInput = By.xpath("//input[@placeholder='First Name']");
    public static By firstNameerrorMsg = By.xpath("//*[normalize-space()='First name is required']");
	
    public static By lastNameInput = By.xpath("//input[@placeholder='Last Name']");
	
    public static By emailInput = By.xpath("//input[@placeholder='Email']");
	
    public static By roleInput = By.xpath("//select[option[contains(text(),'Select Role')]]");
    public static By roleerrorMsg = By.xpath("//*[normalize-space()='Role is required']");
	
    public static By hospitalInput = By.xpath("//select[option[contains(text(),'Select Hospital Name')]]");
    public static By hospitalerrorMsg = By.xpath("//*[normalize-space()='Hospital name is required']");
	
    public static By mcirNumberInput = By.xpath("//input[@placeholder='MCIR Number']");
	
    public static By oldPasswordInput = By.xpath("//app-resetpassword//input[@placeholder='Old Password']");
    public static By newPasswordInput =  By.xpath("//app-resetpassword//input[@placeholder='New Password']");    
    public static By confirmPasswordInput = By.xpath("//app-resetpassword//input[@placeholder='Confirm Password']");
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
