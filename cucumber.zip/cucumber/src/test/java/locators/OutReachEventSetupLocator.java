package locators;

import org.openqa.selenium.By;

public class OutReachEventSetupLocator {

    public static By hospitalDropdown = By.xpath("//select[@name='facilityCode']"); 
    public static By eventDropdown = By.xpath("//ng-select[@name='eventId']");
    public static By eventInput = By.xpath("//ng-select[@name='eventId']//input");
    public static By saveButton = By.xpath("//button[@class='btn btn-secondry' and normalize-space()='Save']");
    public static By cancelButtonORE = By.xpath("button[@class='btn btn-danger']");

    public static By hospitalOption(String hospital) {
        return By.xpath("//*[contains(text(),'" + hospital + "')]");
    }

    public static By eventOption(String eventId) {
        return By.xpath("//ng-dropdown-panel//div[@role='option'][.//strong[contains(text(),'ID: " + eventId + "')]]");
    }
}
