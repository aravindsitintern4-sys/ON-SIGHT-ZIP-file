package locators;

import org.openqa.selenium.By;

public class registrationLocator {
	public static By regOption = By.cssSelector("a[href='/registration-screen']");
	public static By firstNameInput = By.xpath("//input[@placeholder='First Name']");
	public static By lastNameInput = By.xpath("//input[@placeholder='Last Name']");
	public static By ageInput = By.xpath("//input[@placeholder='Years']");
	public static By genderInput = By.xpath("//select[@tabindex='9']");
	public static By yesBtn = By.xpath("//button[normalize-space()='Yes']");
	public static By noBtn  = By.xpath("//button[normalize-space()='No']");
	public static By kinInput = By.xpath("//select[@tabindex='10']");
	public static By kinNameInput = By.xpath("//input[@placeholder='Next of kin name']");
	public static By doorStreetInput = By.xpath("//input[@tabindex='12']");
	public static By localityInput = By.xpath("//input[@placeholder='Locality']");
	public static By areaBtn = By.xpath("//button[@tabindex='13']");
	public static By areaInput = By.xpath("//select[@tabindex='14']");
	public static By pincodeInput = By.xpath("//input[@placeholder='Pin Code']");
	public static By talukInput = By.xpath("//input[@tabindex='18']");
	public static By mobileNumInput = By.xpath("//input[@placeholder='Mobile No']");
	public static By aadhaarNumInput = By.xpath("//input[@placeholder='Aadhaar No']");
	public static By submitBtn = By.xpath("//button[@class='bg-[#1c94fc] text-white px-6 py-2 rounded hover:opacity-90' and normalize-space()='Submit']");
	public static By ClearBtn = By.xpath("//button[@class='border border-[#dc3545] bg-[#fff] text-[#dc3545] px-6 py-2 rounded hover:opacity-90' and normalize-space()='Clear']");
	public static By CancelBtn = By.xpath("//button[@class='text-white bg-red-500 px-6 py-2 rounded hover:opacity-90' and normalize-space()='Cancel']");
	public static By requiredAlert =By.xpath("//*[@class='text-xs text-red-500 mt-1 w-fit ng-star-inserted' and normalize-space()='Required.']");
	public static By invalidAlert = By.xpath("//*[contains(text(),'Invalid')]");
	public static By noDataFoundMsg =By.xpath("//*[contains(text(),'No data')]");
	public static By districtDropdown =By.xpath("//select[@formcontrolname='district']");
	public static By invalidFormatAlert = By.xpath("//*[contains(text(),'Invalid format')]");
	public static By invalidAadhaarAlert = By.xpath("//*[contains(text(),'Invalid Aadhaar number')]");
	public static By closeIconBtn = By.xpath("//h2[contains(text(),'Updated Successfully')]/preceding-sibling::button");
	
}
