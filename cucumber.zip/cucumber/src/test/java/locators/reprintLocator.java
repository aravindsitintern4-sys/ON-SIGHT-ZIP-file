package locators;

import org.openqa.selenium.By;

public class reprintLocator {
	public static By reprintBtn = By.xpath("//button[@tabindex='30']");
	public static By patientTypeInput = By.xpath("//select[@tabindex='0']");
	public static By dateInput = By.xpath("//input[@type='date']");
	public static By oidInput = By.xpath("//input[@placeholder='OID']");
	public static By searchIconBtn = By.xpath("//button[@class='search-style btn']");
	public static By submitBtn = By.xpath("//button[@class='bg-[#1c94fc] mr-3 text-white px-6 py-2 rounded hover:opacity-90' and normalize-space()='Submit']");
	public static By printPreviewCancelBtn = By.xpath("//cr-button[@class='cancel-button' and normalize-space()='Cancel']");
	public static By cancelBtn = By.xpath("//app-reprint//button[normalize-space()='Cancel']");
	public static By closeBtn = By.xpath("//button[@class='absolute top-2 right-5 text-gray-500 hover:text-black text-[30px] confirm-cls' and normalize-space()='×']");
	public static By invalidOidAlert = By.xpath("//*[contains(@class,'text-red-500') and contains(text(),'No data available for the given UID!')]");
	public static By okBtn = By.xpath("//button[normalize-space()='Ok']");
	public static By patientNameValue = By.xpath("//span[text()='Patient Name:']/following-sibling::span");
	public static By requiredAlert = By.xpath("//div[contains(@class,'text-red-500') and contains(text(),'Required')]");
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}