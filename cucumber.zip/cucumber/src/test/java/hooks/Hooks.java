package hooks;

import io.cucumber.java.Before;
import io.cucumber.java.After;
import utils.DriverFactory;

public class Hooks {

	  private static boolean isBrowserStarted = false;

	    @Before
	    public void setup() {

	        if (!isBrowserStarted) {
	            DriverFactory.initDriver();
	            DriverFactory.getDriver().get("https://onsight-qa.aravind.org/");
	            isBrowserStarted = true;
	        }
	    }
	    

	    @After
	    public void tearDown() {
//	        DriverFactory.quitDriver();
	    }
}
//DriverFactory.getDriver().get("https://onsight-qa.aravind.org/");