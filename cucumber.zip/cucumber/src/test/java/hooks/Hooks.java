package hooks;

import io.cucumber.java.BeforeAll;
import io.cucumber.java.AfterAll;
import utils.DriverFactory;

public class Hooks {

    @BeforeAll
    public static void setup() {
        DriverFactory.initDriver("firefox");
        DriverFactory.getDriver().get("https://onsight-qa.aravind.org/");
    }

    @AfterAll
    public static void tearDown() {
//        DriverFactory.quitDriver();
    }
}