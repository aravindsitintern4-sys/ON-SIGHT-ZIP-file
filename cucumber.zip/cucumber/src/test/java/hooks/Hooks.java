package hooks;

import io.cucumber.java.Before;
import io.cucumber.java.After;
import utils.DriverFactory;

public class Hooks {

	// CHECK BROWSER RUNS ONLY ONCE 
	// PRIVATE STATIC --> PREVENTS MULTIPLE BROWSER LAUNCHES
	private static boolean isBrowserStarted = false;

	    @Before
	    public void setup() {
	    	// CHECK BROWSER ALREADY STARTED
	        if (!isBrowserStarted) {
	        	DriverFactory.initDriver("chrome");
	            DriverFactory.getDriver().get("https://onsight-qa.aravind.org/");
	            isBrowserStarted = true;
	        }
	    }
	    

	    @After
	    public void tearDown() {
//	        DriverFactory.quitDriver();
	    }
}
//DriverFactory.getDriver().get("https://onsight-qa.aravind.org/");