package stepDefinitions;


import io.cucumber.java.en.*;
import locators.clinicalRecordsLocator;
import pages.clinicalRecordsPage;
import utils.DriverFactory;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class clinicalRecordsStep {

	clinicalRecordsPage clinical;
    WebDriverWait wait;

    public clinicalRecordsStep() {
    	clinical = new clinicalRecordsPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
//  CLINICAL RECORDS OPTION CLICK
    @And("user clicks on clinical records option")
    public void user_clicks_clinical_records_page() {
    	clinical.clickClinicalRecordsOption();  
    }
    
    @Then("user navigated to the clinical records dashboard page")
    public void user_navigated_to_clinical_records_page() {
        wait.until(ExpectedConditions.urlContains("2"));
        System.out.println("User is navigated to Clinical Records page");
    }

// PATIENT SEARCH ICON
    @And("user clicks patient status search icon")
    public void user_clicks_patient_status_search_page() {
    	clinical.clickPatientStatusSearch();  
    }
// DOCTOR SCREEN NAVIGATION
    @Then("user navigated to the doctor screen page")
    public void user_navigated_to_doctor_screeen_page() {
        wait.until(ExpectedConditions.urlContains("doctor-screen/"));
        System.out.println("User is navigated to Doctor screen page");
    }   
    
 // REPORT VIEW ICON 
    @And("user clicks report view icon")
    public void user_clicks_report_view_icon() {
    	clinical.clickReportViewIcon();  
    }  
    
//  ENTER PIN NUMBER
  @And("user enters pin {string}")
  public void user_entersPin(String pin) {
	  clinical.enterPin(pin);
  }
       
//  VISION 
  
    // VISION CHART 
    @And("user selects vision chart {string} dropdown")
    public void user_clicks_dropdown(String option) {
    	clinical.selectVisionChart(option);
    } 
    //   UCVA DROPDOWN
    @And("user selects RE {string} and LE {string} in UCVA dropdown")
    public void user_selects_re_and_le_in_ucva_dropdown(String reValue, String leValue) {
        clinical.selectUCVA(reValue, leValue);
    }
    
    //  UCVAph DROPDOWN
   @And("user selects RE {string} and LE {string} in UCVAph dropdown")
   public void user_selects_re_and_le_in_ucvaph_dropdown(String reValue, String leValue) {
       clinical.selectUCVAph(reValue, leValue);
   }
    
    
   // METHOS DROPDOWN IN VISION 
    @And("user selects method {string} dropdown")
    public void user_clicks_method_dropdown(String option) {
    	clinical.selectMethod(option);
    }
    //SAVE BUTTON FOR VISION   
    @And("user clicks save button in vision")
    public void user_clicks_save_button_vision() {
    	clinical.clickSaveBtn();
    }     
    
    
// INVESTIGATIONS

//IOP

	//RE IOP INPUT
	@And("I enter RE iop input {string}")
	public void RE_IOP_input(String iop) {
		clinical.enterREIOP(iop);
	}     
	
	//RE IOP DROPDOWN
	@And("I select RE iop dropdown {string}")
	public void RE_IOP_dropdown(String iop) {
		clinical.selectREIOP(iop);
	}   
	
	//LE IOP INPUT
	@And("I enter LE iop input {string}")
	public void LE_IOP_input(String iop) {
		clinical.enterLEIOP(iop);
	}   
	
	//LE IOP DROPDOWN
	@And("I select LE iop dropdown {string}")
	public void LE_IOP_dropdown(String iop) {
		clinical.selectLEIOP(iop);
}

//DUCT

	//DUCT RE LOWER DROPDOWN
	@And("I select duct RE lower dropdown {string}")
	public void duct_RE_lower_dropdown(String duct) {
	  clinical.selectREDuctLower(duct);
	}
	
	//DUCT RE UPPER DROPDOWN
	@And("I select duct RE upper dropdown {string}")
	public void duct_RE_upper_dropdown(String duct) {
	  clinical.selectREDuctUpper(duct);
	}
	
	//DUCT LE LOWER DROPDOWN
	@And("I select duct LE lower dropdown {string}")
	public void duct_LE_lower_dropdown(String duct) {
	  clinical.selectLEDuctLower(duct);
	}
	
	//DUCT LE UPPER DROPDOWN
	@And("I select duct LE upper dropdown {string}")
	public void duct_LE_upper_dropdown(String duct) {
	  clinical.selectLEDuctUpper(duct);
	}

//ROPLAS
	
	//ROPLAS RE DROPDOWN
	@And("I select roplas RE dropdown {string}")
	public void select_roplas_re(String value) {
	    clinical.selectRoplasRE(value);
	}
	
	//ROPLAS LE DROPDOWN
	@And("I select roplas LE dropdown {string}")
	public void select_roplas_le(String value) {
	    clinical.selectRoplasLE(value);
	}

//BLOOD SUGAR
	
	// TYPE OF BLOOD SUGAR DROPDOWN
	@And("I select blood sugar type {string}")
	public void select_bs_type(String type) {
	    clinical.selectBloodSugarType(type);
	}
    
	// LEVEL OF BLOOD SUGAR INPUT
	@And("I enter blood sugar value {string}")
	public void enter_bs_value(String value) {
	    clinical.enterBloodSugarValue(value);
	}
    
	//BLOOD SUGAR TESTED LOCATION DROPDOWN
	@And("I select blood sugar location {string}")
	public void select_bs_location(String loc) {
	    clinical.selectBloodSugarLocation(loc);
	}
	
	//BLOOD SUGAR TESTED DATE
	@And("I select blood sugar date {string}")
	public void select_bs_date(String date) {
	    clinical.selectBloodSugarDate(date);
	}

// BLOOD PRESSURE
	
	// BP SYSTOLIC INPUT
	@And("I enter systolic value {string}")
	public void enter_systolic(String value) {
	    clinical.enterBPSystolic(value);
	}

	// BP DIASTOLIC INPUT
	@And("I enter diastolic value {string}")
	public void enter_diastolic(String value) {
	    clinical.enterBPDiastolic(value);
	}

//DELETE ICON IN INVESTIGATION
@And("I click delete icon in {string}")
public void Delete_icon_investigation(String name) {
	clinical.clickDeleteIcon(name);
}     
//SAVE ICON IN INVESTIGATION
@And("I click save icon in {string}")
public void Save_icon_investigation(String name) {
	clinical.clickSaveIcon(name);
}
//EDIT ICON IN INVESTIGATION
@And("I click edit icon in {string}")
public void Edit_icon_investigation(String name) {
	clinical.clickEditIcon(name);
}
//REPEAT ICON IN INVESTIGATION
@And("I click repeat icon in {string}")
public void Repeat_icon_investigation(String name) {
	clinical.clickRepeatIcon(name);
}
 
//PLUS ICON IN INVESTIGATION
@And("I click plus icon in {string}")
public void Plus_icon_investigation(String name) {
	clinical.clickPlusIcon(name);
}


// COMPLAINTS

	// SELECT EYE AND COMPLAINT
	@And("I select {string} eye for {string} complaint")
	public void select_eye_complaints(String complaint, String eye) {
	    clinical.selectEyeComplaints(complaint,eye);
	}
	
	// SELECT COMPLAINT NAME
	@And("I click {string} complaint option")
	public void select_complaints(String complaints) {
		clinical.selectComplaints(complaints);
	}    
	
	//OPEN DURATION
	@When("I open duration for {string}")
	public void open_duration(String complaint) {
	    clinical.openDuration(complaint);
	}
	
	//SELECT DURATION VALUE FOR COMPLAINTS (0-9)
	@And("I set duration value {string}")
	public void set_duration_value(String value) {
	    clinical.setDurationValue(value);
	}
	
	//SELECT DURATION TYPE FOR COMPLAINTS (year, month..)
	@And("I set duration type {string}")
	public void set_duration_type(String type) {
	    clinical.setDurationType(type);
	}
	
	//DURATION BUTTONS (RESET, BACK, OK)
	@And("I click {string} button in duration")
	public void duration_ok_button(String button) {
	    clinical.setDurationBtn(button);
	}
	
	//INVALID DURATION ERROR 
	@Then("invalid duration error messege should come")
	public void duration_invalid_error_msg() {
	    clinical.validateInvalidDuration();
	}
	
	//SELECTED DURATION DISPLAY
	@Then("complaint with duration should be displayed")
	public void complaint_with_duration_should_be_displayed() {
	    clinical.validateComplaintWithDurationDisplayed();
	}
	
	//SYSTEM ALERT CONFIRMATION AND CANCELATION
	@And("I click delete {string} for confirmation complaint")
	public void confirmation_buttons_delete(String btn) {
	    clinical.confirmationBtnDelete(btn);
	}
	
	@And("I click {string} for system alert confirmation complaint")
	public void confirmation_buttons_alert(String btn) {
	    clinical.confirmationBtnDelete(btn);
	}
	
	//COMPLAINT DROPDOWN ( ALL COMPLAINTS )
	@And("I select {string} from all complaints dropdown")
	public void all_complaint_dropdown(String complaint) {
	    clinical.selectComplaintsDropdown(complaint);
	}
	
	@When("I open duration in all complaints")
	public void open_duration_in_all_complaints() {
	    clinical.openDuration();
	}
	
	//SELECT DURATION VALUE FOR COMPLAINTS (0-9)
	@And("I set duration value {string} in complaints")
	public void set_duration_value_AllComplaints(String value) {
	  clinical.setDurationValueAllComplaints(value);
	}
	
	//SELECT DURATION TYPE FOR COMPLAINTS (year, month..)
	@And("I set duration type {string} in complaints")
	public void set_duration_type_AllComplaints(String type) {
	  clinical.setDurationTypeAllComplaints(type);
	}
	
	//DURATION BUTTONS (RESET, BACK, OK)
	@And("I click {string} button in duration in complaints")
	public void duration_ok_button_AllComplaints(String button) {
	  clinical.setDurationBtnAllComplaints(button);
	}
	
	// SAVE BUTTON
	@And("I click save button")
	public void save_button_complaints() {
		clinical.clickSaveBtnComplaint();
	}

// COMPLAINTS SUMMARY

	//COMPLAINTS SUMMARY DISPLAYED
	@Then("complaints summary should be displayed")
	public void complaints_summary_should_be_displayed() {
		clinical.verifyComplaintSummaryDisplayed();
	}
	
	//COMPLAINTS SUMMARY NOT DISPLAYED
	@Then("complaints summary should be not displayed")
	public void complaints_summary_should_be_not_displayed() {
		clinical.verifyComplaintSummaryNotDisplayed();
	}  
	
	//COMPLAINTS SUMMARY DELETE ICON
	@And("I click complaints summary delete icon")
	public void complaints_summary_delete_icon() {
		clinical.ClickComplaintSummaryDeleteIcon();
	}
	
	//COMPLAINTS SUMMARY INFO ICON
	@When("user hovers complaints summary info icon")
	public void complaints_summary_info_icon() {
		clinical.ClickComplaintSummaryInfoIcon();
	}    
	
	@Then("complaint info {string} should be displayed")
	public void complaints_validate_user_info(String name) {
		clinical.verifyComplaintInfoDisplayed(name);
	}    


// SYSTEMIC HISTORY

	@And("I select {string} label for {string} option")
	public void select_label_option_systemic_history(String label, String option) {
	 clinical.selectSystemicHistory(label,option);
	}
	
	//SELECT DURATION VALUE FOR COMPLAINTS (0-9)
	@And("I set duration value {string} in history")
	public void set_duration_value_history(String value) {
	clinical.setDurationValueHistory(value);
	}
	
	//SELECT DURATION TYPE FOR COMPLAINTS (year, month..)
	@And("I set duration type {string} in history")
	public void set_duration_type_history(String type) {
	clinical.setDurationTypeHistory(type);
	}
	
	//DURATION BUTTONS (RESET, BACK, OK)
	@And("I click {string} button in duration in history")
	public void duration_ok_button_history(String button) {
	clinical.setDurationBtnHistory(button);
	}
	
	// INPUT FOR ADDITIONAL INFO
	@And("I enter {string} label remarks as {string}")
	public void enter_additional_information(String label,String info) {
	clinical.enterAdditionalDetail(label,info);
	}
	
	//INPUT FOR OTHER ALLERGY
	@And("I enter other allergy detail {string}")
	public void enter_Other_allergy_input(String info) {
		clinical.enterOtherAllergyInput(info);
	}
	
	//DROPDOWN FOR DRUG ALLERGY
	@And("I select drug allergy {string}")
	public void select_drug_allergy_input(String info) {
		clinical.selectDrugAllergy(info);
	}

//SYSTEMIC HISTORY SUMMARY

	//SYSTEMIC HISTORY SUMMARY DISPLAYED
	@Then("history summary should be displayed")
	public void history_summary_should_be_displayed() {
		clinical.verifyHistorySummaryDisplayed();
	}
	
	//SYSTEMIC HISTORY SUMMARY NOT DISPLAYED
	@Then("history summary should be not displayed")
	public void history_summary_should_be_not_displayed() {
		clinical.verifyHistorySummaryNotDisplayed();
	}  
	
	//SYSTEMIC HISTORY SUMMARY INFO ICON
	@When("user hovers history summary info icon")
	public void history_summary_info_icon() {
		clinical.ClickHistorySummaryInfoIcon();
	}    
	
	@Then("history info {string} should be displayed")
	public void history_validate_user_info(String name) {
		clinical.verifyHistoryInfoDisplayed(name);
	}    
	
	//CLEAR BUTTON IN HISTORY
	@And("I click clear button in history and complaints")
	public void clear_button_history_complaints() {
		clinical.clickClearButton();
	}
	
	@Then("Mandatory alert should be displayed")
	public void validate_mandatory_alert() {
	    clinical.validateMandatoryAlert();
	}


// ANTERIOR SEGMENT 
	
	//SELECT SEGMENT OPTIONS WITH EYE 
	@And("I select {string} label for {string} with {string} option")
	public void select_anterior_segment_options(String segment, String eye, String option) {
		clinical.selectAntiSegment(segment,eye,option);
	}
	
	//SELECT SEGMENT OPTIONS WITHOUT EYE
	@And("I select {string} label for {string} option in examination")
	public void select_anterior_segment_options_without_eye(String segment,String option) {
		clinical.selectAntiSegmentFullOption(segment,option);
	}
	
	// REMARKS FOR ANTERIOR SEGMENT
	@And("I enter remarks for {string} as {string}")
	public void enter_Remarks_for_anterior_segment(String eye,String remark) {
		clinical.enterRemarksAnteriorSegment(eye,remark);
	}

//ANTERIOR SEGMENT SUMMARY

	//ANTERIOR SEGMENT SUMMARY DISPLAYED
	@Then("Anti. segment summary should be displayed")
	public void anterior_segment_summary_should_be_displayed() {
		clinical.verifyAntiSegmentSummaryDisplayed();
	}
	
	//ANTERIOR SEGMENT SUMMARY NOT DISPLAYED
	@Then("Anti. segment summary should be not displayed")
	public void anterior_segment_summary_should_be_not_displayed() {
		clinical.verifyAntiSegmentSummaryNotDisplayed();
	}  
	
	//ANTERIOR SEGMENT SUMMARY INFO ICON
	@When("user hovers Anti. segment summary info icon")
	public void anterior_segment_summary_info_icon() {
		clinical.ClickAntiSegmentSummaryInfoIcon();
	}    
	
	@Then("Anti. segment info {string} should be displayed")
	public void anterior_segment_validate_user_info(String name) {
		clinical.verifyAntiSegmentInfoDisplayed(name);
	}    
	
	//CLEAR BUTTON IN EXAMINATION
	@And("I click clear button in examination")
	public void clear_button_anterior_segment() {
		clinical.clickClearButtonExamination();
	}
	
	//SAVE BUTTON IN EXAMINATION
	@And("I click save button in examination")
	public void save_button_examination() {
		clinical.clickSaveBtnExamination();
	}
	
	//ANTERIOR SEGMENT SUMMARY DELETE ICON
	@And("I click anti. segment summary delete icon")
	public void anterior_segment_summary_delete_icon() {
		clinical.ClickAntiSegmentSummaryDeleteIcon();
	}
	
	// SAVE OR UPDATE BUTTON ACTION 
	@And("I click save or update button in examination")
	public void click_save_or_update_button() {
		clinical.clickSaveOrUpdateButton();
	}



// FUNDUS

	//SELECT FUNDUS OPTIONS WITH EYE 
	@And("I select {string} label for {string} with {string} option in fundus")
	public void select_fundus_options(String segment, String eye, String option) {
		clinical.selectFundus(segment,eye,option);
	}
	
	//SELECT FUNDUS OPTIONS WITHOUT EYE
	@And("I select {string} label for {string} option in fundus")
	public void select_fundus_options_without_eye(String segment,String option) {
		clinical.selectFundusFullOption(segment,option);
	}
	
	//REMARKS FOR FUNDUS
	@And("I enter remarks for {string} as {string} in fundus")
	public void enter_Remarks_for_fundus(String eye,String remark) {
		clinical.enterRemarksFundus(eye,remark);
}


//FUNDUS SUMMARY

	//FUNDUS SUMMARY DISPLAYED
	@Then("Fundus summary should be displayed")
	public void Fundus_summary_should_be_displayed() {
		clinical.verifyFundusSummaryDisplayed();
	}
	
	//FUNDUS SUMMARY NOT DISPLAYED
	@Then("Fundus summary should be not displayed")
	public void Fundus_summary_should_be_not_displayed() {
		clinical.verifyFundusSummaryNotDisplayed();
	}  
	
	//FUNDUS SUMMARY INFO ICON
	@When("user hovers Fundus summary info icon")
	public void Fundus_summary_info_icon() {
		clinical.ClickFundusSummaryInfoIcon();
	}    
	
	@Then("Fundus info {string} should be displayed")
	public void Fundus_validate_user_info(String name) {
		clinical.verifyFundusInfoDisplayed(name);
	}    
	
	//FUNDUS SUMMARY DELETE ICON
	@And("I click Fundus summary delete icon")
	public void fundus_summary_delete_icon() {
		clinical.ClickFundusSummaryDeleteIcon();
	}

//DIAGNOSIS

	//SELECT EYE AND DIAGNOSIS
	@And("I select {string} eye for {string} diagnosis")
	public void select_eye_diagnosis(String diagnosis, String eye) {
	 clinical.selectEyeDignosis(diagnosis,eye);
	}
	
	//SELECT DIAGNOSIS NAME
	@And("I click {string} diagnosis option")
	public void select_diagnosis(String diagnosis) {
		clinical.selectDiagnosis(diagnosis);
	}  
	
	//OTHER DIAGNOSIS EYE TYPE DIAGNOSIS 
	@And("I select {string} eye type for other diagnosis")
	public void diagnosis_eye_type_(String eye) {
		clinical.ClickOtherDiagnosisEyeType(eye);
	}
	
	//DIAGNOSIS DROPDOWN
	@And("I select {string} from diagnosis dropdown")
	public void all_diagnosis_dropdown(String diagnosis) {
	  clinical.selectDiagnosisDropdown(diagnosis);
	}
	
	//DIAGNOSIS SUMMARY DELETE ICON
	@And("I click Diagnosis summary delete icon")
	public void diagnosis_summary_delete_icon() {
		clinical.ClickDiagnosisSummaryDeleteIcon();
	}
	
	// ALERT IN DIAGNOSIS
	@Then("Not Allowed alert should be displayed")
	public void validate_not_allowed_alert() {
	    clinical.validateAlertDiagnosis();
	}



//DIAGNOSIS SUMMARY
	
	//DIAGNOSIS SUMMARY DISPLAYED
	@Then("Diagnosis summary should be displayed")
	public void Diagnosis_summary_should_be_displayed() {
		clinical.verifyDiagnosisSummaryDisplayed();
	}
	
	//DIAGNOSIS SUMMARY NOT DISPLAYED
	@Then("Diagnosis summary should be not displayed")
	public void Diagnosis_summary_should_be_not_displayed() {
		clinical.verifyDiagnosisSummaryNotDisplayed();
	}  
	
	//DIAGNOSIS SUMMARY INFO ICON
	@When("user hovers Diagnosis summary info icon")
	public void Diagnosis_summary_info_icon() {
		clinical.ClickDiagnosisSummaryInfoIcon();
	}    
	
	@Then("Diagnosis info {string} should be displayed")
	public void Diagnosis_validate_user_info(String name) {
		clinical.verifyDiagnosisInfoDisplayed(name);
	}    


//	ADVICE

//REFERRAL ADVICE 

	//HOSPITAL DROPDOWN
	@And("user selects hospital name {string} dropdown")
	public void user_selects_hospital_name_dropdown(String value) {
		clinical.selectHospitalDropdown(value);
	} 
	    
	//CLINIC DROPDOWN
	@And("user selects clinic name {string} dropdown")
	public void user_selects_clinic_name_dropdown(String value) {
		clinical.selectclinicDropdown(value);
	}    
	
	//REASON FOR REFERRAL DROPDOWN
	@And("user selects reason for referral {string} dropdown")
	public void user_selects_reason_for_referral_dropdown(String value) {
	clinical.selectReasonRefDropdown(value);
	}   
	
	//SAVE BUTTON FOR REASON FOR REFERRAL   
	@And("user clicks save button in referral")
	public void user_clicks_save_button_referral() {
	clinical.clickSaveRefBtn();
	}    
	
	
	@Then("hospital name Required alert should be appear referral advice")
	public void validate_hospital_require() {
	validateRequiredAlert(clinicalRecordsLocator.hospitalNameerrorMsg,"Please select Hospital");
	}   
	
	@Then("clinic name Required alert should be appear referral advice")
	public void validate_clinic_require() {
	validateRequiredAlert(clinicalRecordsLocator.clinicNameerrorMsg,"Please select Clinic");
	} 
	
	@Then("reason for referral Required alert should be appear referral advice")
	public void validate_referralReason_require() {
	validateRequiredAlert(clinicalRecordsLocator.reasonForReferrorMsg,"Please select at least one Referral Reason");
	} 
	
	//EMPTY FIELD ACTION FOR ALL FIELDS
	public void validateRequiredAlert(By locator, String expectedMsg) {
	
	boolean isPresent = wait.until(driver -> {
	    List<WebElement> elements = driver.findElements(locator);
	
	    for (WebElement el : elements) {
	        if (el.getText().trim().equalsIgnoreCase(expectedMsg)) {
	            return true;
	        }
	    }
	    return false;
	});
	
	if (!isPresent) {
	    throw new AssertionError("❌ Expected alert not found: " + expectedMsg);
	}
	
	System.out.println("✅ Alert displayed: " + expectedMsg);
	}  
	
	
	@Then("{string} button should be disabled")
	public void button_should_be_disabled(String buttonName) {
	verifyButtonDisabled(clinicalRecordsLocator.buttonByText(buttonName), buttonName);
	}
	
	public void verifyButtonDisabled(By locator, String buttonName) {
	
	WebElement button = wait.until(
	    ExpectedConditions.presenceOfElementLocated(locator)
	);
	
	if (button.isEnabled()) {
	    throw new AssertionError(buttonName + " button is ENABLED (Expected: Disabled)");
	}
	
	System.out.println("✅ " + buttonName + " button is DISABLED");
	}    
	
	
	//REFERRAL SUMMARY DISPLAYED
	@Then("referral advice summary should be displayed")
	public void summary_should_be_displayed() {
	clinical.verifyReferralSummaryDisplayed();
	}
	
	//REFERRAL SUMMARY NOT DISPLAYED
	@Then("referral advice summary should be not displayed")
	public void summary_should_be_not_displayed() {
	clinical.verifyReferralSummaryNotDisplayed();
	}
	
	//REFERRAL SUMMARY DELETE ICON
	@And("user clicks referral advice summary delete icon")
	public void summary_delete_icon() {
	clinical.ClickReferralSummaryDeleteIcon();
	}   
	
	//REFERRAL SUMMARY PRINT ICON
	@And("user clicks referral advice summary print icon")
	public void summary_print_icon() {
	clinical.ClickReferralSummaryPrintIcon();
	}    
	
	//REFERRAL SUMMARY INFO ICON
	@When("user hovers referral advice summary info icon")
	public void summary_info_icon() {
	clinical.ClickReferralSummaryInfoIcon();
	}    
	@Then("patient info {string} should be displayed")
	public void validate_patient_info(String name) {
	clinical.verifyPatientInfoDisplayed(name);
	} 


// DRUG PRESCRIPTION (DP) ADVICE
	
	//SELECT EYE AND DRUG
	@And("I select {string} for {string} drug")
	public void select_eye_drug(String drug, String eye) {
	 clinical.selectEyeDrug(drug,eye);
	}
	
	//SELECT DRUG NAME
	@And("I click {string} drug option for BE")
	public void select_drug(String drug) {
		clinical.selectDrug(drug);
	}

	// EYE TYPE SELECTION DROPDOWN
	@And("I select eye type {string} in DP")
	public void select_eye_type_drug(String drug) {
		clinical.selectEyeTypeDP(drug);
	}

	// DRUG NAME SELECTION DROPDOWN
	@And("I select drug name {string} in DP")
	public void select_drug_name_dropdown(String drug) {
		clinical.selectDrugNameDP(drug);
	}

	// DRUG FREQUENCY SELECTION DROPDOWN
	@And("I select frequency {string} in DP")
	public void select_frequency_dropdown(String frequency) {
		clinical.selectFrequencyDropDP(frequency);
	}

	// DURATION INPUT
	@And("I enter duration {string} in DP")
	public void enter_duration_in_DP(String duration) {
		clinical.enterDurationDP(duration);
	}

	// DURATION TYPE IN DP
	@And("I select duration Type {string} in DP")
	public void select_Duration_type_dropdown_DP(String type) {
		clinical.selectDurationTypeDP(type);
	}

	// DURATION INPUT
	@And("I enter remarks {string} in DP")
	public void enter_remarks_in_DP(String remark) {
		clinical.enterRemarkDP(remark);
	}
	
	// PRESCRIPTION LANGUAGE IN DP
	@And("I select prescription language {string} in DP")
	public void select_language_prescription_dropdown_DP(String language) {
		clinical.selectPresLanguageDP(language);
	}
	
	// BUTTON ACTIONS IN DP
	@And("I click {string} button in DP")
	public void button_actions_DP(String btn) {
		clinical.buttonActionsDP(btn);
	}
	
	// VISIBILITY OF ADDED DRUG DETAILS
	@Then("added drug details should be displayed")
	public void validate_added_drug() {

	    String drugName = "Aurosol";

	    String page = DriverFactory.getDriver().getPageSource();

	    if (!page.contains(drugName)) {
	        throw new AssertionError("Drug details not displayed");
	    }

	    System.out.println("Drug details displayed successfully");
	}

    // DELETE ICON ACTION AFTER ADD DRUG DETAILS
	@Then("I click delete icon for {string}")
	public void click_delete_icon(String drugName) {
	    WebElement deleteBtn = wait.until(ExpectedConditions.elementToBeClickable(clinicalRecordsLocator.deleteIcon(drugName)));

	    deleteBtn.click();

	    System.out.println("Delete icon clicked");
	}

// DRUG PRESCRIPTION (DP) SUMMARY 
	
	//DP SUMMARY DISPLAYED
	@Then("DP advice summary should be displayed")
	public void DP_summary_should_be_displayed() {
	clinical.verifyDPSummaryDisplayed();
	}
	
	//DP SUMMARY NOT DISPLAYED
	@Then("DP advice summary should be not displayed")
	public void DP_summary_should_be_not_displayed() {
	clinical.verifyDPSummaryNotDisplayed();
	}
	
	//DP SUMMARY DELETE ICON
	@And("I click DP advice summary delete icon")
	public void DP_summary_delete_icon() {
	clinical.ClickDPSummaryDeleteIcon();
	}   
	
	//DP SUMMARY PRINT ICON
	@And("I click DP advice summary print icon")
	public void DP_summary_print_icon() {
	clinical.ClickDPSummaryPrintIcon();
	}    
	
	//DP SUMMARY INFO ICON
	@When("I hover DP advice summary info icon")
	public void DP_summary_info_icon() {
	clinical.ClickDPSummaryInfoIcon();
	}    
	@Then("patient info {string} should be displayed in DP")
	public void validate_patient_info_DP(String name) {
	clinical.verifyPatientInfoDisplayedDP(name);
	}

	// PRESCRIPTION LANGUAGE PRINT CHECKING PROCESS
	@Then("prescription should be displayed in {string}")
	public void validate_prescription_language(String language) {

	    String text = DriverFactory.getDriver().findElement(By.tagName("body")).getText();

	    if (language.equalsIgnoreCase("தமிழ்")) {

//		        if (!text.matches(".*[\\u0B80-\\u0BFF].*")) {
//		            throw new AssertionError("Tamil content not displayed");
//		        }

	        if (!(text.matches("முறை") || text.matches("கண்") || text.matches("நாட்கள்"))) {
	            throw new AssertionError("Prescription not displayed in Tamil");
	        }

	    } else if (language.equalsIgnoreCase("English")) {

	        if (!(text.contains("Times") || text.contains("Days") || text.contains("Eye"))) {
	            throw new AssertionError("Prescription not displayed in English");
	        }
	    }

	    System.out.println("Prescription displayed in " + language);
	}
	

//SURGERY ADVICE 
	
	    //SELECT EYE
		@And("I select label as {string} and option as {string} in surgery advice")
		public void select_eye_surgery(String label, String eye) {
			clinical.selectEyeSurgery(label,eye);
		}
		
		//SELECT SURGERY NAME IN OTHERS
		@And("I select {string} from other surgery")
		public void select_surgery_name(String name) {
			clinical.selectSurgeryDropdown(name);
		}

		//REMARKS 
		@And("I enter remarks {string} in surgery")
		public void enter_remarks_surgery(String remark) {
			clinical.enterRemarkSurgery(remark);
		}

		// SURGERY DATE  
		@And("I enter surgery date as {string}")
		public void enter_surgery_date(String date) {
			clinical.enterSurgeryDate(date);
		}

		//SELECT REASON FOR NOT CONFIRMED DATE SURGERY
		@And("I select reason for surgery date not confirmed is {string}")
		public void select_surgery_reason_not_date_confirmed(String reason) {
			clinical.selectSurgeryReasonDropdown(reason);
		}

		// BUTTON ACTIONS IN SURGERY ADVICE
		@And("I click {string} button in surgery advice")
		public void button_actions_surgery(String btn) {
			clinical.buttonActionsSurgery(btn);
		}
		
		// BUTTON ACTIONS IN SURGERY COUNSELLING ADVICE
		@And("I click {string} button in surgery counselling advice")
		public void button_actions_surgery_counselling(String btn) {
			clinical.buttonActionsSurgeryCounselling(btn);
		}
		
		
// SURGERY ADVICE SUMMARY
		
		// LINK ACTIONS IN SURGERY ADVICE SUMMARY
		@And("I click {string} link in surgery advice summary")
		public void link_actions_surgery(String link) {
			clinical.linkActionsSurgery(link);
		}
				
		//SURGERY ADVICE SUMMARY DISPLAYED
		@Then("surgery advice summary should be displayed")
		public void surgery_summary_should_be_displayed() {
		clinical.verifySurgerySummaryDisplayed();
		}
		
		//SURGERY ADVICE SUMMARY NOT DISPLAYED
		@Then("surgery advice summary should be not displayed")
		public void surgery_summary_should_be_not_displayed() {
		clinical.verifySurgerySummaryNotDisplayed();
		}
		
		//SURGERY ADVICE SUMMARY DELETE ICON
		@And("I click surgery advice summary delete icon")
		public void surgery_summary_delete_icon() {
		clinical.ClickSurgerySummaryDeleteIcon();
		}   

		//SURGERY ADVICE SUMMARY INFO ICON
		@When("I hover surgery advice summary info icon")
		public void surgery_summary_info_icon() {
		clinical.ClickSurgerySummaryInfoIcon();
		}    
		@Then("patient info {string} should be displayed in surgery")
		public void validate_patient_info_surgery(String name) {
		clinical.verifyPatientInfoDisplayedSurgery(name);
		}























    
    
    
}
