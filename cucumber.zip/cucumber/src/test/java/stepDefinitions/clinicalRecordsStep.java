package stepDefinitions;


import io.cucumber.java.en.*;
import locators.clinicalRecordsLocator;
import pages.clinicalRecordsPage;
import utils.DriverFactory;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class clinicalRecordsStep {

	clinicalRecordsPage clinical;
    WebDriverWait wait;

    public clinicalRecordsStep() {
    	clinical = new clinicalRecordsPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
//  CLINICAL RECORDS OPTION CLICK
    @And("user clicks on clinical records option")
    public void user_clicks_clinical_records_page() {
    	clinical.clickClinicalRecordsOption();  
    }
    
    @Then("user navigated to the clinical records dashboard page")
    public void user_navigated_to_clinical_records_page() {
        wait.until(ExpectedConditions.urlContains("2"));
        System.out.println("User is navigated to Clinical Records page");
    }

// PATIENT SEARCH ICON
    @And("user clicks patient status search icon")
    public void user_clicks_patient_status_search_page() {
    	clinical.clickPatientStatusSearch();  
    }
// DOCTOR SCREEN NAVIGATION
    @Then("user navigated to the doctor screen page")
    public void user_navigated_to_doctor_screeen_page() {
        wait.until(ExpectedConditions.urlContains("doctor-screen/"));
        System.out.println("User is navigated to Doctor screen page");
    }   
    
 // REPORT VIEW ICON 
    @And("user clicks report view icon")
    public void user_clicks_report_view_icon() {
    	clinical.clickReportViewIcon();  
    }  
    
//  ENTER PIN NUMBER
  @And("user enters pin {string}")
  public void user_entersPin(String pin) {
	  clinical.enterPin(pin);
  }
       
//  VISION 
  // VISION CHART 
    @And("user selects vision chart {string} dropdown")
    public void user_clicks_dropdown(String option) {
    	clinical.selectVisionChart(option);
    } 
//   UCVA DROPDOWN
    @And("user selects RE {string} and LE {string} in UCVA dropdown")
    public void user_selects_re_and_le_in_ucva_dropdown(String reValue, String leValue) {
        clinical.selectUCVA(reValue, leValue);
    }
    
//  UCVAph DROPDOWN
   @And("user selects RE {string} and LE {string} in UCVAph dropdown")
   public void user_selects_re_and_le_in_ucvaph_dropdown(String reValue, String leValue) {
       clinical.selectUCVAph(reValue, leValue);
   }
    
    
// METHOS DROPDOWN IN VISION 
    @And("user selects method {string} dropdown")
    public void user_clicks_method_dropdown(String option) {
    	clinical.selectMethod(option);
    }
//  SAVE BUTTON FOR VISION   
    @And("user clicks save button in vision")
    public void user_clicks_save_button_vision() {
    	clinical.clickSaveBtn();
    }  
    
    
// REFERRAL ADVICE 

//  HOSPITAL DROPDOWN
    @And("user selects hospital name {string} dropdown")
    public void user_selects_hospital_name_dropdown(String value) {
    	clinical.selectHospitalDropdown(value);
    } 
        
//  CLINIC DROPDOWN
  @And("user selects clinic name {string} dropdown")
  public void user_selects_clinic_name_dropdown(String value) {
  	clinical.selectclinicDropdown(value);
  }    
    
//REASON FOR REFERRAL DROPDOWN
@And("user selects reason for referral {string} dropdown")
public void user_selects_reason_for_referral_dropdown(String value) {
	clinical.selectReasonRefDropdown(value);
}   
    
//SAVE BUTTON FOR REASON FOR REFERRAL   
@And("user clicks save button in referral")
public void user_clicks_save_button_referral() {
	clinical.clickSaveRefBtn();
}    
    
  
@Then("hospital name Required alert should be appear referral advice")
public void validate_hospital_require() {
    validateRequiredAlert(clinicalRecordsLocator.hospitalNameerrorMsg,"Please select Hospital");
}   

@Then("clinic name Required alert should be appear referral advice")
public void validate_clinic_require() {
    validateRequiredAlert(clinicalRecordsLocator.clinicNameerrorMsg,"Please select Clinic");
} 

@Then("reason for referral Required alert should be appear referral advice")
public void validate_referralReason_require() {
    validateRequiredAlert(clinicalRecordsLocator.reasonForReferrorMsg,"Please select at least one Referral Reason");
} 
    
//EMPTY FIELD ACTION FOR ALL FIELDS
public void validateRequiredAlert(By locator, String expectedMsg) {

    boolean isPresent = wait.until(driver -> {
        List<WebElement> elements = driver.findElements(locator);

        for (WebElement el : elements) {
            if (el.getText().trim().equalsIgnoreCase(expectedMsg)) {
                return true;
            }
        }
        return false;
    });

    if (!isPresent) {
        throw new AssertionError("❌ Expected alert not found: " + expectedMsg);
    }

    System.out.println("✅ Alert displayed: " + expectedMsg);
}  
    
    
@Then("{string} button should be disabled")
public void button_should_be_disabled(String buttonName) {
    verifyButtonDisabled(clinicalRecordsLocator.buttonByText(buttonName), buttonName);
}

public void verifyButtonDisabled(By locator, String buttonName) {

    WebElement button = wait.until(
        ExpectedConditions.presenceOfElementLocated(locator)
    );

    if (button.isEnabled()) {
        throw new AssertionError(buttonName + " button is ENABLED (Expected: Disabled)");
    }

    System.out.println("✅ " + buttonName + " button is DISABLED");
}    
  

// REFERRAL SUMMARY DISPLAYED
@Then("referral advice summary should be displayed")
public void summary_should_be_displayed() {
	clinical.verifyReferralSummaryDisplayed();
}

//REFERRAL SUMMARY NOT DISPLAYED
@Then("referral advice summary should be not displayed")
public void summary_should_be_not_displayed() {
	clinical.verifyReferralSummaryNotDisplayed();
}

//REFERRAL SUMMARY DELETE ICON
@And("user clicks referral advice summary delete icon")
public void summary_delete_icon() {
	clinical.ClickReferralSummaryDeleteIcon();
}   
    
//REFERRAL SUMMARY PRINT ICON
@And("user clicks referral advice summary print icon")
public void summary_print_icon() {
	clinical.ClickReferralSummaryPrintIcon();
}    
  
//REFERRAL SUMMARY PRINT ICON
@When("user hovers referral advice summary info icon")
public void summary_info_icon() {
	clinical.ClickReferralSummaryInfoIcon();
}    
@Then("patient info {string} should be displayed")
public void validate_patient_info(String name) {
	clinical.verifyPatientInfoDisplayed(name);
}    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
