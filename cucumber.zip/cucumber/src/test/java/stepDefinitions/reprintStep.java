package stepDefinitions;

import io.cucumber.java.en.*;
import locators.reprintLocator;
import pages.reprintPage;
import utils.DriverFactory;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class reprintStep {

    reprintPage reprint;
    WebDriverWait wait;

    public reprintStep() {
    	reprint = new reprintPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }

//    REPRINT BUTTON 
    @When("user clicks on Reprint button")
    public void user_clicks_reprint_button() {
        reprint.clickReprintBtn();  
    }
//	  REPRINT POP-UP
    @Then("reprint popup should be displayed")
    public void reprint_popup_is_displayed() {
        System.out.println("Reprint popup is displayed successfully");
    }
    
//	PATIENT TYPE
	  @And("user selects patient type {string}")
	  public void user_selects_patientType(String patientType) {
	      reprint.selectpatientType(patientType);
	  }
	  
//  ENTER DATE 
	    @And("user enters date {string} in reprint")
	    public void user_enters_date_reprint(String date) {
	        reprint.enterDate(date);
	    }	  
	 
//  ENTER OID 
    @And("user enters OID {string} in reprint")
    public void user_enters_OID_reprint(String oid) {
        reprint.enterOid(oid);
    }
 
 
//	AFTER CLICK SEARCH ICON ---> VALID OID
  @Then("patient name should be visible in reprint")
  public void patient_name_should_be_visible_reprint() {
	  WebElement nameElement = wait.until( ExpectedConditions.visibilityOfElementLocated(reprintLocator.patientNameValue));

		String patientName = nameElement.getText().trim();

		// ✅ Positive validation
		Assert.assertTrue(!patientName.isEmpty(), "Patient name is displayed");

		System.out.println("Patient name displayed: " + patientName);
  }

//  SUBMIT BUTTON
  @When("user clicks on Submit button in reprint")
  public void user_clicks_submit_button_reprint() {
	    reprint.clickSubmitBtn();
  }
  
  @Then("print preview should be displayed")
  public void patient_address_details_are_displayed_reprint() {
	  System.out.println("Patient print preview details are displayed correctly");
  }

  @Then("user closes print preview")
  public void close_print_preview() throws Exception {

      WebDriver driver = DriverFactory.getDriver();

      Thread.sleep(2000);

      // Focus browser
      driver.switchTo().window(driver.getWindowHandle());
      driver.findElement(By.tagName("body")).click();

      // ESC using Robot (most reliable)
      Robot robot = new Robot();
      robot.keyPress(KeyEvent.VK_ESCAPE);
      robot.keyRelease(KeyEvent.VK_ESCAPE);

      System.out.println("Closed print preview using ESC");
  }
	  

//  CANCEL BUTTON
  @And("user clicks on Cancel button in reprint")
  public void user_clicks_cancel_button_reprint() {
      reprint.clickCancelBtn();
  }   
  
//   CLOSE BUTTON
@And("user clicks on Close button in reprint")
public void user_clicks_close_button_reprint() {
    reprint.clickCloseBtn();
}    
    
//	IF EMPTY FIELD ---> REQUIRED VALIDATION
@Then("submit button should be disable in reprint")
public void validate_submit_oid_empty_field_reprint() {

	 WebElement submitBtn = wait.until(ExpectedConditions.presenceOfElementLocated(reprintLocator.submitBtn));
     
     Assert.assertFalse(submitBtn.isEnabled());
}
    
//DATE FIELD ---> DATE FIELD DISABLE WHEN PATIENT TYPE IS NEW
@Then("date field should be disable")
public void login_button_should_be_disabled() {

  WebElement dateField = wait.until(ExpectedConditions.presenceOfElementLocated(reprintLocator.dateInput));
      
      Assert.assertFalse(dateField.isEnabled());
}   
 
//IF PATIENT NOT REG TODAY ----> PREVIOUS DAY OID
@And("error message {string} should be displayed in reprint")
public void error_message_should_be_displayed_reprint(String expectedMsg) {

 WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Patients not registered today cannot be reprinted.')]")));

 String actualMsg = errorMsg.getText().trim();

 Assert.assertEquals(actualMsg, expectedMsg);
}

//IF EMPTY FIELD ---> REQUIRED VALIDATION

@And("Required alert {string} should be appear in reprint")
public void validate_oid_empty_field_reprint(String expectedMsg) {

	WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(reprintLocator.requiredAlert));
	

		    String actualMsg = errorMsg.getText().trim();

		    Assert.assertEquals(actualMsg, expectedMsg);
} 















    
}