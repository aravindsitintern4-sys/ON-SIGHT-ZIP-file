package stepDefinitions;

import io.cucumber.java.en.*;
import pages.LoginPage;
import utils.DriverFactory;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import locators.LoginLocator;

public class LoginSteps {

    LoginPage login = new LoginPage(DriverFactory.getDriver());
    WebDriverWait wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));

    
    @Given("user is on login page")
    public void user_is_on_login_page() {

        WebDriver driver = DriverFactory.getDriver();

        driver.get("https://onsight-qa.aravind.org/");

        // IF ALREADY LOG IN ---> LOGOUT
        if (driver.getCurrentUrl().contains("pick-event")) {
            driver.findElement(By.xpath("//button[@class='btn btn-danger' and normalize-space()='Cancel']")).click();
        }
    }
    
    @And("user enters username {string} and password {string}")
    public void enter_credentials(String username, String password) {
        login.enterUsername(username);
        login.enterPassword(password);
    }

    @And("clicks on login button")
    public void click_login() {
        login.clickLogin();
    }


//    VAILD ACTION
    @Then("user is navigated to outReach Event setup page")
    public void user_is_navigated_to_out_reach_event_setup_page() {
    	
    	wait.until(ExpectedConditions.urlContains("pick-event"));
    	System.out.println("Successfully navigated into OutReach Event set up page");
    }
    
//    ERROR MESSEGE ---> INVALID ACTION
    @Then("error message should be displayed")
    public void error_message_should_be_displayed() {

        WebElement error = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Login Failed')]")));
        Assert.assertTrue(error.isDisplayed());
        System.out.println("Error messege is displayed");
    }
    
//    EMPTY FIELDS ---> BUTTON DISABLE
    @Then("login button should be disabled")
    public void login_button_should_be_disabled() {

        WebElement loginBtn = wait.until(ExpectedConditions.presenceOfElementLocated(LoginLocator.loginBtn));
            
            Assert.assertFalse(loginBtn.isEnabled());
}
}