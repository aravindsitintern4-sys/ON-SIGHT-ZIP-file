package stepDefinitions;

import io.cucumber.java.en.*;
import locators.outReachMasterLocator;
import pages.outReachMasterPage;
import utils.DriverFactory;
import java.time.Duration;
import java.time.LocalDate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;



public class outReachMasterStep {

    outReachMasterPage outReachMaster;
    WebDriverWait wait;

    public outReachMasterStep() {
    	outReachMaster = new outReachMasterPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
//  MASTER OPTION CLICK
    @And("I click on master option")
    public void navigates_master_page() {
    	outReachMaster.clickMasterOption();  
    }
    
    @Then("I navigated to the master page")
    public void navigated_to_master_page() {
        wait.until(ExpectedConditions.urlContains("master"));
        System.out.println("User is navigated to Master page");
    }
    
 // OUTREACH EVENT MASTER   
    @And("I click on outReach event master option")
    public void navigates_outreachmaster_page() {
    	outReachMaster.clickOutReachMasterOption();  
    }
    
    @Then("I navigated to the outreach event master page")
    public void navigated_to_outreachmaster_page() {
        wait.until(ExpectedConditions.urlContains("event"));
        System.out.println("User is navigated to OutReach Event Master page");
    } 

//  CREATE NEW EVENT ---> NEW BUTTON 
@And("I click New button in outreach event master")
public void click_new_button_outReachMaster() {
	outReachMaster.clickNewBtn();  
}

@Then("new event creation popup should be displayed")
public void new_event_creation_popup_displayed() {
	WebElement popup = wait.until( ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.popup));

	Assert.assertTrue(popup.isDisplayed());
    System.out.println("New event creation popup is displayed");
}     

// SAVE BUTTON   
@And("I click save button in event popup")
public void click_save_button_newEvent_popup() {
	outReachMaster.clickSaveButton();  
}

// CLEAR BUTTON    
@And("I click clear button in event popup")
public void click_clear_button_newEvent_popup() {
	outReachMaster.clickClearButton();  
}

// CANCEL BUTTON    
@And("I click cancel button in event popup")
public void click_cancel_button_newEvent_popup() {
	outReachMaster.clickCancelButton();  
}

// ORGANIZER NAME 
@And("I select event organizer name {string} dropdown")
public void select_organizer_name(String eventOrgName) {
	outReachMaster.selectOrganizerName(eventOrgName);  
}    
    
@Then("organizer name Required alert should be appear")
public void validate_organize_name_empty_field() {
	validateRequiredAlert(outReachMasterLocator.orgNameerrorMsg, "Event Organizer Name");
}    
    
// HOSPITAL NAME 
@And("I select hospital {string} dropdown")
public void select_hospital_name(String hospitalName) {
	outReachMaster.selectHospitalName(hospitalName);  
}    
 
@Then("I should see hospital name empty field validation in outreach")
public void validate_hospital_name_empty_field_outReachEvent() {
	validateRequiredAlert(outReachMasterLocator.hospitalNameerrorMsg, "Hospital Name");
}   

//ACTIVE VALIDATION
@And("I click active checkbox")
public void click_active_checkbox() {
	outReachMaster.clickActiveCheckbox();  
}
    
//PLACE 
@And("I enter place {string}")
public void enter_place_name(String place) {
	outReachMaster.enterPlaceName(place);  
}    

@Then("place Required alert should be appear")
public void validate_place_name_empty_field() {
	validateRequiredAlert(outReachMasterLocator.placeerrorMsg, "Place");
}

// CITY
@And("I select city {string} dropdown")
public void enter_city_name_event(String city) {
	outReachMaster.selectCityName(city);  
}    

@Then("city Required alert should be appear")
public void validate_city_name_empty_field() {
	validateRequiredAlert(outReachMasterLocator.cityerrorMsg, "City / Taluk");
}

    
//DISTRICT 
@And("I select district {string} dropdown")
public void selects_district_name(String district) {
	outReachMaster.selectDistrictName(district);  
}    

@Then("district Required alert should be appear")
public void validate_district_name_empty_field() {
	validateRequiredAlert(outReachMasterLocator.districterrorMsg, "District");
} 

//DISTANCE FROM HQ 
@And("I select distance {string} dropdown")
public void select_distace_from_HQ(String distance) {
	outReachMaster.selectDistance(distance);  
}    

@Then("Distance From HQ Required alert should be appear")
public void validate_distance_HQ_empty_field() {
	validateRequiredAlert(outReachMasterLocator.distanceerrorMsg, "Distance From HQ");
} 

//LANGUAGE OF PRESCRIPTION
@And("I select language of prescription {string} dropdown")
public void select_language_of_prescription(String language) {
	outReachMaster.selectLanguage(language);  
}    
//                             CHANGE THE FIELD NAME
@Then("Language for Prescription Required alert should be appear")
public void validate_language_of_prescription_empty_field() {
	validateRequiredAlert(outReachMasterLocator.languageerrorMsg,"Distance From HQ");
}

//EVENT TYPE
@And("I select event type {string} dropdown")
public void select_event_type(String eventType) {
	outReachMaster.selectEventType(eventType);  
}    

@Then("Event Type Required alert should be appear")
public void validate_event_type_empty_field() {
	validateRequiredAlert(outReachMasterLocator.eventTypeerrorMsg,"Event Type");
}

//EVENT LOCATION TYPE 
@And("I select event location {string} dropdown")
public void select_event_location_name(String eventLocation) {
	outReachMaster.selectEventLocation(eventLocation);  
}    

@Then("Event Location Required alert should be appear")
public void validate_event_location_empty_field() {
	validateRequiredAlert(outReachMasterLocator.eventLocationerrorMsg, "Event Location");  
}   
  
//PROJECT NAME
@And("I select project name {string} dropdown")
public void select_project_name(String project) {
	outReachMaster.selectProject(project);  
}    

// LOCAL PERTNER NAME
@And("I enter local partner {string}")
public void enter_local_partner(String localPartner) {
	outReachMaster.enterLocalPartner(localPartner);  
} 

//IHMS CAMP ID
@And("I enter camp id {string} in event")
public void user_enter_campid_event(String campid) {
	outReachMaster.enterCampId(campid);  
}

@Then("validation for IHMS camp id field")
public void validate_campid() {
	validateCampIdField(outReachMasterLocator.campIdInput, "IHMS camp id");
}

// START DATE THROUGH CALENDER    

// START CALENDER
@And("I click event start date calendar icon")
public void click_start_date_calendar() {
 outReachMaster.clickStartDateCalendar();
}

//SELECT START MONTH
@And("I select start month {string}")
public void select_start_month(String month) {
 outReachMaster.selectStartMonth(month);
}

//SELECT START YEAR
@And("I select start year {string}")
public void select_start_year(String year) {
 outReachMaster.selectStartYear(year);
}

//SELECT START DATE
@And("I select start date {string} from date picker")
public void select_start_date(String date) {
 outReachMaster.selectStartDate(date);
}

//VERIFY START DATE
@Then("selected date should be displayed in event start date field")
public void verify_start_date() {
	 String value = outReachMaster.getSelectedStartDate();
	 Assert.assertTrue(value != null && !value.isEmpty(), "Start date not selected");
	 System.out.println("Start Date: " + value);
}

//START DATE REQUIRED
@Then("start date Required alert should be appear")
public void validate_start_date_empty_field() {
	validateRequiredAlert(outReachMasterLocator.startDateerrorMsg, "Stard Date");
}

//PAST DATE VALIDATION
@Then("past dates should be disabled in date picker")
public void verify_past_dates_disabled() { 
	 LocalDate today = LocalDate.now();
	    int currentDay = today.getDayOfMonth();

	    for (int day = 1; day < currentDay; day++) {

	        WebElement date = DriverFactory.getDriver().findElement(
	                By.xpath("//div[@role='gridcell' and @aria-label[contains(.,', June ')]]" +"[.//div[text()='" + day + "']]"));

	        Assert.assertEquals(date.getAttribute("aria-disabled"),"true","Past date " + day + " is enabled");
	    }

	    System.out.println("All past dates are disabled");
	}



//END DATE 

//OPEN END DATE CALENDER
@And("I click event end date calendar icon")
public void click_end_date_calendar() {
 outReachMaster.clickEndDateCalendar();
}

//SELECT END MONTH
@And("I select end month {string}")
public void select_end_month(String month) {
 outReachMaster.selectEndMonth(month);
}

//SELECT END YEAR
@And("I select end year {string}")
public void select_end_year(String year) {
 outReachMaster.selectEndYear(year);
}

//SELECT END DATE
@And("I select end date {string} from date picker")
public void select_end_date(String date) {
 outReachMaster.selectEndDate(date);
}

@Then("selected date should be displayed in event end date field")
public void verify_end_date() {
	 String value = outReachMaster.getSelectedEndDate();
	 Assert.assertTrue(value != null && !value.isEmpty(), "End date not selected");
	 System.out.println("End Date: " + value);
}

//END DATE --> EMPTY FIELDS
@Then("end date Required alert should be appear")
public void validate_end_date_empty_field() {
	validateRequiredAlert(outReachMasterLocator.endDateerrorMsg, "End Date");
}
    


//EXPECTED OP VALIDATION
@And("I enter expected op {string}")
public void enter_expected_op(String op) {
	outReachMaster.enterExpectedOP(op);  
}

@Then("validation for expected op field")
public void validate_expected_op_length() {

    WebElement field = DriverFactory.getDriver().findElement(outReachMasterLocator.expectedOPInput);
    String value = field.getAttribute("value");
    // ALLOWS ONLY NUMBERS  
    if (!value.matches("\\d*")) {
        throw new AssertionError("Expected OP contains invalid characters: " + value);
    }
    // CHECK LEGNTH OF PINCODE
    if (value.length() > 3) {
        throw new AssertionError("Expected OP accepts more than 3 digits: " + value);
    }
    System.out.println("Expected OP accepted correctly: " + value);
}   

@Then("Expected op Required alert should be appear")
public void validate_expected_op_empty_field() {
	validateRequiredAlert(outReachMasterLocator.expectedOPerrorMsg, "Expected OP");  
}

//EXPECTED IP VALIDATION
@And("I enter expected ip {string}")
public void enter_expected_ip(String ip) {
	outReachMaster.enterExpectedIP(ip);  
}

@Then("validation for expected ip field")
public void validate_expected_ip() {
    validatePercentageField(outReachMasterLocator.expectedIPInput, "Expected IP");
}

@Then("Expected ip Required alert should be appear")
public void validate_expected_ip_empty_field() {
	validateRequiredAlert(outReachMasterLocator.expectedIPerrorMsg, "Expected IP");
}

//EXPECTED SPECIALITY REFERRAL VALIDATION
@And("I enter expected speciality referral {string}")
public void enter_expected_speciality_referral(String specRef) {
	outReachMaster.enterExpectedSpecReferral(specRef);  
}

@Then("validation for expected speciality referral field")
public void validate_expected_speciality_referral() {
	validatePercentageField(outReachMasterLocator.expectedSpecRefInput, "Expected Speciality Referral");
} 

@Then("Expected speciality referral Required alert should be appear")
public void validate_expected_speciality_referral_empty_field() {
	validateRequiredAlert(outReachMasterLocator.expectedSpecReferrorMsg, "Expected Speciality");
}

//EXPECTED GP VALIDATION
@And("I enter expected GP {string}")
public void enter_expected_GP(String gp) {
	outReachMaster.enterExpectedGP(gp);  
}

@Then("validation for expected GP field")
public void validate_expected_gp() {
	validatePercentageField(outReachMasterLocator.expectedGPInput, "Expected GP");
} 

@Then("Expected GP Required alert should be appear")
public void validate_expected_GP_empty_field() {
	 validateRequiredAlert(outReachMasterLocator.expectedGPerrorMsg, "Expected GP");
}


//  VALIDATE PERCENTAGE FIELDS ---> IP, SPECIALITY REFERRAL, GP
public void validatePercentageField(By locator, String fieldName) {

    WebElement field = DriverFactory.getDriver().findElement(locator);
    String value = field.getAttribute("value");

    // ALLOW ONLY NUMBERS
    if (!value.matches("\\d+")) {
        throw new AssertionError(fieldName + " contains invalid characters: " + value);
    }
   // RANGE CHECK
    int number = Integer.parseInt(value);
    if (number < 0 || number > 100) {
        throw new AssertionError(fieldName + " should be between 0 and 100: " + value);
    }
}

// EMPTY FIELD ACTION FOR ALL FIELDS
public void validateRequiredAlert(By locator, String fieldName) {

    WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

    if (!errorMsg.isDisplayed()) {
        throw new AssertionError(fieldName + " is required");
    }

    System.out.println(fieldName + " required alert is displayed");
}


//VALIDATE RANGE FIELDS ---> CAMP CODE
public void validateCampIdField(By locator, String fieldName) {

	WebElement field = DriverFactory.getDriver().findElement(locator);
	String value = field.getAttribute("value");
	
	// ALLOW ONLY NUMBERS
	if (!value.matches("\\d+")) {
	    throw new AssertionError(fieldName + " contains invalid characters: " + value);
	}
	// RANGE CHECK
	int number = Integer.parseInt(value);
	if (number < 0 || number > 99999) {
	    throw new AssertionError(fieldName + " should be between 0 and 99999: " + value);
	}
}


@Then("no data found messege should be displayed in dropdown in event")
public void validate_no_data_found_message() {

	 WebDriverWait wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));

	 WebElement noDataMsg = wait.until(
			    ExpectedConditions.visibilityOfElementLocated(
			        By.xpath("//strong[normalize-space()='No data found'] | " +
			                 "//*[contains(normalize-space(.),'No data')] | " +
			                 "//*[contains(normalize-space(.),'no data')]")));

	 String actualMsg = noDataMsg.getText().trim();

	 Assert.assertTrue(
	     actualMsg.contains("No data found") ||
	     actualMsg.contains("No data"),
	     "Expected 'No data' message but got: " + actualMsg
	 );

	 System.out.println("Message displayed: " + actualMsg);
}



// EDIT BUTTON WORKFLOW

@Given("I am on event management page")
public void event_page() {

    DriverFactory.getDriver().navigate().refresh();

    wait.until(ExpectedConditions.visibilityOfElementLocated(
        By.xpath("//table//tbody//tr")
    ));
}

// EDIT BUTTON
@And("I enter data in search bar {string}")
public void enter_eventId_on_search_bar(String data) {
    outReachMaster.enterEventIdInSearchBar(data);
}

//VALIDATE EVENT LIST DISPLAYED
@Then("event details for data {string} should be displayed")
public void validate_event_displayed_with_eventID_searchbox(String data) {

  WebElement row = wait.until(ExpectedConditions.visibilityOfElementLocated(getRowByData(data)));

  if (!row.isDisplayed()) {
      throw new AssertionError("Event not found: " + data);
  }
}

public static By getRowByData(String data) {
    return By.xpath("//table//tbody//tr[.//td[contains(normalize-space(),'" + data + "')]]");
}

@And("user clears search bar")
public void clear_search_bar_in_event() {
	outReachMaster.clickClearSearch();
}

// SELECT CHECK BOX
@When("I select checkbox for data {string}")
public void select_checkbox_for_event(String data) {

    WebElement row = wait.until(ExpectedConditions.visibilityOfElementLocated(getRowByData(data)));

    WebElement checkbox = wait.until(ExpectedConditions.elementToBeClickable(row.findElement(By.xpath(".//input[@type='checkbox']"))));

    // Click only if not already selected
    if (!checkbox.isSelected()) {
        checkbox.click();
    }
}

@Then("checkbox for data {string} should be selected")
public void validate_checkbox_selected(String data) {

    WebElement row = DriverFactory.getDriver().findElement(getRowByData(data));
    WebElement checkbox = row.findElement(By.xpath(".//input[@type='checkbox']"));

    if (!checkbox.isSelected()) {
        throw new AssertionError("Checkbox not selected for event id: " + data);
    }
}


// CLICK EDIT BUTTON
@And("I click on edit button in Event")
public void click_edit_button_in_event() {
	outReachMaster.clickEditBtn();
}

// VALIDATE POPUP DISPLAYED
@Then("event creation popup with existing details should be displayed")
public void validate_edit_popup_displayed() {
	WebElement popup = wait.until( ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.popup));

    if (!popup.isDisplayed()) {
        throw new AssertionError("Edit popup is not displayed");
    }

}


// UPDATE BUTTON
@And("I click update button in event")
public void click_update_button() {
    outReachMaster.clickUpdateBtn();
}

//DELETE BUTTON
@And("I click on delete button in Event")
public void click_delete_button() {
	outReachMaster.clickDeleteBtn();
}

// CONFIRMATION FOR DELETE
@And("I click on Confirmation ok in Event")
public void click_confirmation_ok_button() {
	outReachMaster.clickOKBtn();
}
//CONFIRMATION FOR DELETE
@And("I click on Confirmation Cancel in Event")
public void click_confirmation_cancel_button() {
	outReachMaster.clickCancelBtn();
}


























}