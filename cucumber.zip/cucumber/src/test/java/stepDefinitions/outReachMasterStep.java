package stepDefinitions;

import io.cucumber.java.en.*;
import locators.outReachMasterLocator;
import pages.outReachMasterPage;
import utils.DriverFactory;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;



public class outReachMasterStep {

    outReachMasterPage outReachMaster;
    WebDriverWait wait;

    public outReachMasterStep() {
    	outReachMaster = new outReachMasterPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
//  MASTER OPTION CLICK
    @And("user clicks on master option")
    public void user_navigates_master_page() {
    	outReachMaster.clickMasterOption();  
    }
    
    @Then("user navigated to the master page")
    public void user_navigated_to_master_page() {
        wait.until(ExpectedConditions.urlContains("master"));
        System.out.println("User is navigated to Master page");
    }
    
 // OUTREACH EVENT MASTER   
    @And("user clicks on outReach event master option")
    public void user_navigates_outreachmaster_page() {
    	outReachMaster.clickOutReachMasterOption();  
    }
    
    @Then("user navigated to the outreach event master page")
    public void user_navigated_to_outreachmaster_page() {
        wait.until(ExpectedConditions.urlContains("event"));
        System.out.println("User is navigated to OutReach Event Master page");
    } 

//  CREATE NEW EVENT ---> NEW BUTTON 
@And("user clicks New button in outreach event master")
public void user_clicks_new_button_outReachMaster() {
	outReachMaster.clickNewBtn();  
}

@Then("new event creation popup should be displayed")
public void new_event_creation_popup_displayed() {
	WebElement popup = wait.until( ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.popup));

	Assert.assertTrue(popup.isDisplayed());
    System.out.println("New event creation popup is displayed");
}     

// SAVE BUTTON   
@And("user clicks save button in event popup")
public void user_clicks_save_button_newEvent_popup() {
	outReachMaster.clickSaveButton();  
}

// CLEAR BUTTON    
@And("user clicks clear button in event popup")
public void user_clicks_clear_button_newEvent_popup() {
	outReachMaster.clickClearButton();  
}

// CANCEL BUTTON    
@And("user clicks cancel button in event popup")
public void user_clicks_cancel_button_newEvent_popup() {
	outReachMaster.clickCancelButton();  
}

// ORGANIZER NAME 
@And("user selects event organizer name {string} dropdown")
public void user_select_organizer_name(String eventOrgName) {
	outReachMaster.selectOrganizerName(eventOrgName);  
}    
    
@Then("organizer name Required alert should be appear")
public void validate_organize_name_empty_field() {
	validateRequiredAlert(outReachMasterLocator.orgNameerrorMsg, "Event Organizer Name");
}    
    
// HOSPITAL NAME 
@And("user selects hospital {string} dropdown")
public void user_select_hospital_name(String hospitalName) {
	outReachMaster.selectHospitalName(hospitalName);  
}    
 
@Then("user should see hospital name empty field validation in outreach")
public void validate_hospital_name_empty_field_outReachEvent() {
	validateRequiredAlert(outReachMasterLocator.hospitalNameerrorMsg, "Hospital Name");
}   

//ACTIVE VALIDATION
@And("user clicks active checkbox")
public void user_clicks_active_checkbox() {
	outReachMaster.clickActiveCheckbox();  
}
    
//PLACE 
@And("user enters place {string}")
public void user_enter_place_name(String place) {
	outReachMaster.enterPlaceName(place);  
}    

@Then("place Required alert should be appear")
public void validate_place_name_empty_field() {
	validateRequiredAlert(outReachMasterLocator.placeerrorMsg, "Place");
}

// CITY
@And("user selects city {string} dropdown")
public void user_enter_city_name_event(String city) {
	outReachMaster.selectCityName(city);  
}    

@Then("city Required alert should be appear")
public void validate_city_name_empty_field() {
	validateRequiredAlert(outReachMasterLocator.cityerrorMsg, "City / Taluk");
}

    
//DISTRICT 
@And("user selects district {string} dropdown")
public void user_selects_district_name(String district) {
	outReachMaster.selectDistrictName(district);  
}    

@Then("district Required alert should be appear")
public void validate_district_name_empty_field() {
	validateRequiredAlert(outReachMasterLocator.districterrorMsg, "District");
} 

//DISTANCE FROM HQ 
@And("user selects distance {string} dropdown")
public void user_select_distace_from_HQ(String distance) {
	outReachMaster.selectDistance(distance);  
}    

@Then("Distance From HQ Required alert should be appear")
public void validate_distance_HQ_empty_field() {
	validateRequiredAlert(outReachMasterLocator.distanceerrorMsg, "Distance From HQ");
} 

//LANGUAGE OF PRESCRIPTION
@And("user selects language of prescription {string} dropdown")
public void user_select_language_of_prescription(String language) {
	outReachMaster.selectLanguage(language);  
}    
//                             CHANGE THE FIELD NAME
@Then("Language for Prescription Required alert should be appear")
public void validate_language_of_prescription_empty_field() {
	validateRequiredAlert(outReachMasterLocator.languageerrorMsg,"Distance From HQ");
}

//EVENT TYPE
@And("user selects event type {string} dropdown")
public void user_select_event_type(String eventType) {
	outReachMaster.selectEventType(eventType);  
}    

@Then("Event Type Required alert should be appear")
public void validate_event_type_empty_field() {
	validateRequiredAlert(outReachMasterLocator.eventTypeerrorMsg,"Event Type");
}

//EVENT LOCATION TYPE 
@And("user selects event location {string} dropdown")
public void user_selects_event_location_name(String eventLocation) {
	outReachMaster.selectEventLocation(eventLocation);  
}    

@Then("Event Location Required alert should be appear")
public void validate_event_location_empty_field() {
	validateRequiredAlert(outReachMasterLocator.eventLocationerrorMsg, "Event Location");  
}   
  
//PROJECT NAME
@And("user selects project name {string} dropdown")
public void user_select_project_name(String project) {
	outReachMaster.selectProject(project);  
}    

// LOCAL PERTNER NAME
@And("user enters local partner {string}")
public void user_enter_local_partner(String localPartner) {
	outReachMaster.enterLocalPartner(localPartner);  
} 

//IHMS CAMP ID
@And("user enters camp id {string} in event")
public void user_enter_campid_event(String campid) {
	outReachMaster.enterCampId(campid);  
}

@Then("validation for IHMS camp id field")
public void validate_campid() {
	validateCampIdField(outReachMasterLocator.campIdInput, "IHMS camp id");
}

// START DATE THROUGH CALENDER    

// START CALENDER
@And("user clicks event start date calendar icon")
public void click_start_date_calendar() {
 outReachMaster.clickStartDateCalendar();
}

//SELECT START MONTH
@And("user selects start month {string}")
public void select_start_month(String month) {
 outReachMaster.selectStartMonth(month);
}

//SELECT START YEAR
@And("user selects start year {string}")
public void select_start_year(String year) {
 outReachMaster.selectStartYear(year);
}

//SELECT START DATE
@And("user selects start date {string} from date picker")
public void select_start_date(String date) {
 outReachMaster.selectStartDate(date);
}

//VERIFY START DATE
@Then("selected date should be displayed in event start date field")
public void verify_start_date() {
 String value = outReachMaster.getSelectedStartDate();
 Assert.assertTrue(value != null && !value.isEmpty(), "Start date not selected");
 System.out.println("Start Date: " + value);
}

//START DATE REQUIRED
@Then("start date Required alert should be appear")
public void validate_start_date_empty_field() {
	validateRequiredAlert(outReachMasterLocator.startDateerrorMsg, "Stard Date");
}

//PAST DATE VALIDATION
@Then("past dates should be disabled in date picker")
public void verify_past_dates_disabled() { 
	WebElement pastDate = DriverFactory.getDriver().findElement(By.xpath("//ngb-datepicker//div[contains(@class,'ngb-dp-day') and normalize-space()='1']")); 
	String classes = pastDate.getAttribute("class"); 
	Assert.assertTrue(classes.contains("disabled") || classes.contains("ngb-dp-disabled"),"Past date is disable"); 
System.out.println("Past date is correctly disabled"); 
}



//END DATE 

//OPEN END DATE CALENDER
@And("user clicks event end date calendar icon")
public void click_end_date_calendar() {
 outReachMaster.clickEndDateCalendar();
}

//SELECT END MONTH
@And("user selects end month {string}")
public void select_end_month(String month) {
 outReachMaster.selectEndMonth(month);
}

//SELECT END YEAR
@And("user selects end year {string}")
public void select_end_year(String year) {
 outReachMaster.selectEndYear(year);
}

//SELECT END DATE
@And("user selects end date {string} from date picker")
public void select_end_date(String date) {
 outReachMaster.selectEndDate(date);
}

@Then("selected date should be displayed in event end date field")
public void verify_end_date() {
 String value = outReachMaster.getSelectedEndDate();
 Assert.assertTrue(value != null && !value.isEmpty(), "End date not selected");
 System.out.println("End Date: " + value);
}

//END DATE --> EMPTY FIELDS
@Then("end date Required alert should be appear")
public void validate_end_date_empty_field() {
	validateRequiredAlert(outReachMasterLocator.endDateerrorMsg, "End Date");
}
    


//EXPECTED OP VALIDATION
@And("user enters expected op {string}")
public void user_enter_expected_op(String op) {
	outReachMaster.enterExpectedOP(op);  
}

@Then("validation for expected op field")
public void validate_expected_op_length() {

    WebElement field = DriverFactory.getDriver().findElement(outReachMasterLocator.expectedOPInput);
    String value = field.getAttribute("value");
    // ALLOWS ONLY NUMBERS  
    if (!value.matches("\\d*")) {
        throw new AssertionError("Expected OP contains invalid characters: " + value);
    }
    // CHECK LEGNTH OF PINCODE
    if (value.length() > 3) {
        throw new AssertionError("Expected OP accepts more than 3 digits: " + value);
    }
    System.out.println("Expected OP accepted correctly: " + value);
}   

@Then("Expected op Required alert should be appear")
public void validate_expected_op_empty_field() {
	validateRequiredAlert(outReachMasterLocator.expectedOPerrorMsg, "Expected OP");  
}

//EXPECTED IP VALIDATION
@And("user enters expected ip {string}")
public void user_enter_expected_ip(String ip) {
	outReachMaster.enterExpectedIP(ip);  
}

@Then("validation for expected ip field")
public void validate_expected_ip() {
    validatePercentageField(outReachMasterLocator.expectedIPInput, "Expected IP");
}

@Then("Expected ip Required alert should be appear")
public void validate_expected_ip_empty_field() {
	validateRequiredAlert(outReachMasterLocator.expectedIPerrorMsg, "Expected IP");
}

//EXPECTED SPECIALITY REFERRAL VALIDATION
@And("user enters expected speciality referral {string}")
public void user_enter_expected_speciality_referral(String specRef) {
	outReachMaster.enterExpectedSpecReferral(specRef);  
}

@Then("validation for expected speciality referral field")
public void validate_expected_speciality_referral() {
	validatePercentageField(outReachMasterLocator.expectedSpecRefInput, "Expected Speciality Referral");
} 

@Then("Expected speciality referral Required alert should be appear")
public void validate_expected_speciality_referral_empty_field() {
	validateRequiredAlert(outReachMasterLocator.expectedSpecReferrorMsg, "Expected Speciality");
}

//EXPECTED GP VALIDATION
@And("user enters expected GP {string}")
public void user_enter_expected_GP(String gp) {
	outReachMaster.enterExpectedGP(gp);  
}

@Then("validation for expected GP field")
public void validate_expected_gp() {
	validatePercentageField(outReachMasterLocator.expectedGPInput, "Expected GP");
} 

@Then("Expected GP Required alert should be appear")
public void validate_expected_GP_empty_field() {
	 validateRequiredAlert(outReachMasterLocator.expectedGPerrorMsg, "Expected GP");
}


//  VALIDATE PERCENTAGE FIELDS ---> IP, SPECIALITY REFERRAL, GP
public void validatePercentageField(By locator, String fieldName) {

    WebElement field = DriverFactory.getDriver().findElement(locator);
    String value = field.getAttribute("value");

    // ALLOW ONLY NUMBERS
    if (!value.matches("\\d+")) {
        throw new AssertionError(fieldName + " contains invalid characters: " + value);
    }
   // RANGE CHECK
    int number = Integer.parseInt(value);
    if (number < 0 || number > 100) {
        throw new AssertionError(fieldName + " should be between 0 and 100: " + value);
    }
}

// EMPTY FIELD ACTION FOR ALL FIELDS
public void validateRequiredAlert(By locator, String fieldName) {

    WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

    if (!errorMsg.isDisplayed()) {
        throw new AssertionError(fieldName + " is required");
    }

    System.out.println(fieldName + " required alert is displayed");
}


//VALIDATE RANGE FIELDS ---> CAMP CODE
public void validateCampIdField(By locator, String fieldName) {

WebElement field = DriverFactory.getDriver().findElement(locator);
String value = field.getAttribute("value");

// ALLOW ONLY NUMBERS
if (!value.matches("\\d+")) {
    throw new AssertionError(fieldName + " contains invalid characters: " + value);
}
// RANGE CHECK
int number = Integer.parseInt(value);
if (number < 0 || number > 99999) {
    throw new AssertionError(fieldName + " should be between 0 and 99999: " + value);
}
}


@Then("no data found messege should be displayed in dropdown in event")
public void validate_no_data_found_message() {

	 WebDriverWait wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));

	    WebElement noDataMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(
	        By.xpath("//*[contains(text(),'No data') or contains(text(),'no data')]")
	    ));

	    String actualMsg = noDataMsg.getText().trim();
	    System.out.println("Dropdown message: " + actualMsg);

	    if (!actualMsg.toLowerCase().contains("no data")) {
	        throw new AssertionError("Expected 'No data found' but got: " + actualMsg);
	    }
}



// EDIT BUTTON WORKFLOW

@Given("user is on event management page")
public void user_on_event_page() {

    DriverFactory.getDriver().navigate().refresh();

    wait.until(ExpectedConditions.visibilityOfElementLocated(
        By.xpath("//table//tbody//tr")
    ));
}

// EDIT BUTTON
@And("user enters data in search bar {string}")
public void user_enters_eventId_on_search_bar(String data) {
    outReachMaster.enterEventIdInSearchBar(data);
}

//VALIDATE EVENT LIST DISPLAYED
@Then("event details for data {string} should be displayed")
public void validate_event_displayed_with_eventID_searchbox(String data) {

  WebElement row = wait.until(
      ExpectedConditions.visibilityOfElementLocated(
          getRowByData(data)
      )
  );

  if (!row.isDisplayed()) {
      throw new AssertionError("Event not found: " + data);
  }
}
public static By getRowByData(String data) {
    return By.xpath("//table//tbody//tr[.//td[contains(normalize-space(),'" + data + "')]]");
}

@And("user clears search bar")
public void user_clears_search_bar_in_event() {
	outReachMaster.clickClearSearch();
}

// SELECT CHECK BOX
@When("user selects checkbox for data {string}")
public void select_checkbox_for_event(String data) {

    WebElement row = wait.until(ExpectedConditions.visibilityOfElementLocated(getRowByData(data)));

    WebElement checkbox = wait.until(ExpectedConditions.elementToBeClickable(row.findElement(By.xpath(".//input[@type='checkbox']"))));

    // Click only if not already selected
    if (!checkbox.isSelected()) {
        checkbox.click();
    }
}

@Then("checkbox for data {string} should be selected")
public void validate_checkbox_selected(String data) {

    WebElement row = DriverFactory.getDriver().findElement(getRowByData(data));
    WebElement checkbox = row.findElement(By.xpath(".//input[@type='checkbox']"));

    if (!checkbox.isSelected()) {
        throw new AssertionError("Checkbox not selected for event id: " + data);
    }
}


// CLICK EDIT BUTTON
@And("user clicks on edit button in Event")
public void user_clicks_edit_button_in_event() {
	outReachMaster.clickEditBtn();
}

// VALIDATE POPUP DISPLAYED
@Then("event creation popup with existing details should be displayed")
public void validate_edit_popup_displayed() {
	WebElement popup = wait.until( ExpectedConditions.visibilityOfElementLocated(outReachMasterLocator.popup));

    if (!popup.isDisplayed()) {
        throw new AssertionError("Edit popup is not displayed");
    }

}


// UPDATE BUTTON
@And("user clicks update button in event")
public void user_clicks_update_button() {
    outReachMaster.clickUpdateBtn();
}

//DELETE BUTTON
@And("user clicks on delete button in Event")
public void user_clicks_delete_button() {
	outReachMaster.clickDeleteBtn();
}

// CONFIRMATION FOR DELETE
@And("user clicks on Confirmation ok in Event")
public void user_clicks_confirmation_ok_button() {
	outReachMaster.clickOKBtn();
}
//CONFIRMATION FOR DELETE
@And("user clicks on Confirmation Cancel in Event")
public void user_clicks_confirmation_cancel_button() {
	outReachMaster.clickCancelBtn();
}


























}