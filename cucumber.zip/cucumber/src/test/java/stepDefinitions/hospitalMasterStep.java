package stepDefinitions;

import io.cucumber.java.en.*;
import locators.hospitalMasterLocator;
import pages.hospitalMasterPage;
import utils.DriverFactory;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class hospitalMasterStep {

    hospitalMasterPage hospitalMaster;
    WebDriverWait wait;

    public hospitalMasterStep() {
    	hospitalMaster = new hospitalMasterPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
    
// USER MASTER   
@And("I click on hospital master option")
public void click_hospital_master_page() {
	hospitalMaster.clickHospitalMasterOption();  
}

@Then("I navigated to the hospital master page")
public void navigated_to_hospital_master_page() {
    wait.until(ExpectedConditions.urlContains("facility"));
    System.out.println("User is navigated to Hospital Master page");
} 

    
//CREATE NEW EVENT ---> NEW BUTTON 
@And("I click New button in hospital master")
public void click_new_button_hospital_Master() {
	hospitalMaster.clickNewBtn();  
}

@Then("new hospital creation popup should be displayed")
public void new_user_creation_popup_displayed() {
	WebElement popup = wait.until( ExpectedConditions.visibilityOfElementLocated(hospitalMasterLocator.popup));
	
	Assert.assertTrue(popup.isDisplayed());
	System.out.println("New hospital creation popup is displayed");
}     


// HOSPITAL NAME
@And("I enter hospital name {string}")
public void enter_hospital_name(String hospital) {
	hospitalMaster.enterHospitalName(hospital);  
}
@Then("hospital name Required alert should be appear")
 public void hospital_name_empty_field(){
	validateRequiredAlert(hospitalMasterLocator.hospitalNameerrorMsg,"Hospital Name");
}

//HOSPITAL SHORT NAME
@And("I enter hospital short name {string}")
public void enter_hospital_short_name(String hospital) {
	hospitalMaster.enterHospitalShortName(hospital);  
}
@Then("hospital short name Required alert should be appear")
public void hospital_short_name_empty_field(){
	validateRequiredAlert(hospitalMasterLocator.hospitalShortNameerrorMsg,"Hospital Short Name");
}

//HOSPITAL TYPE
@And("I select hospital type {string}")
public void enter_hospital_type(String type) {
	hospitalMaster.selectHospitalType(type);  
}
@Then("hospital type Required alert should be appear")
public void hospital_type_empty_field(){
	validateRequiredAlert(hospitalMasterLocator.hospitalTypeerrorMsg,"Hospital Type");
}

// ADDRESS LINE
@And("I enter address line {string}")
public void enter_address(String address) {
	hospitalMaster.enterAddress(address);  
}
@Then("address Required alert should be appear")
public void address_empty_field(){
	validateRequiredAlert(hospitalMasterLocator.addresserrorMsg,"Address");
}

// TALUK
@And("I select citytaluk {string}")
public void select_citytaluk(String taluk) {
	hospitalMaster.selectTaluk(taluk);  
}
@Then("taluk Required alert should be appear")
public void taluk_empty_field(){
	validateRequiredAlert(hospitalMasterLocator.talukerrorMsg,"City / Taluk");
}

//DISTRICT
@And("I select district {string}")
public void select_district(String district) {
	hospitalMaster.selectDistrict(district);  
}
@Then("district require alert should be appear")
public void district_require_alert(){
	validateRequiredAlert(hospitalMasterLocator.districterrorMsg,"District");
}

//STATE
@And("I select state {string}")
public void select_state(String state) {
	hospitalMaster.selectState(state);  
}
@Then("state Required alert should be appear")
public void state_empty_field(){
	validateRequiredAlert(hospitalMasterLocator.stateerrorMsg,"State");
}

// COUNTRY
@And("I select country {string}")
public void select_country(String country) {
	hospitalMaster.selectCountry(country);  
}

//TELEPHONE NUMBER
  @And("I enter telephone number {string}")
  public void enter_telephone_number(String telephone) {
	  hospitalMaster.enterTelephone(telephone);
  }

//STATE
@And("I enter email {string}")
public void enter_email(String email) {
	hospitalMaster.enterEmail(email);  
}
@Then("email Required alert should be appear")
public void email_empty_field(){
	validateRequiredAlert(hospitalMasterLocator.emailerrorMsg,"Email");
}

//EMPTY FIELD VALIDATION
public void validateRequiredAlert(By locator, String fieldName) {
    WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

    if (!errorMsg.isDisplayed()) {
        throw new AssertionError(fieldName + " is required");
    }

    System.out.println(fieldName + " required alert is displayed");
}


@Then("hospital edit popup with existing details should be displayed")
public void validate_edit_popup_displayed() {
	WebElement popup = wait.until( ExpectedConditions.visibilityOfElementLocated(hospitalMasterLocator.popup));

    if (!popup.isDisplayed()) {
        throw new AssertionError("Edit popup is not displayed");
    }

}











	
}
