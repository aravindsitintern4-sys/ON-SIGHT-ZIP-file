package stepDefinitions;

import io.cucumber.java.en.*;
import locators.userMasterLocator;
import pages.userMasterPage;
import utils.DriverFactory;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class userMasterStep {

    userMasterPage userMaster;
    WebDriverWait wait;

    public userMasterStep() {
    	userMaster = new userMasterPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(30));
    }
    
    
// USER MASTER   
@And("user clicks on user master option")
public void user_clicks_usermaster_page() {
	userMaster.clickUserMasterOption();  
}

@Then("user navigated to the user master page")
public void user_navigated_to_usermaster_page() {
    wait.until(ExpectedConditions.urlContains("user"));
    System.out.println("User is navigated to User Master page");
} 

    
//CREATE NEW EVENT ---> NEW BUTTON 
@And("user clicks New button in user master")
public void user_clicks_new_button_userMaster() {
	userMaster.clickNewBtn();  
}

@Then("new user creation popup should be displayed")
public void new_user_creation_popup_displayed() {
	WebElement popup = wait.until( ExpectedConditions.visibilityOfElementLocated(userMasterLocator.popup));
	
	Assert.assertTrue(popup.isDisplayed());
	System.out.println("New user creation popup is displayed");
}     

//SAVE BUTTON   
@And("user clicks save button in user popup")
public void user_clicks_save_button_newUser_popup() {
	userMaster.clickSaveButton();  
}

//CLEAR BUTTON    
@And("user clicks clear button in user popup")
public void user_clicks_clear_button_newUser_popup() {
	userMaster.clickClearButton();  
}

//CANCEL BUTTON    
@And("user clicks cancel button in user popup")
public void user_clicks_cancel_button_newUser_popup() {
	userMaster.clickCancelButton();  
}


 
// ALIAS 
@And("user selects alias {string} dropdown")
public void user_selects_alias_userMaster(String alias) {
	userMaster.selectAlias(alias);  
}    
@Then("alias Required alert should be appear")
public void validate_alias_empty_field() {
	validateRequiredAlert(userMasterLocator.aliaserrorMsg, "Alias");
}    

//FIRST NAME 
@And("user enters First name {string} in user")
public void user_enter_firstName_userMaster(String Fname) {
	userMaster.enterFirstName(Fname);  
}    
@Then("first name Required alert should be appear")
public void validate_First_name_empty_field() {
	validateRequiredAlert(userMasterLocator.firstNameerrorMsg, "First name");
}

//LAST NAME 
@And("user enters Last name {string} in user")
public void user_enter_lastName_userMaster(String Lname) {
	userMaster.enterLastName(Lname);  
}

//EMAIL 
@And("user enters email {string} in user")
public void user_enter_email_userMaster(String email) {
	userMaster.enterEmail(email);  
}

//ROLES 
@And("user selects role {string} dropdown")
public void user_selects_role_userMaster(String role) {
	userMaster.selectRoles(role);  
}    
@Then("role Required alert should be appear")
public void validate_role_empty_field() {
	validateRequiredAlert(userMasterLocator.roleerrorMsg, "Role");
}

//HOSPITAL NAME 
@And("user selects hospital name {string} userMaster dropdown")
public void user_selects_hospital_name_userMaster(String hospital) {
	userMaster.selectHospital(hospital);  
}    
@Then("user should see hospital name empty field validation in user master")
public void empty_hospitalName_validation_userMaster() {
	validateRequiredAlert(userMasterLocator.hospitalerrorMsg, "Hospital name");
}

//MCIR NUMBER 
@And("user enters MCIR number {string} in user")
public void user_enter_MCIR_Number_userMaster(String mcir) {
	userMaster.enterMCIR(mcir);  
}


//EMPTY FIELD ACTION FOR ALL FIELDS
public void validateRequiredAlert(By locator, String fieldName) {

 WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

 if (!errorMsg.isDisplayed()) {
     throw new AssertionError(fieldName + " is required");
 }

 System.out.println(fieldName + " required alert is displayed");
}    
    
//OLD PASSWORD 
@And("user enters old password {string}")
public void user_enters_old_password(String old) {
	userMaster.enterOldPassword(old);  
}    
    
//NEW PASSWORD 
@And("user enters new password {string}")
public void user_enters_new_password(String newpass) {
	userMaster.enterNewPassword(newpass);  
}    
    
//CONFIRM PASSWORD 
@And("user enters confirm password {string}")
public void user_enters_confirm_password(String confirm) {
	userMaster.enterConfirmPassword(confirm);  
}    
    
//RESET PASSWORD NAVIGATION VALIDATION
@Then("user is navigated to reset password page")
public void user_is_navigated_reset_password_page() {

	wait.until(ExpectedConditions.urlContains("reset-password"));
	System.out.println("Successfully navigated into reset password page");
}    
    
//LOGIN PAGE NAVIGATION VALIDATION
@Then("user is navigated into login page")
public void user_is_navigated_login_page() {

	wait.until(ExpectedConditions.urlContains("login"));
	System.out.println("Successfully navigated into Login page");
}    
 
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
