package stepDefinitions;


import io.cucumber.java.en.*;
import pages.dashboardStationsPage;
import utils.DriverFactory;

import java.time.Duration;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class dashboardStationsStep {

	dashboardStationsPage station;
    WebDriverWait wait;

    public dashboardStationsStep() {
    	station = new dashboardStationsPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    

// STATION OVERVIEW ----> DASHBOARD PAGE
    
    @And("I click patient station overview section in dashboard")
    public void station_overview_in_dashboard() {
    	station.clickWaitingBadge();
    }

    @Then("total OP should equal sum of waiting and completed")
    public void validate_total_op() {
    	station.validateTotalOP();
    }

    @Then("all station names should be visible")
    public void validate_station_names() {
    	station.validateStationNames();
    }

    @Then("waiting count for each station should match")
    public void validate_waiting_counts() {
    	station.validateWaitingSum();
    }

    @Then("progress bar should be displayed for stations with waiting > 0")
    public void validate_progress_bar() {
    	station.validateProgressBars();
    }

    @Then("stations with zero waiting should show empty progress bar")
    public void validate_zero_progress() {
    	station.validateZeroProgressBars();
    }



  
//SURGERY ADVISED ------> DASHBOARD PAGE
    
    @And("I click patient surgery confirmed section in dashboard")
    public void surgery_advised_in_dashboard() {
    	station.clickSurgeryAdviced();
    }
    
    @Then("I navigated to the surgery advised onboarding page")
    public void navigated_to_surgery_advised_onboarding_page() {
        wait.until(ExpectedConditions.urlContains("patient-onboarding"));
        System.out.println("Navigated into surgery advised Patient Onboarding page");
    }
    
    @And("I enter id in search bar {string} in Surgery advised")
    public void search_bar_surgery_advised(String name) {
    	station.enterSearchBar(name);
    }
    
    @And("I click filtered option in surgery advised")
    public void filtered_option() {
    	station.clickFilteredOption();
    }
        
    // BUTTON ACTIONS
	@And("I click {string} button in surgery adviced onboarding")
	public void buttons_surgery_advised_onboarding_module(String btn) {
		station.ClickBtnOnboarding(btn);
	}    

}
