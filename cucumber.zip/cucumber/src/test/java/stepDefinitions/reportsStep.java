package stepDefinitions;



import io.cucumber.java.en.*;
import pages.reportsPage;
import utils.DriverFactory;
import java.time.Duration;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class reportsStep {

	reportsPage reports;
    WebDriverWait wait;

    public reportsStep() {
    	reports = new reportsPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
//  REPORTS OPTION CLICK
    @And("user clicks on reports option")
    public void user_navigates_master_page() {
    	reports.clickreportsOption();  
    }
    
    @Then("user navigated to the reports page")
    public void user_navigated_to_reports_page() {
        wait.until(ExpectedConditions.urlContains("reports"));
        System.out.println("User is navigated to Reports page");
    }
    
//  OP REGISTER
    
    @And("user selects campId {string}")
    public void user_selects_campid(String campid) {
    	reports.selectCampId(campid);  
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


}
