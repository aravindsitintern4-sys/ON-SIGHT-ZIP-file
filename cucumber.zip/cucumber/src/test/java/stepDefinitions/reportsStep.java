package stepDefinitions;



import io.cucumber.java.en.*;
import pages.reportsPage;
import utils.DriverFactory;
import java.time.Duration;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class reportsStep {

	reportsPage reports;
    WebDriverWait wait;

    public reportsStep() {
    	reports = new reportsPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
//  REPORTS OPTION CLICK
    @And("I click on reports option")
    public void navigates_master_page() {
    	reports.clickreportsOption();  
    }
    
    @Then("I navigated to the reports page")
    public void navigated_to_reports_page() {
        wait.until(ExpectedConditions.urlContains("reports"));
        System.out.println("User is navigated to Reports page");
    }
    
//  OP REGISTER
    
    @And("I select campId {string}")
    public void selects_campid(String campid) {
    	reports.selectCampId(campid);  
    }
    
    
// REPORTS -----> CAMP SUMMARY
	
 		// INPUT ACTIONS
 		@And("I enter From date as {string}")
 		public void enter_from_date(String dateInput) {
 			reports.enterFromDateCampSummary(dateInput);
 		}
 		
 		@And("I enter To date as {string}")
 		public void enter_to_date(String dateInput) {
 			reports.enterToDateCampSummary(dateInput);
 		}
 		
 		// DROPDOWN ACTIONS
 		@And("I select Camp id or place dropdown field {string}")
 		public void select_camp(String option) {
 			reports.selectCampIdOrPlace(option);
 		}
 		
 		@And("I select Camp id or place dropdown field invalid data {string}")
 		public void select_camp_invalid_data(String option) {
 			reports.selectCampIdOrPlaceInvalid(option);
 		}
 		
 		// BUTTON ACTIONS
 		@And("I click {string} button in camp summary")
 		public void buttons_camp_summary_report(String btn) {
 			reports.ClickBtnCampSummaryReport(btn);
 		}
 		
 		// NO ITEMS FOUND IN DROPDOWN
 		@Then("no items found message should be displayed in dropdown in reports")
 		public void no_items_found_message_should_be_displayed_in_dropdown_reports() {
 			reports.validateNoItemsFoundMessageCommon();
 		}
 		
 		//SELECT ALL CHECK BOX
 		@Given("I open the Camp dropdown")
 		public void i_open_the_camp_dropdown() {
 			reports.openCampDropdown();
 		}
 		
 		@And("I click on Select All checkbox")
 		public void i_click_select_all_checkbox() {
 			reports.clickSelectAllCheckbox();
 		}

 		@Then("all dropdown options should be selected")
 		public void all_dropdown_options_should_be_selected() {
 			reports.verifyAllOptionsSelected();
 		}
 		
 		@Then("report table should be displayed")
 		public void report_table_should_be_displayed() {
 			reports.isReportTableDisplayed();
 		}   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


}
