package stepDefinitions;

import io.cucumber.java.en.*;
import locators.recallLocator;
import pages.recallPage;
import utils.DriverFactory;
import java.time.Duration;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class recallStep {

    recallPage recall;
    WebDriverWait wait;

    public recallStep() {
        recall = new recallPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
    @Given("user is on the registration page")
    public void user_is_on_registration_page_recall() {
    	System.out.println("User is on Registration Page");  
    }

//    RECALL BUTTON 
    @When("user clicks on Recall button")
    public void user_clicks_recall_button() {
        recall.clickRecallBtn();  
    }
//	  RECALL POP-UP
    @Then("recall popup should be displayed")
    public void recall_popup_is_displayed() {
        System.out.println("Recall popup is displayed successfully");
    }

//  ENTER OID 
    @And("user enters OID {string}")
    public void user_enters_OID_recall(String oid) {
        recall.enterOid(oid);
    }
 

//  SUBMIT BUTTON
  @And("user clicks on Submit button in recall")
  public void user_clicks_submit_button_recall() {
      recall.clickSubmitBtn();
  }
  
  @Then("patient address details should be displayed")
  public void patient_address_details_are_displayed_recall() {
	  System.out.println("Patient address details are displayed correctly");
  }
  

//  CANCEL BUTTON
  @And("user clicks on Cancel button in recall")
  public void user_clicks_cancel_button_recall() {
      recall.clickCancelBtn();
  }
  
  @Then("user should be navigated to registration page")
  public void user_navigated_to_registration_page_recall() {
	  System.out.println("User is navigated to Registration Page");
  }  
  
//   CLOSE BUTTON
@And("user clicks on Close button in recall")
public void user_clicks_close_button_recall() {
    recall.clickCloseBtn();
}
 
//	OID FIELD VALIDATION
  @Then("user should see OID validation message {string}")
  public void validate_oid_error_message(String expectedMsg) {

      WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(recallLocator.invalidOidAlert));

      String actualMsg = errorMsg.getText().trim();

      if (!actualMsg.equals(expectedMsg)) {
          throw new AssertionError("Expected: " + expectedMsg + " but got: " + actualMsg);
      }

      System.out.println("OID validation message displayed correctly: " + actualMsg);
  }   
    
//	OK BUTTON FOR ALERT
@And("user clicks on OK button")
public void user_clicks_ok_button_recall_alert() {
  recall.clickOkBtn();
}    
    
//	IF EMPTY FIELD ---> REQUIRED VALIDATION

@Then("Required alert should be appear in recall")
public void validate_oid_empty_field_recall() {

	WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(recallLocator.requiredAlert));

    String actualText = errorMsg.getText().trim();

    if (!actualText.contains("required")) {
        throw new AssertionError("Expected required message but got: " + actualText);
    }

    System.out.println("Required alert is displayed: " + actualText);
}   
    
    
    
    
}