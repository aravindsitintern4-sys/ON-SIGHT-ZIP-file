package stepDefinitions;

import io.cucumber.java.en.*;
import locators.recallLocator;
import pages.recallPage;
import utils.DriverFactory;
import java.time.Duration;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class recallStep {

    recallPage recall;
    WebDriverWait wait;

    public recallStep() {
        recall = new recallPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
    @Given("placed on registration page")
    public void placed_on_registration_page_recall() {
    	System.out.println("User is on Registration Page");  
    }

//    RECALL BUTTON 
    @When("I click on Recall button")
    public void click_recall_button() {
        recall.clickRecallBtn();  
    }
//	  RECALL POP-UP
    @Then("recall popup should be displayed")
    public void recall_popup_is_displayed() {
        System.out.println("Recall popup is displayed successfully");
    }

//  ENTER OID 
    @And("I enter OID {string}")
    public void enter_OID_recall(String oid) {
        recall.enterOid(oid);
    }
 

//  SUBMIT BUTTON
  @And("I click on Submit button in recall")
  public void click_submit_button_recall() {
      recall.clickSubmitBtn();
  }
  
  @Then("patient address details should be displayed")
  public void patient_address_details_are_displayed_recall() {
	  System.out.println("Patient address details are displayed correctly");
  }
  

//  CANCEL BUTTON
  @And("I click on Cancel button in recall")
  public void click_cancel_button_recall() {
      recall.clickCancelBtn();
  }
  
  @Then("I should be navigated to registration page")
  public void navigated_to_registration_page_recall() {
	  System.out.println("User is navigated to Registration Page");
  }  
  
//   CLOSE BUTTON
@And("I click on Close button in recall")
public void click_close_button_recall() {
    recall.clickCloseBtn();
}
 
//	OID FIELD VALIDATION
  @Then("I should see OID validation message {string}")
  public void validate_oid_error_message(String expectedMsg) {

      WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(recallLocator.invalidOidAlert));

      String actualMsg = errorMsg.getText().trim();

      if (!actualMsg.equals(expectedMsg)) {
          throw new AssertionError("Expected: " + expectedMsg + " but got: " + actualMsg);
      }

      System.out.println("OID validation message displayed correctly: " + actualMsg);
  }   
    
//	OK BUTTON FOR ALERT
@And("I click on OK button")
public void click_ok_button_recall_alert() {
  recall.clickOkBtn();
}    
    
//	IF EMPTY FIELD ---> REQUIRED VALIDATION

@Then("Required alert should be appear in recall")
public void validate_oid_empty_field_recall() {

	WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(recallLocator.requiredAlert));

    String actualText = errorMsg.getText().trim();

    if (!actualText.contains("required")) {
        throw new AssertionError("Expected required message but got: " + actualText);
    }

    System.out.println("Required alert is displayed: " + actualText);
}   
    
    
    
    
}