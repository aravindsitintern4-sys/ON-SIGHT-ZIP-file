package stepDefinitions;

import io.cucumber.java.en.*;
import pages.registrationPage;
import utils.DriverFactory;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import locators.registrationLocator;


public class registrationStep {

    registrationPage reg;
    WebDriverWait wait;

    public registrationStep() {
        reg = new registrationPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
    @Given("user is on the dashboard page")
    public void user_is_on_dashboard_page() {
    	System.out.println("User is on Dashboard Page");  
    }

    @When("user clicks on Registration option")
    public void user_navigates_reg_page() {
    	reg.clickRegOption();  
    }
    
    @Then("patient should be navigated to the registration page")
    public void user_navigated_to_registration_page() {
        wait.until(ExpectedConditions.urlContains("registration-screen"));
        System.out.println("User is navigated to registration page");
    }

//    FIRST NAME
    @And("user enters First Name {string}")
    public void user_enters_first_name(String fName) {
        reg.enterFirstName(fName);
    }

//    LAST NAME
    @And("user enters Last Name {string}")
    public void user_enters_last_name(String lName) {
        reg.enterLastName(lName);
    }
    
//   AGE
	  @And("user enters Age {string}")
	  public void user_enters_age(String age) {
	      reg.enterAge(age);
	  }
    
//	GENDER
	  @And("user selects Gender {string}")
	  public void user_selects_gender(String gender) {
	      reg.selectGender(gender);
	  }
//	TRANS GENDER --> YES
	  @And("user clicks Yes button")
	  public void user_clicks_yes() {
	      reg.clickYes();
	  }
//	TRANS GENDER --> NO
	  @And("user clicks No button")
	  public void user_clicks_no() {
	      reg.clickNo();
	  }
//	  OPEN DROPDWON ---> GENDER --WITHOUT SELECT VALUES
	  @When("user clicks on Gender dropdown")
	  public void user_clicks_gender_dropdown() {
	      reg.clickGenderDropdown();
	  }

//	NEXT OF Kin
	@And("user selects Next of Kin {string}")
	public void user_selects_kin(String kin) {
	   reg.selectKin(kin);
	}
//	  OPEN DROPDWON ---> KIN -- WITHOUT SELECT VALUES
	  @When("user clicks on Next of Kin dropdown")
	  public void user_clicks_kin_dropdown() {
	      reg.clickKinDropdown();
	  }
	
//  KIN NAME
	  @And("user enters Kin Name {string}")
	  public void user_enters_kin_name(String kinName) {
	      reg.enterKinName(kinName);
	  }
	 
//  DOOR / STREET
	  @And("user enters Door {string}")
	  public void user_enters_door_street(String doorStreet) {
	      reg.enterDoorStreet(doorStreet);
	  }	
	  
//  LOCALITY
	  @And("user enters Locality {string}")
	  public void user_enters_locality(String locality) {
	      reg.enterLocality(locality);
	  }	  
	  
//	AREA
	  
	  @When("user clicks on Area button")
	    public void user_clickes_area_button() {
	    	reg.clickAreaBtn();  
	    }
	  
		@And("user selects Area {string}")
		public void user_selects_area(String area) {	  
		   reg.selectArea(area);
		}
	  
//  PINCODE
	  @And("user enters PinCode {string}")
	  public void user_enters_pincode(String pincode) {
	      reg.enterPincode(pincode);
	  }
	  
//	TALUK
		@And("user selects Taluk {string}")
		public void user_selects_taluk(String taluk) {	  
		   reg.selectTaluk(taluk);
		}  
			
//  MOBILE NUMBER
	  @And("user enters Mobile No {string}")
	  public void user_enters_mobileNo(String mobile) {
	      reg.enterMobile(mobile);
	  }
	  
//  AADHAAR NUMBER
	  @And("user enters Aadhaar No {string}")
	  public void user_enters_aadhaarNo(String aadhaar) {
	      reg.enterAadhaar(aadhaar);
	  }

//	  SUBMIT BUTTON
    @When("user clicks on Submit button in registration")
    public void user_clicks_submit_reg() {
        reg.clickSubmit();
    }
    
    
    @Then("patient should be registered successfully")
    public void user_navigated_to_registration() {
        System.out.println("User is navigated to registration page");
    }


  
//	  CLEAR BUTTON
  @And("user clicks on Clear button in registration")
  public void user_clicks_clear_reg() {
      reg.clickClear();
  }
  
  @Then("patient entered details should be cleared")
  public void user_navigated_to_dashboard() {
      System.out.println("Entered patient details are cleared");
  }
  
	  
//  CANCEL BUTTON
	@And("user clicks on Cancel button in registration")
	public void user_clicks_cancel_reg() {	
	  reg.clickCancel();
	}
	
	  @Then("user should be navigated to dashboard page")
	  public void user_navigated_to_dashboard_after_cancel() {
	      wait.until(ExpectedConditions.urlContains("dashboard"));
	      System.out.println("Entered patient details are cleared");
	  }
	  
//CANCEL BUTTON FOR POP UP
	  @And("user clicks close icon in oid generated pop up in registration")
	  public void user_clicks_close_icon_oid_generated_popup() {
	    reg.clickCloseIcon();
	  }	  
	  
	  	  
//	  ONLY ALPHABETS ACCEPTED VALIDATION

  @Then("only alphabets should be entered in name field")
  public void validate_name_field() {

      WebElement field = DriverFactory.getDriver().findElement(registrationLocator.firstNameInput);

      String value = field.getAttribute("value");
      
      if (!value.matches("[a-zA-Z]*")) {
          throw new AssertionError("Invalid characters present: " + value);
      }  
  }
  
//    IF EMPTY FIELD ---> REQUIRED VALIDATION
  
  @Then("Required alert should be appear")
  public void validate_name_empty_field() {

	  WebElement errorMsg = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(registrationLocator.requiredAlert)
		    );

		    if (!errorMsg.isDisplayed()) {
		        throw new AssertionError("Required");
		    }
		    System.out.println("Required alert is displayed");
  }
  
//  ONLY NUMBERS ACCEPTED VALIDATION
  
  @Then("only numbers should be accepted in age field")
  public void validate_age_field() {

      WebElement field = DriverFactory.getDriver()
              .findElement(registrationLocator.ageInput);

      String value = field.getAttribute("value");
//     "//d" --> accepts 0-9
      if (!value.matches("\\d*")) {
          throw new AssertionError("Invalid characters in Age field: " + value);
      }

      System.out.println("Age field validation passed");
  }
  
//   INVALID ALERT MESSAGE
  
@Then("Invalid alert should be appear")
public void invalid_alert_messege() {

  WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.invalidAlert));

	    if (!errorMsg.isDisplayed()) {
	        throw new AssertionError("invalid");
	    }
	    System.out.println("Invalid alert is displayed");
}

//  PINCODE FIELD ACCEPTS MORE THAN 6 DIGITS
@Then("validation for pincode field")
public void validate_pincode_length() {

    WebElement field = DriverFactory.getDriver().findElement(registrationLocator.pincodeInput);
    String value = field.getAttribute("value");
    // ALLOWS ONLY NUMBERS  
    if (!value.matches("\\d*")) {
        throw new AssertionError("Pincode contains invalid characters: " + value);
    }
    // CHECK LEGNTH OF PINCODE
    if (value.length() > 6) {
        throw new AssertionError("Pincode accepts more than 6 digits: " + value);
    }
    System.out.println("Pincode accepted correctly: " + value);
}

//  NO DATA FOUND ERROR MESSEGE IN DROPDOWN
@Then("no data found messege should be displayed in dropdown")
public void no_data_message_displayed(String expectedText) {

	 WebElement msg = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.noDataFoundMsg));
		    String text = msg.getText();

		    if (!text.toLowerCase().contains("No data Found")) {
		        throw new AssertionError("No data Found message NOT displayed");
		    }

		    System.out.println("No data Found message displayed: " + text);
} 

//MOBILE NUMBER FIELD VALIDATION
@Then("validation for Mobile No field")
public void validate_mobilenumber_length() {

	   WebDriver driver = DriverFactory.getDriver();
	    WebElement field = driver.findElement(registrationLocator.mobileNumInput);
	    String value = field.getAttribute("value");
	    if (!value.matches("[6-9]\\d{9}")) {

	        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.invalidFormatAlert));
	        String actualText = errorMsg.getText().trim();
	        
	        if (!actualText.equals("Invalid format.")) {
	            throw new AssertionError("Expected 'Invalid format.' but got: " + actualText);
	        }
	        System.out.println("Correct error message displayed: " + actualText);
	    }
}

//AADHAAR NUMBER FIELD VALIDATION
@Then("validation for Aadhaar No field")
public void validate_aadhaarnumber_length() {

	 WebDriver driver = DriverFactory.getDriver();

	    WebElement field = driver.findElement(registrationLocator.aadhaarNumInput);
	    String value = field.getAttribute("value");

	    if (value.length() < 12) {

	        WebElement errorMsg = wait.until(ExpectedConditions.presenceOfElementLocated(
	                By.xpath("//*[contains(text(),'12 characters')]")));

	        String actualText = errorMsg.getText().trim();

	        if (!actualText.contains("12 characters")) {
	            throw new AssertionError("Expected length error, but got: " + actualText);
	        }

	        System.out.println("Length validation message displayed: " + actualText);
	    }
	    // Invalid Aadhaar format
	    else if (!value.matches("[2-9]\\d{11}")) {

	        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(
	                registrationLocator.invalidAadhaarAlert));

	        String actualText = errorMsg.getText().trim();

	        if (!actualText.equals("Invalid Aadhaar number")) {
	            throw new AssertionError("Expected 'Invalid Aadhaar number' but got: " + actualText);
	        }

	        System.out.println("Invalid Aadhaar message displayed correctly");
	    }

	    // CASE 3: Valid Aadhaar
	    else {
	        System.out.println("Valid Aadhaar number: " + value);
	    }
}


















	
}
