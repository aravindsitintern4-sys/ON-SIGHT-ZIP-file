package stepDefinitions;

import io.cucumber.java.en.*;
import pages.registrationPage;
import utils.DriverFactory;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import locators.registrationLocator;


public class registrationStep {

    registrationPage reg;
    WebDriverWait wait;

    public registrationStep() {
        reg = new registrationPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }
    
    @Given("placed on dashboard page")
    public void placed_on_dashboard_page() {
    	System.out.println("User is on Dashboard Page");  
    }

    @When("I click on Registration option")
    public void navigates_reg_page() {
    	reg.clickRegOption();  
    }
    
    @Then("patient should be navigated to the registration page")
    public void navigated_to_registration_page() {
        wait.until(ExpectedConditions.urlContains("registration-screen"));
        System.out.println("User is navigated to registration page");
    }

//    FIRST NAME
    @And("I enter First Name {string}")
    public void enter_first_name(String fName) {
        reg.enterFirstName(fName);
    }

//    LAST NAME
    @And("I enter Last Name {string}")
    public void enter_last_name(String lName) {
        reg.enterLastName(lName);
    }
    
//   AGE
	  @And("I enter Age {string}")
	  public void enter_age(String age) {
	      reg.enterAge(age);
	  }
    
//	GENDER
	  @And("I select Gender {string}")
	  public void select_gender(String gender) {
	      reg.selectGender(gender);
	  }
//	TRANS GENDER --> YES
	  @And("I click Yes button")
	  public void click_yes() {
	      reg.clickYes();
	  }
//	TRANS GENDER --> NO
	  @And("I click No button")
	  public void click_no() {
	      reg.clickNo();
	  }
//	  OPEN DROPDWON ---> GENDER --WITHOUT SELECT VALUES
	  @When("I click on Gender dropdown")
	  public void click_gender_dropdown() {
	      reg.clickGenderDropdown();
	  }

//	NEXT OF Kin
	@And("I select Next of Kin {string}")
	public void select_kin(String kin) {
	   reg.selectKin(kin);
	}
//	  OPEN DROPDWON ---> KIN -- WITHOUT SELECT VALUES
	  @When("I click on Next of Kin dropdown")
	  public void click_kin_dropdown() {
	      reg.clickKinDropdown();
	  }
	
//  KIN NAME
	  @And("I enter Kin Name {string}")
	  public void enter_kin_name(String kinName) {
	      reg.enterKinName(kinName);
	  }
	 
//  DOOR / STREET
	  @And("I enter Door {string}")
	  public void enter_door_street(String doorStreet) {
	      reg.enterDoorStreet(doorStreet);
	  }	
	  
//  LOCALITY
	  @And("I enter Locality {string}")
	  public void enter_locality(String locality) {
	      reg.enterLocality(locality);
	  }	  
	  
//	AREA
	  
	  @When("I click on Area button")
	    public void clicke_area_button() {
	    	reg.clickAreaBtn();  
	    }
	  
		@And("I select Area {string}")
		public void select_area(String area) {	  
		   reg.selectArea(area);
		}
	  
//  PINCODE
	  @And("I enter PinCode {string}")
	  public void enter_pincode(String pincode) {
	      reg.enterPincode(pincode);
	  }
	  
//	TALUK
		@And("I select Taluk {string}")
		public void select_taluk(String taluk) {	  
		   reg.selectTaluk(taluk);
		}  
			
//  MOBILE NUMBER
	  @And("I enter Mobile No {string}")
	  public void enter_mobileNo(String mobile) {
	      reg.enterMobile(mobile);
	  }
	  
//  AADHAAR NUMBER
	  @And("I enter Aadhaar No {string}")
	  public void user_enters_aadhaarNo(String aadhaar) {
	      reg.enterAadhaar(aadhaar);
	  }

//	  SUBMIT BUTTON
    @When("I click on Submit button in registration")
    public void click_submit_reg() {
        reg.clickSubmit();
    }
    
    
    @Then("patient should be registered successfully")
    public void navigated_to_registration() {
        System.out.println("User is navigated to registration page");
    }


  
//	  CLEAR BUTTON
  @And("I click on Clear button in registration")
  public void click_clear_reg() {
      reg.clickClear();
  }
  
  @Then("patient entered details should be cleared")
  public void navigated_to_dashboard() {
      System.out.println("Entered patient details are cleared");
  }
  
	  
//  CANCEL BUTTON
	@And("I click on Cancel button in registration")
	public void click_cancel_reg() {	
	  reg.clickCancel();
	}
	
	  @Then("I should be navigated to dashboard page")
	  public void navigated_to_dashboard_after_cancel() {
	      wait.until(ExpectedConditions.urlContains("dashboard"));
	      System.out.println("Entered patient details are cleared");
	  }
	  
//CANCEL BUTTON FOR POP UP
	  @And("I click close icon in oid generated pop up in registration")
	  public void click_close_icon_oid_generated_popup() {
	    reg.clickCloseIcon();
	  }	  
	  
	  	  
//	  ONLY ALPHABETS ACCEPTED VALIDATION

  @Then("only alphabets should be entered in name field")
  public void validate_name_field() {

      WebElement field = DriverFactory.getDriver().findElement(registrationLocator.firstNameInput);

      String value = field.getAttribute("value");
      
      if (!value.matches("[a-zA-Z]*")) {
          throw new AssertionError("Invalid characters present: " + value);
      }  
  }
  
//    IF EMPTY FIELD ---> REQUIRED VALIDATION
  
  @Then("Required alert should be appear")
  public void validate_name_empty_field() {

	  WebElement errorMsg = wait.until(
		        ExpectedConditions.visibilityOfElementLocated(registrationLocator.requiredAlert)
		    );

		    if (!errorMsg.isDisplayed()) {
		        throw new AssertionError("Required");
		    }
		    System.out.println("Required alert is displayed");
  }
  
//  ONLY NUMBERS ACCEPTED VALIDATION
  
  @Then("only numbers should be accepted in field")
  public void validate_age_field() {

      WebElement field = DriverFactory.getDriver()
              .findElement(registrationLocator.ageInput);

      String value = field.getAttribute("value");
//     "//d" --> accepts 0-9
      if (!value.matches("\\d*")) {
          throw new AssertionError("Invalid characters in Age field: " + value);
      }

      System.out.println("Age field validation passed");
  }
  
//   INVALID ALERT MESSAGE
  
@Then("Invalid alert should be appear")
public void invalid_alert_messege() {

  WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.invalidAlert));

	    if (!errorMsg.isDisplayed()) {
	        throw new AssertionError("invalid");
	    }
	    System.out.println("Invalid alert is displayed");
}

//  PINCODE FIELD ACCEPTS MORE THAN 6 DIGITS
@Then("validation for pincode field")
public void validate_pincode_length() {

    WebElement field = DriverFactory.getDriver().findElement(registrationLocator.pincodeInput);
    String value = field.getAttribute("value");
    // ALLOWS ONLY NUMBERS  
    if (!value.matches("\\d*")) {
        throw new AssertionError("Pincode contains invalid characters: " + value);
    }
    // CHECK LEGNTH OF PINCODE
    if (value.length() > 6) {
        throw new AssertionError("Pincode accepts more than 6 digits: " + value);
    }
    System.out.println("Pincode accepted correctly: " + value);
}

//  NO DATA FOUND ERROR MESSEGE IN DROPDOWN
@Then("no data found messege should be displayed in dropdown")
public void no_data_message_displayed(){

	 WebElement noDataMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.noDataFoundMsg));
	 Assert.assertEquals(noDataMsg.getText().trim(), "No data Found");

	    System.out.println("Verified: No data Found message is displayed");
} 

//MOBILE NUMBER FIELD VALIDATION
@Then("validation for Mobile No field")
public void validate_mobilenumber_length() {

	   WebDriver driver = DriverFactory.getDriver();
	    WebElement field = driver.findElement(registrationLocator.mobileNumInput);
	    String value = field.getAttribute("value");
	    if (!value.matches("[6-9]\\d{9}")) {

	        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.invalidFormatAlert));
	        String actualText = errorMsg.getText().trim();
	        
	        if (!actualText.equals("Invalid format.")) {
	            throw new AssertionError("Expected 'Invalid format.' but got: " + actualText);
	        }
	        System.out.println("Correct error message displayed: " + actualText);
	    }
}

//AADHAAR NUMBER FIELD VALIDATION
@Then("validation for Aadhaar No field")
public void validate_aadhaarnumber_length() {

	 WebDriver driver = DriverFactory.getDriver();

	    WebElement field = driver.findElement(registrationLocator.aadhaarNumInput);
	    String value = field.getAttribute("value");

	    if (value.length() < 12) {

	        WebElement errorMsg = wait.until(ExpectedConditions.presenceOfElementLocated(
	                By.xpath("//*[contains(text(),'12 characters')]")));

	        String actualText = errorMsg.getText().trim();

	        if (!actualText.contains("12 characters")) {
	            throw new AssertionError("Expected length error, but got: " + actualText);
	        }

	        System.out.println("Length validation message displayed: " + actualText);
	    }
	    // INVALID AADHAAR FORMAT
	    else if (!value.matches("[2-9]\\d{11}")) {

	        WebElement errorMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(registrationLocator.invalidAadhaarAlert));

	        String actualText = errorMsg.getText().trim();

	        if (!actualText.equals("Invalid Aadhaar number")) {
	            throw new AssertionError("Expected 'Invalid Aadhaar number' but got: " + actualText);
	        }

	        System.out.println("Invalid Aadhaar message displayed correctly");
	    }
	    else {
	        System.out.println("Valid Aadhaar number: " + value);
	    }
}


// COPY AND STORE THE OID AND PIN AFTER REGISTER
@And("I capture and store the generated OID and PIN from registration popup")
public void capture_and_store_generated_oid_and_pin_from_registration_popup() {
    reg.captureOIDAndPIN();
}

// NO ITEMS FOUND MSG 
@Then("Verify No items found message is displayed")
public void verify_no_items_found_message_is_displayed() {
    reg.verifyNoItemsFoundMessage();
}










	
}
