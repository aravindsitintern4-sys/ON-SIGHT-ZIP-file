package stepDefinitions;

import io.cucumber.java.en.*;
import pages.OutReachEventSetupPage;
import utils.DriverFactory;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import locators.OutReachEventSetupLocator;

public class OutReachEventSetup {

    OutReachEventSetupPage page = new OutReachEventSetupPage(DriverFactory.getDriver());
    WebDriverWait wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));

    @Given("outreach event setup page")
    public void placed_on_outreach_page() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(OutReachEventSetupLocator.hospitalDropdown));
    }

    @When("I select hospital {string}")
    public void select_hospital(String hospital) {
        page.selectHospital(hospital);
    }

    @When("I select eventId {string}")
    public void enter_event_id(String eventId) {
        page.enterEventId(eventId);
    }
//    SAVE BUTTON
    @When("I click on the Save button")
    public void clicks_save() {
        page.clickSave();
    }

//    VALID ACTION
    @Then("I navigated to the dashboard page")
    public void navigated_to_dashboard() {

        wait.until(ExpectedConditions.urlContains("dashboard"));
        System.out.println("Navigated to Dashboard");
    }
    
//  ERROR MESSEGE ---> INVALID ACTION
  @Then("error message should be displayed Outreach Event setup")
  public void error_message_should_be_displayed_outReachEvent() {

      WebElement error = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Please fill all required fields!')]")));
      Assert.assertTrue(error.isDisplayed());
      System.out.println("Error messege is displayed");
  }

//CANCEL BUTTON
	@When("I click Cancel button")
	public void click_cancel_outReachEvent() {
	    page.clickCancel();
	} 
	@Then("I navigated to the login page")
	public void user_navigated_to_loginPage() {
	
	      wait.until(ExpectedConditions.urlContains("login"));
	      System.out.println("Navigated to login page");
	  }
    
}