package stepDefinitions;

import io.cucumber.java.en.*;
import pages.OutReachEventSetupPage;
import utils.DriverFactory;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import locators.OutReachEventSetupLocator;

public class OutReachEventSetup {

    OutReachEventSetupPage page = new OutReachEventSetupPage(DriverFactory.getDriver());
    WebDriverWait wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));

    @Given("user is on the outreach event setup page")
    public void user_is_on_outreach_page() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(OutReachEventSetupLocator.hospitalDropdown));
    }

    @When("user selects hospital {string}")
    public void user_selects_hospital(String hospital) {
        page.selectHospital(hospital);
    }

    @When("user selects eventId {string}")
    public void user_enters_event_id(String eventId) {
        page.enterEventId(eventId);
    }
//    SAVE BUTTON
    @When("user clicks on the Save button")
    public void user_clicks_save() {
        page.clickSave();
    }

//    VALID ACTION
    @Then("user should be navigated to the dashboard page")
    public void user_navigated_to_dashboard() {

        wait.until(ExpectedConditions.urlContains("dashboard"));
        System.out.println("Navigated to Dashboard");
    }
    
//  ERROR MESSEGE ---> INVALID ACTION
  @Then("error message should be displayed Outreach Event setup")
  public void error_message_should_be_displayed_outReachEvent() {

      WebElement error = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Please fill all required fields!')]")));
      Assert.assertTrue(error.isDisplayed());
      System.out.println("Error messege is displayed");
  }

//CANCEL BUTTON
	@When("user clicks Cancel button")
	public void user_clicks_cancel_outReachEvent() {
	    page.clickCancel();
	} 
	@Then("user should navigated to the login page")
	public void user_navigated_to_loginPage() {
	
	      wait.until(ExpectedConditions.urlContains("login"));
	      System.out.println("Navigated to login page");
	  }
    
}