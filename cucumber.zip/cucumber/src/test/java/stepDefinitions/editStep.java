package stepDefinitions;

import io.cucumber.java.en.*;
import locators.editLocator;
import pages.editPage;
import utils.DriverFactory;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class editStep {

    editPage edit;
    WebDriverWait wait;

    public editStep() {
        edit = new editPage(DriverFactory.getDriver());
        wait = new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(10));
    }

//    EDIT BUTTON 
    @When("I click on Edit button")
    public void click_edit_button() {
    	edit.clickEditBtn();  
    }
//	  EDIT POP-UP
    @Then("edit popup should be displayed")
    public void edit_popup_is_displayed() {
        System.out.println("Edit popup is displayed successfully");
    }

//  ENTER OID 
    @And("I enter OID {string} for edit")
    public void enter_OID_edit(String oid) {
        edit.enterOid(oid);
    }
    
//  SEARCH ICON
  @And("I click on Search icon in edit")
  public void click_search_icon_edit() {
      edit.clickSearchIcon();
  }
 

//  UPDATE BUTTON
  @And("I click on update button in edit")
  public void click_update_button_edit() {
      edit.clickUpdateBtn();
  }
  
//  @Then("patient address details should be displayed")
//  public void patient_address_details_are_displayed_edit() {
//	  System.out.println("Patient address details are displayed correctly");
//  }
  

//  CANCEL BUTTON FOR POP UP
  @And("I click on Cancel button in edit")
  public void click_cancel_button_edit() {
      edit.clickCancelBtn();
  }
  
//UPDATE BUTTON IN REGISTRATION PAGE
@And("I click update button in edit registration")
public void click_update_button_edit_registration() {
    edit.clickUpdateRegBtn();
}  
 
    
//EMPTY FIELDS ---> BUTTON DISABLE
@Then("update button should be disabled")
public void update_button_should_be_disabled() {

  WebElement updateBtn = wait.until(ExpectedConditions.presenceOfElementLocated(editLocator.updateBtn));
      
      Assert.assertFalse(updateBtn.isEnabled());
}    
  
// IF PATIENT NOT REG TODAY ----> PREVIOUS DAY OID
@And("error message {string} should be displayed in edit")
public void error_message_should_be_displayed_edit(String expectedMsg) {

    WebElement errorMsg = wait.until(
        ExpectedConditions.visibilityOfElementLocated(
            By.xpath("//span[contains(text(),'Patients not registered today cannot be edited.')]")
        )
    );

    String actualMsg = errorMsg.getText().trim();

    Assert.assertEquals(actualMsg, expectedMsg);
}
    
}