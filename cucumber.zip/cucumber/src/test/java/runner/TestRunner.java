package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
    features = "src/test/resources/features",
    glue = {"stepDefinitions", "hooks" , "utils"},
    tags = "@login",
    plugin = {"pretty"},
    monochrome = true
)
public class TestRunner extends AbstractTestNGCucumberTests {      
	   
}

       